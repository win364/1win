"use strict";
(self["webpackChunk_1win_frontend_main"] = self["webpackChunk_1win_frontend_main"] || []).push([
    [70299], {
        670299: (n, t, e) => {
            e.r(t), e.d(t, {
                default: () => v
            });
            var r = e(166252);

            function h(n, t) {
                return (0, r.wg)(), (0, r.iD)("svg", (0, r.dG)({
                    viewBox: "0 0 14 14",
                    xmlns: "http://www.w3.org/2000/svg"
                }, n.$attrs), t[0] || (t[0] = [(0, r._)("path", {
                    d: "M5 2H2v3H0V0h5zM5 12H2V9H0v5h5zM9 2h3v3h2V0H9zM9 12h3V9h2v5H9z"
                }, null, -1)]), 16)
            }
            var s = e(983744);
            const w = {},
                a = (0, s.Z)(w, [
                    ["render", h]
                ]),
                v = a
        }
    }
]);