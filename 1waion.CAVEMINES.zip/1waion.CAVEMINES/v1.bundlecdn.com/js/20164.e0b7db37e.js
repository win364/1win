"use strict";
(self["webpackChunk_1win_frontend_main"] = self["webpackChunk_1win_frontend_main"] || []).push([
    [20164], {
        720164: (n, t, a) => {
            a.r(t), a.d(t, {
                default: () => s
            });
            var e = a(166252);

            function r(n, t) {
                return (0, e.wg)(), (0, e.iD)("svg", (0, e.dG)({
                    xmlns: "http://www.w3.org/2000/svg",
                    width: "10",
                    height: "10",
                    viewBox: "0 0 10 10"
                }, n.$attrs), t[0] || (t[0] = [(0, e._)("path", {
                    fill: "#99A2AD",
                    d: "M9.5.5a.707.707 0 00-1 0L5 4 1.5.5a.707.707 0 00-1 1L4 5 .5 8.5a.707.707 0 001 1L5 6l3.5 3.5a.707.707 0 001-1L6 5l3.5-3.5a.707.707 0 000-1z"
                }, null, -1)]), 16)
            }
            var i = a(983744);
            const w = {},
                l = (0, i.Z)(w, [
                    ["render", r]
                ]),
                s = l
        }
    }
]);