"use strict";
(self["webpackChunk_1win_frontend_main"] = self["webpackChunk_1win_frontend_main"] || []).push([
    [82436], {
        282436: (n, e, l) => {
            l.r(e), l.d(e, {
                default: () => f
            });
            var t = l(166252);

            function i(n, e) {
                return (0, t.wg)(), (0, t.iD)("svg", (0, t.dG)({
                    width: "15",
                    height: "20",
                    viewBox: "0 0 15 20",
                    fill: "none",
                    xmlns: "http://www.w3.org/2000/svg"
                }, n.$attrs), e[0] || (e[0] = [(0, t._)("path", {
                    "fill-rule": "evenodd",
                    "clip-rule": "evenodd",
                    d: "M12 0c1.657 0 3 1.28 3 2.857v14.286C15 18.72 13.657 20 12 20H3c-1.657 0-3-1.28-3-2.857V2.857C0 1.28 1.343 0 3 0h9zM4.5 1.429v.428a1 1 0 001 1h4a1 1 0 001-1V1.43H12l.175.01c.746.082 1.325.686 1.325 1.418v14.286l-.01.166c-.087.71-.72 1.262-1.49 1.262H3l-.175-.01c-.746-.082-1.325-.686-1.325-1.418V2.857l.01-.166c.087-.711.72-1.262 1.49-1.262h1.5z",
                    fill: "#fff"
                }, null, -1)]), 16)
            }
            var r = l(983744);
            const c = {},
                d = (0, r.Z)(c, [
                    ["render", i]
                ]),
                f = d
        }
    }
]);