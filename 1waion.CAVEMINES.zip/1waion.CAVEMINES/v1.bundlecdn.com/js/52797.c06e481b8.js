(self["webpackChunk_1win_frontend_main"] = self["webpackChunk_1win_frontend_main"] || []).push([
    [52797], {
        250840: (t, e, i) => {
            var n;
            /*! Hammer.JS - v2.0.7 - 2016-04-22
             * http://hammerjs.github.io/
             *
             * Copyright (c) 2016 Jorik Tangelder;
             * Licensed under the MIT license */
            (function(r, s, o, a) {
                "use strict";
                var h, u = ["", "webkit", "Moz", "MS", "ms", "o"],
                    c = s.createElement("div"),
                    l = "function",
                    p = Math.round,
                    f = Math.abs,
                    v = Date.now;

                function d(t, e, i) {
                    return setTimeout(I(t, i), e)
                }

                function m(t, e, i) {
                    return !!Array.isArray(t) && (g(t, i[e], i), !0)
                }

                function g(t, e, i) {
                    var n;
                    if (t)
                        if (t.forEach) t.forEach(e, i);
                        else if (t.length !== a) {
                        n = 0;
                        while (n < t.length) e.call(i, t[n], n, t), n++
                    } else
                        for (n in t) t.hasOwnProperty(n) && e.call(i, t[n], n, t)
                }

                function T(t, e, i) {
                    var n = "DEPRECATED METHOD: " + e + "\n" + i + " AT \n";
                    return function() {
                        var e = new Error("get-stack-trace"),
                            i = e && e.stack ? e.stack.replace(/^[^\(]+?[\n$]/gm, "").replace(/^\s+at\s+/gm, "").replace(/^Object.<anonymous>\s*\(/gm, "{anonymous}()@") : "Unknown Stack Trace",
                            s = r.console && (r.console.warn || r.console.log);
                        return s && s.call(r.console, n, i), t.apply(this, arguments)
                    }
                }
                h = "function" !== typeof Object.assign ? function(t) {
                    if (t === a || null === t) throw new TypeError("Cannot convert undefined or null to object");
                    for (var e = Object(t), i = 1; i < arguments.length; i++) {
                        var n = arguments[i];
                        if (n !== a && null !== n)
                            for (var r in n) n.hasOwnProperty(r) && (e[r] = n[r])
                    }
                    return e
                } : Object.assign;
                var y = T((function(t, e, i) {
                        var n = Object.keys(e),
                            r = 0;
                        while (r < n.length)(!i || i && t[n[r]] === a) && (t[n[r]] = e[n[r]]), r++;
                        return t
                    }), "extend", "Use `assign`."),
                    E = T((function(t, e) {
                        return y(t, e, !0)
                    }), "merge", "Use `assign`.");

                function w(t, e, i) {
                    var n, r = e.prototype;
                    n = t.prototype = Object.create(r), n.constructor = t, n._super = r, i && h(n, i)
                }

                function I(t, e) {
                    return function() {
                        return t.apply(e, arguments)
                    }
                }

                function _(t, e) {
                    return typeof t == l ? t.apply(e && e[0] || a, e) : t
                }

                function A(t, e) {
                    return t === a ? e : t
                }

                function C(t, e, i) {
                    g(D(e), (function(e) {
                        t.addEventListener(e, i, !1)
                    }))
                }

                function b(t, e, i) {
                    g(D(e), (function(e) {
                        t.removeEventListener(e, i, !1)
                    }))
                }

                function S(t, e) {
                    while (t) {
                        if (t == e) return !0;
                        t = t.parentNode
                    }
                    return !1
                }

                function P(t, e) {
                    return t.indexOf(e) > -1
                }

                function D(t) {
                    return t.trim().split(/\s+/g)
                }

                function x(t, e, i) {
                    if (t.indexOf && !i) return t.indexOf(e);
                    var n = 0;
                    while (n < t.length) {
                        if (i && t[n][i] == e || !i && t[n] === e) return n;
                        n++
                    }
                    return -1
                }

                function O(t) {
                    return Array.prototype.slice.call(t, 0)
                }

                function R(t, e, i) {
                    var n = [],
                        r = [],
                        s = 0;
                    while (s < t.length) {
                        var o = e ? t[s][e] : t[s];
                        x(r, o) < 0 && n.push(t[s]), r[s] = o, s++
                    }
                    return i && (n = e ? n.sort((function(t, i) {
                        return t[e] > i[e]
                    })) : n.sort()), n
                }

                function M(t, e) {
                    var i, n, r = e[0].toUpperCase() + e.slice(1),
                        s = 0;
                    while (s < u.length) {
                        if (i = u[s], n = i ? i + r : e, n in t) return n;
                        s++
                    }
                    return a
                }
                var z = 1;

                function N() {
                    return z++
                }

                function X(t) {
                    var e = t.ownerDocument || t;
                    return e.defaultView || e.parentWindow || r
                }
                var Y = /mobile|tablet|ip(ad|hone|od)|android/i,
                    F = "ontouchstart" in r,
                    k = M(r, "PointerEvent") !== a,
                    W = F && Y.test(navigator.userAgent),
                    q = "touch",
                    L = "pen",
                    H = "mouse",
                    U = "kinect",
                    V = 25,
                    j = 1,
                    G = 2,
                    Z = 4,
                    B = 8,
                    $ = 1,
                    J = 2,
                    K = 4,
                    Q = 8,
                    tt = 16,
                    et = J | K,
                    it = Q | tt,
                    nt = et | it,
                    rt = ["x", "y"],
                    st = ["clientX", "clientY"];

                function ot(t, e) {
                    var i = this;
                    this.manager = t, this.callback = e, this.element = t.element, this.target = t.options.inputTarget, this.domHandler = function(e) {
                        _(t.options.enable, [t]) && i.handler(e)
                    }, this.init()
                }

                function at(t) {
                    var e, i = t.options.inputClass;
                    return e = i || (k ? Pt : W ? Xt : F ? Wt : _t), new e(t, ht)
                }

                function ht(t, e, i) {
                    var n = i.pointers.length,
                        r = i.changedPointers.length,
                        s = e & j && n - r === 0,
                        o = e & (Z | B) && n - r === 0;
                    i.isFirst = !!s, i.isFinal = !!o, s && (t.session = {}), i.eventType = e, ut(t, i), t.emit("hammer.input", i), t.recognize(i), t.session.prevInput = i
                }

                function ut(t, e) {
                    var i = t.session,
                        n = e.pointers,
                        r = n.length;
                    i.firstInput || (i.firstInput = pt(e)), r > 1 && !i.firstMultiple ? i.firstMultiple = pt(e) : 1 === r && (i.firstMultiple = !1);
                    var s = i.firstInput,
                        o = i.firstMultiple,
                        a = o ? o.center : s.center,
                        h = e.center = ft(n);
                    e.timeStamp = v(), e.deltaTime = e.timeStamp - s.timeStamp, e.angle = gt(a, h), e.distance = mt(a, h), ct(i, e), e.offsetDirection = dt(e.deltaX, e.deltaY);
                    var u = vt(e.deltaTime, e.deltaX, e.deltaY);
                    e.overallVelocityX = u.x, e.overallVelocityY = u.y, e.overallVelocity = f(u.x) > f(u.y) ? u.x : u.y, e.scale = o ? yt(o.pointers, n) : 1, e.rotation = o ? Tt(o.pointers, n) : 0, e.maxPointers = i.prevInput ? e.pointers.length > i.prevInput.maxPointers ? e.pointers.length : i.prevInput.maxPointers : e.pointers.length, lt(i, e);
                    var c = t.element;
                    S(e.srcEvent.target, c) && (c = e.srcEvent.target), e.target = c
                }

                function ct(t, e) {
                    var i = e.center,
                        n = t.offsetDelta || {},
                        r = t.prevDelta || {},
                        s = t.prevInput || {};
                    e.eventType !== j && s.eventType !== Z || (r = t.prevDelta = {
                        x: s.deltaX || 0,
                        y: s.deltaY || 0
                    }, n = t.offsetDelta = {
                        x: i.x,
                        y: i.y
                    }), e.deltaX = r.x + (i.x - n.x), e.deltaY = r.y + (i.y - n.y)
                }

                function lt(t, e) {
                    var i, n, r, s, o = t.lastInterval || e,
                        h = e.timeStamp - o.timeStamp;
                    if (e.eventType != B && (h > V || o.velocity === a)) {
                        var u = e.deltaX - o.deltaX,
                            c = e.deltaY - o.deltaY,
                            l = vt(h, u, c);
                        n = l.x, r = l.y, i = f(l.x) > f(l.y) ? l.x : l.y, s = dt(u, c), t.lastInterval = e
                    } else i = o.velocity, n = o.velocityX, r = o.velocityY, s = o.direction;
                    e.velocity = i, e.velocityX = n, e.velocityY = r, e.direction = s
                }

                function pt(t) {
                    var e = [],
                        i = 0;
                    while (i < t.pointers.length) e[i] = {
                        clientX: p(t.pointers[i].clientX),
                        clientY: p(t.pointers[i].clientY)
                    }, i++;
                    return {
                        timeStamp: v(),
                        pointers: e,
                        center: ft(e),
                        deltaX: t.deltaX,
                        deltaY: t.deltaY
                    }
                }

                function ft(t) {
                    var e = t.length;
                    if (1 === e) return {
                        x: p(t[0].clientX),
                        y: p(t[0].clientY)
                    };
                    var i = 0,
                        n = 0,
                        r = 0;
                    while (r < e) i += t[r].clientX, n += t[r].clientY, r++;
                    return {
                        x: p(i / e),
                        y: p(n / e)
                    }
                }

                function vt(t, e, i) {
                    return {
                        x: e / t || 0,
                        y: i / t || 0
                    }
                }

                function dt(t, e) {
                    return t === e ? $ : f(t) >= f(e) ? t < 0 ? J : K : e < 0 ? Q : tt
                }

                function mt(t, e, i) {
                    i || (i = rt);
                    var n = e[i[0]] - t[i[0]],
                        r = e[i[1]] - t[i[1]];
                    return Math.sqrt(n * n + r * r)
                }

                function gt(t, e, i) {
                    i || (i = rt);
                    var n = e[i[0]] - t[i[0]],
                        r = e[i[1]] - t[i[1]];
                    return 180 * Math.atan2(r, n) / Math.PI
                }

                function Tt(t, e) {
                    return gt(e[1], e[0], st) + gt(t[1], t[0], st)
                }

                function yt(t, e) {
                    return mt(e[0], e[1], st) / mt(t[0], t[1], st)
                }
                ot.prototype = {
                    handler: function() {},
                    init: function() {
                        this.evEl && C(this.element, this.evEl, this.domHandler), this.evTarget && C(this.target, this.evTarget, this.domHandler), this.evWin && C(X(this.element), this.evWin, this.domHandler)
                    },
                    destroy: function() {
                        this.evEl && b(this.element, this.evEl, this.domHandler), this.evTarget && b(this.target, this.evTarget, this.domHandler), this.evWin && b(X(this.element), this.evWin, this.domHandler)
                    }
                };
                var Et = {
                        mousedown: j,
                        mousemove: G,
                        mouseup: Z
                    },
                    wt = "mousedown",
                    It = "mousemove mouseup";

                function _t() {
                    this.evEl = wt, this.evWin = It, this.pressed = !1, ot.apply(this, arguments)
                }
                w(_t, ot, {
                    handler: function(t) {
                        var e = Et[t.type];
                        e & j && 0 === t.button && (this.pressed = !0), e & G && 1 !== t.which && (e = Z), this.pressed && (e & Z && (this.pressed = !1), this.callback(this.manager, e, {
                            pointers: [t],
                            changedPointers: [t],
                            pointerType: H,
                            srcEvent: t
                        }))
                    }
                });
                var At = {
                        pointerdown: j,
                        pointermove: G,
                        pointerup: Z,
                        pointercancel: B,
                        pointerout: B
                    },
                    Ct = {
                        2: q,
                        3: L,
                        4: H,
                        5: U
                    },
                    bt = "pointerdown",
                    St = "pointermove pointerup pointercancel";

                function Pt() {
                    this.evEl = bt, this.evWin = St, ot.apply(this, arguments), this.store = this.manager.session.pointerEvents = []
                }
                r.MSPointerEvent && !r.PointerEvent && (bt = "MSPointerDown", St = "MSPointerMove MSPointerUp MSPointerCancel"), w(Pt, ot, {
                    handler: function(t) {
                        var e = this.store,
                            i = !1,
                            n = t.type.toLowerCase().replace("ms", ""),
                            r = At[n],
                            s = Ct[t.pointerType] || t.pointerType,
                            o = s == q,
                            a = x(e, t.pointerId, "pointerId");
                        r & j && (0 === t.button || o) ? a < 0 && (e.push(t), a = e.length - 1) : r & (Z | B) && (i = !0), a < 0 || (e[a] = t, this.callback(this.manager, r, {
                            pointers: e,
                            changedPointers: [t],
                            pointerType: s,
                            srcEvent: t
                        }), i && e.splice(a, 1))
                    }
                });
                var Dt = {
                        touchstart: j,
                        touchmove: G,
                        touchend: Z,
                        touchcancel: B
                    },
                    xt = "touchstart",
                    Ot = "touchstart touchmove touchend touchcancel";

                function Rt() {
                    this.evTarget = xt, this.evWin = Ot, this.started = !1, ot.apply(this, arguments)
                }

                function Mt(t, e) {
                    var i = O(t.touches),
                        n = O(t.changedTouches);
                    return e & (Z | B) && (i = R(i.concat(n), "identifier", !0)), [i, n]
                }
                w(Rt, ot, {
                    handler: function(t) {
                        var e = Dt[t.type];
                        if (e === j && (this.started = !0), this.started) {
                            var i = Mt.call(this, t, e);
                            e & (Z | B) && i[0].length - i[1].length === 0 && (this.started = !1), this.callback(this.manager, e, {
                                pointers: i[0],
                                changedPointers: i[1],
                                pointerType: q,
                                srcEvent: t
                            })
                        }
                    }
                });
                var zt = {
                        touchstart: j,
                        touchmove: G,
                        touchend: Z,
                        touchcancel: B
                    },
                    Nt = "touchstart touchmove touchend touchcancel";

                function Xt() {
                    this.evTarget = Nt, this.targetIds = {}, ot.apply(this, arguments)
                }

                function Yt(t, e) {
                    var i = O(t.touches),
                        n = this.targetIds;
                    if (e & (j | G) && 1 === i.length) return n[i[0].identifier] = !0, [i, i];
                    var r, s, o = O(t.changedTouches),
                        a = [],
                        h = this.target;
                    if (s = i.filter((function(t) {
                            return S(t.target, h)
                        })), e === j) {
                        r = 0;
                        while (r < s.length) n[s[r].identifier] = !0, r++
                    }
                    r = 0;
                    while (r < o.length) n[o[r].identifier] && a.push(o[r]), e & (Z | B) && delete n[o[r].identifier], r++;
                    return a.length ? [R(s.concat(a), "identifier", !0), a] : void 0
                }
                w(Xt, ot, {
                    handler: function(t) {
                        var e = zt[t.type],
                            i = Yt.call(this, t, e);
                        i && this.callback(this.manager, e, {
                            pointers: i[0],
                            changedPointers: i[1],
                            pointerType: q,
                            srcEvent: t
                        })
                    }
                });
                var Ft = 2500,
                    kt = 25;

                function Wt() {
                    ot.apply(this, arguments);
                    var t = I(this.handler, this);
                    this.touch = new Xt(this.manager, t), this.mouse = new _t(this.manager, t), this.primaryTouch = null, this.lastTouches = []
                }

                function qt(t, e) {
                    t & j ? (this.primaryTouch = e.changedPointers[0].identifier, Lt.call(this, e)) : t & (Z | B) && Lt.call(this, e)
                }

                function Lt(t) {
                    var e = t.changedPointers[0];
                    if (e.identifier === this.primaryTouch) {
                        var i = {
                            x: e.clientX,
                            y: e.clientY
                        };
                        this.lastTouches.push(i);
                        var n = this.lastTouches,
                            r = function() {
                                var t = n.indexOf(i);
                                t > -1 && n.splice(t, 1)
                            };
                        setTimeout(r, Ft)
                    }
                }

                function Ht(t) {
                    for (var e = t.srcEvent.clientX, i = t.srcEvent.clientY, n = 0; n < this.lastTouches.length; n++) {
                        var r = this.lastTouches[n],
                            s = Math.abs(e - r.x),
                            o = Math.abs(i - r.y);
                        if (s <= kt && o <= kt) return !0
                    }
                    return !1
                }
                w(Wt, ot, {
                    handler: function(t, e, i) {
                        var n = i.pointerType == q,
                            r = i.pointerType == H;
                        if (!(r && i.sourceCapabilities && i.sourceCapabilities.firesTouchEvents)) {
                            if (n) qt.call(this, e, i);
                            else if (r && Ht.call(this, i)) return;
                            this.callback(t, e, i)
                        }
                    },
                    destroy: function() {
                        this.touch.destroy(), this.mouse.destroy()
                    }
                });
                var Ut = M(c.style, "touchAction"),
                    Vt = Ut !== a,
                    jt = "compute",
                    Gt = "auto",
                    Zt = "manipulation",
                    Bt = "none",
                    $t = "pan-x",
                    Jt = "pan-y",
                    Kt = ee();

                function Qt(t, e) {
                    this.manager = t, this.set(e)
                }

                function te(t) {
                    if (P(t, Bt)) return Bt;
                    var e = P(t, $t),
                        i = P(t, Jt);
                    return e && i ? Bt : e || i ? e ? $t : Jt : P(t, Zt) ? Zt : Gt
                }

                function ee() {
                    if (!Vt) return !1;
                    var t = {},
                        e = r.CSS && r.CSS.supports;
                    return ["auto", "manipulation", "pan-y", "pan-x", "pan-x pan-y", "none"].forEach((function(i) {
                        t[i] = !e || r.CSS.supports("touch-action", i)
                    })), t
                }
                Qt.prototype = {
                    set: function(t) {
                        t == jt && (t = this.compute()), Vt && this.manager.element.style && Kt[t] && (this.manager.element.style[Ut] = t), this.actions = t.toLowerCase().trim()
                    },
                    update: function() {
                        this.set(this.manager.options.touchAction)
                    },
                    compute: function() {
                        var t = [];
                        return g(this.manager.recognizers, (function(e) {
                            _(e.options.enable, [e]) && (t = t.concat(e.getTouchAction()))
                        })), te(t.join(" "))
                    },
                    preventDefaults: function(t) {
                        var e = t.srcEvent,
                            i = t.offsetDirection;
                        if (this.manager.session.prevented) e.preventDefault();
                        else {
                            var n = this.actions,
                                r = P(n, Bt) && !Kt[Bt],
                                s = P(n, Jt) && !Kt[Jt],
                                o = P(n, $t) && !Kt[$t];
                            if (r) {
                                var a = 1 === t.pointers.length,
                                    h = t.distance < 2,
                                    u = t.deltaTime < 250;
                                if (a && h && u) return
                            }
                            if (!o || !s) return r || s && i & et || o && i & it ? this.preventSrc(e) : void 0
                        }
                    },
                    preventSrc: function(t) {
                        this.manager.session.prevented = !0, t.preventDefault()
                    }
                };
                var ie = 1,
                    ne = 2,
                    re = 4,
                    se = 8,
                    oe = se,
                    ae = 16,
                    he = 32;

                function ue(t) {
                    this.options = h({}, this.defaults, t || {}), this.id = N(), this.manager = null, this.options.enable = A(this.options.enable, !0), this.state = ie, this.simultaneous = {}, this.requireFail = []
                }

                function ce(t) {
                    return t & ae ? "cancel" : t & se ? "end" : t & re ? "move" : t & ne ? "start" : ""
                }

                function le(t) {
                    return t == tt ? "down" : t == Q ? "up" : t == J ? "left" : t == K ? "right" : ""
                }

                function pe(t, e) {
                    var i = e.manager;
                    return i ? i.get(t) : t
                }

                function fe() {
                    ue.apply(this, arguments)
                }

                function ve() {
                    fe.apply(this, arguments), this.pX = null, this.pY = null
                }

                function de() {
                    fe.apply(this, arguments)
                }

                function me() {
                    ue.apply(this, arguments), this._timer = null, this._input = null
                }

                function ge() {
                    fe.apply(this, arguments)
                }

                function Te() {
                    fe.apply(this, arguments)
                }

                function ye() {
                    ue.apply(this, arguments), this.pTime = !1, this.pCenter = !1, this._timer = null, this._input = null, this.count = 0
                }

                function Ee(t, e) {
                    return e = e || {}, e.recognizers = A(e.recognizers, Ee.defaults.preset), new _e(t, e)
                }
                ue.prototype = {
                    defaults: {},
                    set: function(t) {
                        return h(this.options, t), this.manager && this.manager.touchAction.update(), this
                    },
                    recognizeWith: function(t) {
                        if (m(t, "recognizeWith", this)) return this;
                        var e = this.simultaneous;
                        return t = pe(t, this), e[t.id] || (e[t.id] = t, t.recognizeWith(this)), this
                    },
                    dropRecognizeWith: function(t) {
                        return m(t, "dropRecognizeWith", this) || (t = pe(t, this), delete this.simultaneous[t.id]), this
                    },
                    requireFailure: function(t) {
                        if (m(t, "requireFailure", this)) return this;
                        var e = this.requireFail;
                        return t = pe(t, this), -1 === x(e, t) && (e.push(t), t.requireFailure(this)), this
                    },
                    dropRequireFailure: function(t) {
                        if (m(t, "dropRequireFailure", this)) return this;
                        t = pe(t, this);
                        var e = x(this.requireFail, t);
                        return e > -1 && this.requireFail.splice(e, 1), this
                    },
                    hasRequireFailures: function() {
                        return this.requireFail.length > 0
                    },
                    canRecognizeWith: function(t) {
                        return !!this.simultaneous[t.id]
                    },
                    emit: function(t) {
                        var e = this,
                            i = this.state;

                        function n(i) {
                            e.manager.emit(i, t)
                        }
                        i < se && n(e.options.event + ce(i)), n(e.options.event), t.additionalEvent && n(t.additionalEvent), i >= se && n(e.options.event + ce(i))
                    },
                    tryEmit: function(t) {
                        if (this.canEmit()) return this.emit(t);
                        this.state = he
                    },
                    canEmit: function() {
                        var t = 0;
                        while (t < this.requireFail.length) {
                            if (!(this.requireFail[t].state & (he | ie))) return !1;
                            t++
                        }
                        return !0
                    },
                    recognize: function(t) {
                        var e = h({}, t);
                        if (!_(this.options.enable, [this, e])) return this.reset(), void(this.state = he);
                        this.state & (oe | ae | he) && (this.state = ie), this.state = this.process(e), this.state & (ne | re | se | ae) && this.tryEmit(e)
                    },
                    process: function(t) {},
                    getTouchAction: function() {},
                    reset: function() {}
                }, w(fe, ue, {
                    defaults: {
                        pointers: 1
                    },
                    attrTest: function(t) {
                        var e = this.options.pointers;
                        return 0 === e || t.pointers.length === e
                    },
                    process: function(t) {
                        var e = this.state,
                            i = t.eventType,
                            n = e & (ne | re),
                            r = this.attrTest(t);
                        return n && (i & B || !r) ? e | ae : n || r ? i & Z ? e | se : e & ne ? e | re : ne : he
                    }
                }), w(ve, fe, {
                    defaults: {
                        event: "pan",
                        threshold: 10,
                        pointers: 1,
                        direction: nt
                    },
                    getTouchAction: function() {
                        var t = this.options.direction,
                            e = [];
                        return t & et && e.push(Jt), t & it && e.push($t), e
                    },
                    directionTest: function(t) {
                        var e = this.options,
                            i = !0,
                            n = t.distance,
                            r = t.direction,
                            s = t.deltaX,
                            o = t.deltaY;
                        return r & e.direction || (e.direction & et ? (r = 0 === s ? $ : s < 0 ? J : K, i = s != this.pX, n = Math.abs(t.deltaX)) : (r = 0 === o ? $ : o < 0 ? Q : tt, i = o != this.pY, n = Math.abs(t.deltaY))), t.direction = r, i && n > e.threshold && r & e.direction
                    },
                    attrTest: function(t) {
                        return fe.prototype.attrTest.call(this, t) && (this.state & ne || !(this.state & ne) && this.directionTest(t))
                    },
                    emit: function(t) {
                        this.pX = t.deltaX, this.pY = t.deltaY;
                        var e = le(t.direction);
                        e && (t.additionalEvent = this.options.event + e), this._super.emit.call(this, t)
                    }
                }), w(de, fe, {
                    defaults: {
                        event: "pinch",
                        threshold: 0,
                        pointers: 2
                    },
                    getTouchAction: function() {
                        return [Bt]
                    },
                    attrTest: function(t) {
                        return this._super.attrTest.call(this, t) && (Math.abs(t.scale - 1) > this.options.threshold || this.state & ne)
                    },
                    emit: function(t) {
                        if (1 !== t.scale) {
                            var e = t.scale < 1 ? "in" : "out";
                            t.additionalEvent = this.options.event + e
                        }
                        this._super.emit.call(this, t)
                    }
                }), w(me, ue, {
                    defaults: {
                        event: "press",
                        pointers: 1,
                        time: 251,
                        threshold: 9
                    },
                    getTouchAction: function() {
                        return [Gt]
                    },
                    process: function(t) {
                        var e = this.options,
                            i = t.pointers.length === e.pointers,
                            n = t.distance < e.threshold,
                            r = t.deltaTime > e.time;
                        if (this._input = t, !n || !i || t.eventType & (Z | B) && !r) this.reset();
                        else if (t.eventType & j) this.reset(), this._timer = d((function() {
                            this.state = oe, this.tryEmit()
                        }), e.time, this);
                        else if (t.eventType & Z) return oe;
                        return he
                    },
                    reset: function() {
                        clearTimeout(this._timer)
                    },
                    emit: function(t) {
                        this.state === oe && (t && t.eventType & Z ? this.manager.emit(this.options.event + "up", t) : (this._input.timeStamp = v(), this.manager.emit(this.options.event, this._input)))
                    }
                }), w(ge, fe, {
                    defaults: {
                        event: "rotate",
                        threshold: 0,
                        pointers: 2
                    },
                    getTouchAction: function() {
                        return [Bt]
                    },
                    attrTest: function(t) {
                        return this._super.attrTest.call(this, t) && (Math.abs(t.rotation) > this.options.threshold || this.state & ne)
                    }
                }), w(Te, fe, {
                    defaults: {
                        event: "swipe",
                        threshold: 10,
                        velocity: .3,
                        direction: et | it,
                        pointers: 1
                    },
                    getTouchAction: function() {
                        return ve.prototype.getTouchAction.call(this)
                    },
                    attrTest: function(t) {
                        var e, i = this.options.direction;
                        return i & (et | it) ? e = t.overallVelocity : i & et ? e = t.overallVelocityX : i & it && (e = t.overallVelocityY), this._super.attrTest.call(this, t) && i & t.offsetDirection && t.distance > this.options.threshold && t.maxPointers == this.options.pointers && f(e) > this.options.velocity && t.eventType & Z
                    },
                    emit: function(t) {
                        var e = le(t.offsetDirection);
                        e && this.manager.emit(this.options.event + e, t), this.manager.emit(this.options.event, t)
                    }
                }), w(ye, ue, {
                    defaults: {
                        event: "tap",
                        pointers: 1,
                        taps: 1,
                        interval: 300,
                        time: 250,
                        threshold: 9,
                        posThreshold: 10
                    },
                    getTouchAction: function() {
                        return [Zt]
                    },
                    process: function(t) {
                        var e = this.options,
                            i = t.pointers.length === e.pointers,
                            n = t.distance < e.threshold,
                            r = t.deltaTime < e.time;
                        if (this.reset(), t.eventType & j && 0 === this.count) return this.failTimeout();
                        if (n && r && i) {
                            if (t.eventType != Z) return this.failTimeout();
                            var s = !this.pTime || t.timeStamp - this.pTime < e.interval,
                                o = !this.pCenter || mt(this.pCenter, t.center) < e.posThreshold;
                            this.pTime = t.timeStamp, this.pCenter = t.center, o && s ? this.count += 1 : this.count = 1, this._input = t;
                            var a = this.count % e.taps;
                            if (0 === a) return this.hasRequireFailures() ? (this._timer = d((function() {
                                this.state = oe, this.tryEmit()
                            }), e.interval, this), ne) : oe
                        }
                        return he
                    },
                    failTimeout: function() {
                        return this._timer = d((function() {
                            this.state = he
                        }), this.options.interval, this), he
                    },
                    reset: function() {
                        clearTimeout(this._timer)
                    },
                    emit: function() {
                        this.state == oe && (this._input.tapCount = this.count, this.manager.emit(this.options.event, this._input))
                    }
                }), Ee.VERSION = "2.0.7", Ee.defaults = {
                    domEvents: !1,
                    touchAction: jt,
                    enable: !0,
                    inputTarget: null,
                    inputClass: null,
                    preset: [
                        [ge, {
                            enable: !1
                        }],
                        [de, {
                                enable: !1
                            },
                            ["rotate"]
                        ],
                        [Te, {
                            direction: et
                        }],
                        [ve, {
                                direction: et
                            },
                            ["swipe"]
                        ],
                        [ye],
                        [ye, {
                                event: "doubletap",
                                taps: 2
                            },
                            ["tap"]
                        ],
                        [me]
                    ],
                    cssProps: {
                        userSelect: "none",
                        touchSelect: "none",
                        touchCallout: "none",
                        contentZooming: "none",
                        userDrag: "none",
                        tapHighlightColor: "rgba(0,0,0,0)"
                    }
                };
                var we = 1,
                    Ie = 2;

                function _e(t, e) {
                    this.options = h({}, Ee.defaults, e || {}), this.options.inputTarget = this.options.inputTarget || t, this.handlers = {}, this.session = {}, this.recognizers = [], this.oldCssProps = {}, this.element = t, this.input = at(this), this.touchAction = new Qt(this, this.options.touchAction), Ae(this, !0), g(this.options.recognizers, (function(t) {
                        var e = this.add(new t[0](t[1]));
                        t[2] && e.recognizeWith(t[2]), t[3] && e.requireFailure(t[3])
                    }), this)
                }

                function Ae(t, e) {
                    var i, n = t.element;
                    n.style && (g(t.options.cssProps, (function(r, s) {
                        i = M(n.style, s), e ? (t.oldCssProps[i] = n.style[i], n.style[i] = r) : n.style[i] = t.oldCssProps[i] || ""
                    })), e || (t.oldCssProps = {}))
                }

                function Ce(t, e) {
                    var i = s.createEvent("Event");
                    i.initEvent(t, !0, !0), i.gesture = e, e.target.dispatchEvent(i)
                }
                _e.prototype = {
                    set: function(t) {
                        return h(this.options, t), t.touchAction && this.touchAction.update(), t.inputTarget && (this.input.destroy(), this.input.target = t.inputTarget, this.input.init()), this
                    },
                    stop: function(t) {
                        this.session.stopped = t ? Ie : we
                    },
                    recognize: function(t) {
                        var e = this.session;
                        if (!e.stopped) {
                            var i;
                            this.touchAction.preventDefaults(t);
                            var n = this.recognizers,
                                r = e.curRecognizer;
                            (!r || r && r.state & oe) && (r = e.curRecognizer = null);
                            var s = 0;
                            while (s < n.length) i = n[s], e.stopped === Ie || r && i != r && !i.canRecognizeWith(r) ? i.reset() : i.recognize(t), !r && i.state & (ne | re | se) && (r = e.curRecognizer = i), s++
                        }
                    },
                    get: function(t) {
                        if (t instanceof ue) return t;
                        for (var e = this.recognizers, i = 0; i < e.length; i++)
                            if (e[i].options.event == t) return e[i];
                        return null
                    },
                    add: function(t) {
                        if (m(t, "add", this)) return this;
                        var e = this.get(t.options.event);
                        return e && this.remove(e), this.recognizers.push(t), t.manager = this, this.touchAction.update(), t
                    },
                    remove: function(t) {
                        if (m(t, "remove", this)) return this;
                        if (t = this.get(t), t) {
                            var e = this.recognizers,
                                i = x(e, t); - 1 !== i && (e.splice(i, 1), this.touchAction.update())
                        }
                        return this
                    },
                    on: function(t, e) {
                        if (t !== a && e !== a) {
                            var i = this.handlers;
                            return g(D(t), (function(t) {
                                i[t] = i[t] || [], i[t].push(e)
                            })), this
                        }
                    },
                    off: function(t, e) {
                        if (t !== a) {
                            var i = this.handlers;
                            return g(D(t), (function(t) {
                                e ? i[t] && i[t].splice(x(i[t], e), 1) : delete i[t]
                            })), this
                        }
                    },
                    emit: function(t, e) {
                        this.options.domEvents && Ce(t, e);
                        var i = this.handlers[t] && this.handlers[t].slice();
                        if (i && i.length) {
                            e.type = t, e.preventDefault = function() {
                                e.srcEvent.preventDefault()
                            };
                            var n = 0;
                            while (n < i.length) i[n](e), n++
                        }
                    },
                    destroy: function() {
                        this.element && Ae(this, !1), this.handlers = {}, this.session = {}, this.input.destroy(), this.element = null
                    }
                }, h(Ee, {
                    INPUT_START: j,
                    INPUT_MOVE: G,
                    INPUT_END: Z,
                    INPUT_CANCEL: B,
                    STATE_POSSIBLE: ie,
                    STATE_BEGAN: ne,
                    STATE_CHANGED: re,
                    STATE_ENDED: se,
                    STATE_RECOGNIZED: oe,
                    STATE_CANCELLED: ae,
                    STATE_FAILED: he,
                    DIRECTION_NONE: $,
                    DIRECTION_LEFT: J,
                    DIRECTION_RIGHT: K,
                    DIRECTION_UP: Q,
                    DIRECTION_DOWN: tt,
                    DIRECTION_HORIZONTAL: et,
                    DIRECTION_VERTICAL: it,
                    DIRECTION_ALL: nt,
                    Manager: _e,
                    Input: ot,
                    TouchAction: Qt,
                    TouchInput: Xt,
                    MouseInput: _t,
                    PointerEventInput: Pt,
                    TouchMouseInput: Wt,
                    SingleTouchInput: Rt,
                    Recognizer: ue,
                    AttrRecognizer: fe,
                    Tap: ye,
                    Pan: ve,
                    Swipe: Te,
                    Pinch: de,
                    Rotate: ge,
                    Press: me,
                    on: C,
                    off: b,
                    each: g,
                    merge: E,
                    extend: y,
                    assign: h,
                    inherit: w,
                    bindFn: I,
                    prefixed: M
                });
                var be = "undefined" !== typeof r ? r : "undefined" !== typeof self ? self : {};
                be.Hammer = Ee, n = function() {
                    return Ee
                }.call(e, i, e, t), n === a || (t.exports = n)
            })(window, document)
        }
    }
]);