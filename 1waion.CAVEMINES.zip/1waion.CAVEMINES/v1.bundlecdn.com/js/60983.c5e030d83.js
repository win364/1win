"use strict";
(self["webpackChunk_1win_frontend_main"] = self["webpackChunk_1win_frontend_main"] || []).push([
    [60983], {
        660983: (l, a, e) => {
            e.r(a), e.d(a, {
                default: () => r
            });
            var t = e(166252);

            function c(l, a) {
                return (0, t.wg)(), (0, t.iD)("svg", (0, t.dG)({
                    width: "26",
                    height: "15",
                    viewBox: "0 0 26 15",
                    fill: "none",
                    xmlns: "http://www.w3.org/2000/svg"
                }, l.$attrs), a[0] || (a[0] = [(0, t.uE)('<g class="mastercard_svg__color"><path d="M7.956 15c3.986 0 7.218-3.358 7.218-7.5 0-4.142-3.232-7.5-7.218-7.5C3.969 0 .736 3.358.736 7.5c0 4.142 3.233 7.5 7.22 7.5z" fill="#EA001B"></path><path d="M18.268 15c3.987 0 7.219-3.358 7.219-7.5 0-4.142-3.232-7.5-7.219-7.5S11.05 3.358 11.05 7.5c0 4.142 3.232 7.5 7.22 7.5z" fill="#FFA200"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M12.864 2a7.866 7.866 0 00-2.227 5.5c0 2.14.85 4.082 2.227 5.5a7.866 7.866 0 002.228-5.5c0-2.142-.85-4.083-2.228-5.5z" fill="#ED692C"></path></g><g class="mastercard_svg__mono"><path d="M7.956 15c3.986 0 7.218-3.358 7.218-7.5 0-4.142-3.232-7.5-7.218-7.5C3.969 0 .736 3.358.736 7.5c0 4.142 3.233 7.5 7.22 7.5z" fill="#FFF"></path><path d="M18.268 15c3.987 0 7.219-3.358 7.219-7.5 0-4.142-3.232-7.5-7.219-7.5S11.05 3.358 11.05 7.5c0 4.142 3.232 7.5 7.22 7.5z" fill="#FFF"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M12.864 2a7.866 7.866 0 00-2.227 5.5c0 2.14.85 4.082 2.227 5.5a7.866 7.866 0 002.228-5.5c0-2.142-.85-4.083-2.228-5.5z" fill="#C3DDF7"></path></g>', 2)]), 16)
            }
            var d = e(983744);
            const n = {},
                i = (0, d.Z)(n, [
                    ["render", c]
                ]),
                r = i
        }
    }
]);