"use strict";
(self["webpackChunk_1win_frontend_main"] = self["webpackChunk_1win_frontend_main"] || []).push([
    [75690], {
        75690: (n, t, r) => {
            r.r(t), r.d(t, {
                default: () => c
            });
            var e = r(166252);

            function i(n, t) {
                return (0, e.wg)(), (0, e.iD)("svg", (0, e.dG)({
                    xmlns: "http://www.w3.org/2000/svg",
                    width: "16",
                    height: "14",
                    viewBox: "0 0 16 14"
                }, n.$attrs), t[0] || (t[0] = [(0, e._)("path", {
                    fill: "currentColor",
                    d: "M8 0C3.581 0 0 2.91 0 6.5c0 1.55.669 2.969 1.781 4.084C1.391 12.16.084 13.563.07 13.578a.248.248 0 00-.047.272c.04.094.128.15.228.15 2.072 0 3.625-.994 4.394-1.606A9.53 9.53 0 008 13c4.419 0 8-2.91 8-6.5S12.419 0 8 0z"
                }, null, -1)]), 16)
            }
            var w = r(983744);
            const a = {},
                s = (0, w.Z)(a, [
                    ["render", i]
                ]),
                c = s
        }
    }
]);