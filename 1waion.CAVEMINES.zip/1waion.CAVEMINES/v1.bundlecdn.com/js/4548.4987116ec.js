"use strict";
(self["webpackChunk_1win_frontend_main"] = self["webpackChunk_1win_frontend_main"] || []).push([
    [4548], {
        4548: (n, e, l) => {
            l.r(e), l.d(e, {
                default: () => o
            });
            var r = l(166252);

            function t(n, e) {
                return (0, r.wg)(), (0, r.iD)("svg", (0, r.dG)({
                    xmlns: "http://www.w3.org/2000/svg",
                    fill: "none",
                    viewBox: "0 0 24 24"
                }, n.$attrs), e[0] || (e[0] = [(0, r._)("path", {
                    fill: "currentColor",
                    "fill-rule": "evenodd",
                    d: "M12 2a10 10 0 100 20 10 10 0 000-20zm4.28 7.75a.94.94 0 10-1.42-1.22l-4.2 4.89-1.52-1.77a.94.94 0 00-1.42 1.22l2.23 2.6a.94.94 0 001.42 0l4.91-5.72z",
                    "clip-rule": "evenodd"
                }, null, -1)]), 16)
            }
            var a = l(983744);
            const i = {},
                d = (0, a.Z)(i, [
                    ["render", t]
                ]),
                o = d
        }
    }
]);