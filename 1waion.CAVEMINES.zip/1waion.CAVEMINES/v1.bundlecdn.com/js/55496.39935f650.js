(self["webpackChunk_1win_frontend_main"] = self["webpackChunk_1win_frontend_main"] || []).push([
    [55496], {
        555496: (t, e, n) => {
            "use strict";
            n.d(e, {
                i: () => ht
            });
            var d = n(916991),
                p = n.n(d),
                h = n(722972),
                c = n.n(h),
                i = n(269594),
                m = n.n(i),
                g = n(24841),
                b = n.n(g),
                o = n(775608),
                r = n.n(o),
                a = n(597563),
                s = n.n(a),
                w = n(259987),
                u = n.n(w),
                l = n(747199),
                v = n.n(l),
                f = n(136701),
                _ = n.n(f),
                y = n(478888),
                S = n.n(y),
                k = n(534153),
                x = n.n(k),
                z = n(384131),
                C = n.n(z),
                j = n(490076),
                q = n.n(j),
                A = n(38867),
                B = n.n(A),
                D = n(400863),
                E = n.n(D),
                F = n(803630),
                G = n.n(F),
                H = n(503622),
                I = n.n(H),
                J = n(217094),
                K = n.n(J),
                L = n(479976),
                M = n.n(L),
                N = n(692637),
                O = n.n(N),
                P = n(765080),
                Q = n.n(P),
                R = n(236962),
                T = n.n(R),
                U = n(681319),
                V = n.n(U),
                W = n(643311),
                X = n.n(W),
                Y = n(872853),
                Z = n.n(Y),
                $ = n(491967),
                tt = n.n($),
                et = n(217710),
                nt = n.n(et),
                dt = n(599711),
                pt = n.n(dt);
            const ht = {
                airtel: {
                    png: p(),
                    webp: c()
                },
                amazon: {
                    png: m(),
                    webp: b()
                },
                bank_transfer_order: {
                    png: r(),
                    webp: s()
                },
                bhim_order: {
                    png: u(),
                    webp: v()
                },
                freecharge: {
                    png: _(),
                    webp: S()
                },
                gpay_order: {
                    png: x(),
                    webp: C()
                },
                mobikwik: {
                    png: q(),
                    webp: B()
                },
                paytm: {
                    png: E(),
                    webp: G()
                },
                paytm_order: {
                    png: I(),
                    webp: K()
                },
                phonepe: {
                    png: M(),
                    webp: O()
                },
                phonepe_order: {
                    png: Q(),
                    webp: T()
                },
                upi_id: {
                    png: V(),
                    webp: X()
                },
                upi_order: {
                    png: Z(),
                    webp: tt()
                },
                whatsapp: {
                    png: nt(),
                    webp: pt()
                }
            }
        },
        916991: t => {
            t.exports = {
                srcSet: "https://v1.bundlecdn.com/img/airtel.7572fbb44-200.png 200w,https://v1.bundlecdn.com/img/airtel.22e56247b-300.png 300w,https://v1.bundlecdn.com/img/airtel.fe56e0a25-322.png 322w",
                images: [{
                    path: "https://v1.bundlecdn.com/img/airtel.7572fbb44-200.png",
                    width: 200,
                    height: 409
                }, {
                    path: "https://v1.bundlecdn.com/img/airtel.22e56247b-300.png",
                    width: 300,
                    height: 613
                }, {
                    path: "https://v1.bundlecdn.com/img/airtel.fe56e0a25-322.png",
                    width: 322,
                    height: 658
                }],
                src: "https://v1.bundlecdn.com/img/airtel.fe56e0a25-322.png",
                toString: function() {
                    return "https://v1.bundlecdn.com/img/airtel.fe56e0a25-322.png"
                },
                width: 322,
                height: 658
            }
        },
        722972: t => {
            t.exports = {
                srcSet: "https://v1.bundlecdn.com/img/airtel.665f83c20-200.webp 200w,https://v1.bundlecdn.com/img/airtel.e8b1f2f51-300.webp 300w,https://v1.bundlecdn.com/img/airtel.1f3f14ab2-322.webp 322w",
                images: [{
                    path: "https://v1.bundlecdn.com/img/airtel.665f83c20-200.webp",
                    width: 200,
                    height: 409
                }, {
                    path: "https://v1.bundlecdn.com/img/airtel.e8b1f2f51-300.webp",
                    width: 300,
                    height: 613
                }, {
                    path: "https://v1.bundlecdn.com/img/airtel.1f3f14ab2-322.webp",
                    width: 322,
                    height: 658
                }],
                src: "https://v1.bundlecdn.com/img/airtel.1f3f14ab2-322.webp",
                toString: function() {
                    return "https://v1.bundlecdn.com/img/airtel.1f3f14ab2-322.webp"
                },
                width: 322,
                height: 658
            }
        },
        269594: t => {
            t.exports = {
                srcSet: "https://v1.bundlecdn.com/img/amazon.3d10cf33a-200.png 200w,https://v1.bundlecdn.com/img/amazon.3fb2fba29-300.png 300w,https://v1.bundlecdn.com/img/amazon.58de9f898-339.png 339w",
                images: [{
                    path: "https://v1.bundlecdn.com/img/amazon.3d10cf33a-200.png",
                    width: 200,
                    height: 394
                }, {
                    path: "https://v1.bundlecdn.com/img/amazon.3fb2fba29-300.png",
                    width: 300,
                    height: 591
                }, {
                    path: "https://v1.bundlecdn.com/img/amazon.58de9f898-339.png",
                    width: 339,
                    height: 668
                }],
                src: "https://v1.bundlecdn.com/img/amazon.58de9f898-339.png",
                toString: function() {
                    return "https://v1.bundlecdn.com/img/amazon.58de9f898-339.png"
                },
                width: 339,
                height: 668
            }
        },
        24841: t => {
            t.exports = {
                srcSet: "https://v1.bundlecdn.com/img/amazon.0fd4371b4-200.webp 200w,https://v1.bundlecdn.com/img/amazon.ecec8e8f7-300.webp 300w,https://v1.bundlecdn.com/img/amazon.18c52ca77-339.webp 339w",
                images: [{
                    path: "https://v1.bundlecdn.com/img/amazon.0fd4371b4-200.webp",
                    width: 200,
                    height: 394
                }, {
                    path: "https://v1.bundlecdn.com/img/amazon.ecec8e8f7-300.webp",
                    width: 300,
                    height: 591
                }, {
                    path: "https://v1.bundlecdn.com/img/amazon.18c52ca77-339.webp",
                    width: 339,
                    height: 668
                }],
                src: "https://v1.bundlecdn.com/img/amazon.18c52ca77-339.webp",
                toString: function() {
                    return "https://v1.bundlecdn.com/img/amazon.18c52ca77-339.webp"
                },
                width: 339,
                height: 668
            }
        },
        775608: t => {
            t.exports = {
                srcSet: "https://v1.bundlecdn.com/img/bank_transfer_order.ea532e482-200.png 200w,https://v1.bundlecdn.com/img/bank_transfer_order.41c6682fc-300.png 300w,https://v1.bundlecdn.com/img/bank_transfer_order.2093506e2-375.png 375w",
                images: [{
                    path: "https://v1.bundlecdn.com/img/bank_transfer_order.ea532e482-200.png",
                    width: 200,
                    height: 390
                }, {
                    path: "https://v1.bundlecdn.com/img/bank_transfer_order.41c6682fc-300.png",
                    width: 300,
                    height: 585
                }, {
                    path: "https://v1.bundlecdn.com/img/bank_transfer_order.2093506e2-375.png",
                    width: 375,
                    height: 731
                }],
                src: "https://v1.bundlecdn.com/img/bank_transfer_order.2093506e2-375.png",
                toString: function() {
                    return "https://v1.bundlecdn.com/img/bank_transfer_order.2093506e2-375.png"
                },
                width: 375,
                height: 731
            }
        },
        597563: t => {
            t.exports = {
                srcSet: "https://v1.bundlecdn.com/img/bank_transfer_order.952f22a89-200.webp 200w,https://v1.bundlecdn.com/img/bank_transfer_order.d5f3107c9-300.webp 300w,https://v1.bundlecdn.com/img/bank_transfer_order.5b987f403-375.webp 375w",
                images: [{
                    path: "https://v1.bundlecdn.com/img/bank_transfer_order.952f22a89-200.webp",
                    width: 200,
                    height: 390
                }, {
                    path: "https://v1.bundlecdn.com/img/bank_transfer_order.d5f3107c9-300.webp",
                    width: 300,
                    height: 585
                }, {
                    path: "https://v1.bundlecdn.com/img/bank_transfer_order.5b987f403-375.webp",
                    width: 375,
                    height: 731
                }],
                src: "https://v1.bundlecdn.com/img/bank_transfer_order.5b987f403-375.webp",
                toString: function() {
                    return "https://v1.bundlecdn.com/img/bank_transfer_order.5b987f403-375.webp"
                },
                width: 375,
                height: 731
            }
        },
        259987: t => {
            t.exports = {
                srcSet: "https://v1.bundlecdn.com/img/bhim_order.913f222dd-200.png 200w,https://v1.bundlecdn.com/img/bhim_order.d2dbb3bf6-300.png 300w,https://v1.bundlecdn.com/img/bhim_order.317f19f52-375.png 375w",
                images: [{
                    path: "https://v1.bundlecdn.com/img/bhim_order.913f222dd-200.png",
                    width: 200,
                    height: 390
                }, {
                    path: "https://v1.bundlecdn.com/img/bhim_order.d2dbb3bf6-300.png",
                    width: 300,
                    height: 585
                }, {
                    path: "https://v1.bundlecdn.com/img/bhim_order.317f19f52-375.png",
                    width: 375,
                    height: 731
                }],
                src: "https://v1.bundlecdn.com/img/bhim_order.317f19f52-375.png",
                toString: function() {
                    return "https://v1.bundlecdn.com/img/bhim_order.317f19f52-375.png"
                },
                width: 375,
                height: 731
            }
        },
        747199: t => {
            t.exports = {
                srcSet: "https://v1.bundlecdn.com/img/bhim_order.a8129e4c5-200.webp 200w,https://v1.bundlecdn.com/img/bhim_order.1a3961c42-300.webp 300w,https://v1.bundlecdn.com/img/bhim_order.e538082b8-375.webp 375w",
                images: [{
                    path: "https://v1.bundlecdn.com/img/bhim_order.a8129e4c5-200.webp",
                    width: 200,
                    height: 390
                }, {
                    path: "https://v1.bundlecdn.com/img/bhim_order.1a3961c42-300.webp",
                    width: 300,
                    height: 585
                }, {
                    path: "https://v1.bundlecdn.com/img/bhim_order.e538082b8-375.webp",
                    width: 375,
                    height: 731
                }],
                src: "https://v1.bundlecdn.com/img/bhim_order.e538082b8-375.webp",
                toString: function() {
                    return "https://v1.bundlecdn.com/img/bhim_order.e538082b8-375.webp"
                },
                width: 375,
                height: 731
            }
        },
        136701: t => {
            t.exports = {
                srcSet: "https://v1.bundlecdn.com/img/freecharge.d39141a8c-200.png 200w,https://v1.bundlecdn.com/img/freecharge.608a25771-300.png 300w,https://v1.bundlecdn.com/img/freecharge.a9bf29523-328.png 328w",
                images: [{
                    path: "https://v1.bundlecdn.com/img/freecharge.d39141a8c-200.png",
                    width: 200,
                    height: 402
                }, {
                    path: "https://v1.bundlecdn.com/img/freecharge.608a25771-300.png",
                    width: 300,
                    height: 603
                }, {
                    path: "https://v1.bundlecdn.com/img/freecharge.a9bf29523-328.png",
                    width: 328,
                    height: 659
                }],
                src: "https://v1.bundlecdn.com/img/freecharge.a9bf29523-328.png",
                toString: function() {
                    return "https://v1.bundlecdn.com/img/freecharge.a9bf29523-328.png"
                },
                width: 328,
                height: 659
            }
        },
        478888: t => {
            t.exports = {
                srcSet: "https://v1.bundlecdn.com/img/freecharge.8b98ba8bf-200.webp 200w,https://v1.bundlecdn.com/img/freecharge.4834feed1-300.webp 300w,https://v1.bundlecdn.com/img/freecharge.f02d02d20-328.webp 328w",
                images: [{
                    path: "https://v1.bundlecdn.com/img/freecharge.8b98ba8bf-200.webp",
                    width: 200,
                    height: 402
                }, {
                    path: "https://v1.bundlecdn.com/img/freecharge.4834feed1-300.webp",
                    width: 300,
                    height: 603
                }, {
                    path: "https://v1.bundlecdn.com/img/freecharge.f02d02d20-328.webp",
                    width: 328,
                    height: 659
                }],
                src: "https://v1.bundlecdn.com/img/freecharge.f02d02d20-328.webp",
                toString: function() {
                    return "https://v1.bundlecdn.com/img/freecharge.f02d02d20-328.webp"
                },
                width: 328,
                height: 659
            }
        },
        534153: t => {
            t.exports = {
                srcSet: "https://v1.bundlecdn.com/img/gpay_order.766172855-200.png 200w,https://v1.bundlecdn.com/img/gpay_order.48df5965d-300.png 300w,https://v1.bundlecdn.com/img/gpay_order.b0937602c-375.png 375w",
                images: [{
                    path: "https://v1.bundlecdn.com/img/gpay_order.766172855-200.png",
                    width: 200,
                    height: 390
                }, {
                    path: "https://v1.bundlecdn.com/img/gpay_order.48df5965d-300.png",
                    width: 300,
                    height: 585
                }, {
                    path: "https://v1.bundlecdn.com/img/gpay_order.b0937602c-375.png",
                    width: 375,
                    height: 731
                }],
                src: "https://v1.bundlecdn.com/img/gpay_order.b0937602c-375.png",
                toString: function() {
                    return "https://v1.bundlecdn.com/img/gpay_order.b0937602c-375.png"
                },
                width: 375,
                height: 731
            }
        },
        384131: t => {
            t.exports = {
                srcSet: "https://v1.bundlecdn.com/img/gpay_order.fe3234ac1-200.webp 200w,https://v1.bundlecdn.com/img/gpay_order.b0e40a6ae-300.webp 300w,https://v1.bundlecdn.com/img/gpay_order.21ffdf861-375.webp 375w",
                images: [{
                    path: "https://v1.bundlecdn.com/img/gpay_order.fe3234ac1-200.webp",
                    width: 200,
                    height: 390
                }, {
                    path: "https://v1.bundlecdn.com/img/gpay_order.b0e40a6ae-300.webp",
                    width: 300,
                    height: 585
                }, {
                    path: "https://v1.bundlecdn.com/img/gpay_order.21ffdf861-375.webp",
                    width: 375,
                    height: 731
                }],
                src: "https://v1.bundlecdn.com/img/gpay_order.21ffdf861-375.webp",
                toString: function() {
                    return "https://v1.bundlecdn.com/img/gpay_order.21ffdf861-375.webp"
                },
                width: 375,
                height: 731
            }
        },
        490076: t => {
            t.exports = {
                srcSet: "https://v1.bundlecdn.com/img/mobikwik.9b050b1f9-200.png 200w,https://v1.bundlecdn.com/img/mobikwik.0e5908d84-300.png 300w",
                images: [{
                    path: "https://v1.bundlecdn.com/img/mobikwik.9b050b1f9-200.png",
                    width: 200,
                    height: 442
                }, {
                    path: "https://v1.bundlecdn.com/img/mobikwik.0e5908d84-300.png",
                    width: 300,
                    height: 663
                }],
                src: "https://v1.bundlecdn.com/img/mobikwik.0e5908d84-300.png",
                toString: function() {
                    return "https://v1.bundlecdn.com/img/mobikwik.0e5908d84-300.png"
                },
                width: 300,
                height: 663
            }
        },
        38867: t => {
            t.exports = {
                srcSet: "https://v1.bundlecdn.com/img/mobikwik.f4e3e3d1b-200.webp 200w,https://v1.bundlecdn.com/img/mobikwik.1685c210e-300.webp 300w",
                images: [{
                    path: "https://v1.bundlecdn.com/img/mobikwik.f4e3e3d1b-200.webp",
                    width: 200,
                    height: 442
                }, {
                    path: "https://v1.bundlecdn.com/img/mobikwik.1685c210e-300.webp",
                    width: 300,
                    height: 663
                }],
                src: "https://v1.bundlecdn.com/img/mobikwik.1685c210e-300.webp",
                toString: function() {
                    return "https://v1.bundlecdn.com/img/mobikwik.1685c210e-300.webp"
                },
                width: 300,
                height: 663
            }
        },
        400863: t => {
            t.exports = {
                srcSet: "https://v1.bundlecdn.com/img/paytm.4286c63da-200.png 200w,https://v1.bundlecdn.com/img/paytm.3f9bde9c0-300.png 300w,https://v1.bundlecdn.com/img/paytm.e7addb337-400.png 400w,https://v1.bundlecdn.com/img/paytm.be7df6c75-555.png 555w",
                images: [{
                    path: "https://v1.bundlecdn.com/img/paytm.4286c63da-200.png",
                    width: 200,
                    height: 198
                }, {
                    path: "https://v1.bundlecdn.com/img/paytm.3f9bde9c0-300.png",
                    width: 300,
                    height: 297
                }, {
                    path: "https://v1.bundlecdn.com/img/paytm.e7addb337-400.png",
                    width: 400,
                    height: 396
                }, {
                    path: "https://v1.bundlecdn.com/img/paytm.be7df6c75-555.png",
                    width: 555,
                    height: 549
                }],
                src: "https://v1.bundlecdn.com/img/paytm.be7df6c75-555.png",
                toString: function() {
                    return "https://v1.bundlecdn.com/img/paytm.be7df6c75-555.png"
                },
                width: 555,
                height: 549
            }
        },
        803630: t => {
            t.exports = {
                srcSet: "https://v1.bundlecdn.com/img/paytm.92ce8b16f-200.webp 200w,https://v1.bundlecdn.com/img/paytm.5c5251873-300.webp 300w,https://v1.bundlecdn.com/img/paytm.312bc6c16-400.webp 400w,https://v1.bundlecdn.com/img/paytm.2f677d480-555.webp 555w",
                images: [{
                    path: "https://v1.bundlecdn.com/img/paytm.92ce8b16f-200.webp",
                    width: 200,
                    height: 198
                }, {
                    path: "https://v1.bundlecdn.com/img/paytm.5c5251873-300.webp",
                    width: 300,
                    height: 297
                }, {
                    path: "https://v1.bundlecdn.com/img/paytm.312bc6c16-400.webp",
                    width: 400,
                    height: 396
                }, {
                    path: "https://v1.bundlecdn.com/img/paytm.2f677d480-555.webp",
                    width: 555,
                    height: 549
                }],
                src: "https://v1.bundlecdn.com/img/paytm.2f677d480-555.webp",
                toString: function() {
                    return "https://v1.bundlecdn.com/img/paytm.2f677d480-555.webp"
                },
                width: 555,
                height: 549
            }
        },
        503622: t => {
            t.exports = {
                srcSet: "https://v1.bundlecdn.com/img/paytm_order.4286c63da-200.png 200w,https://v1.bundlecdn.com/img/paytm_order.3f9bde9c0-300.png 300w,https://v1.bundlecdn.com/img/paytm_order.e7addb337-400.png 400w,https://v1.bundlecdn.com/img/paytm_order.be7df6c75-555.png 555w",
                images: [{
                    path: "https://v1.bundlecdn.com/img/paytm_order.4286c63da-200.png",
                    width: 200,
                    height: 198
                }, {
                    path: "https://v1.bundlecdn.com/img/paytm_order.3f9bde9c0-300.png",
                    width: 300,
                    height: 297
                }, {
                    path: "https://v1.bundlecdn.com/img/paytm_order.e7addb337-400.png",
                    width: 400,
                    height: 396
                }, {
                    path: "https://v1.bundlecdn.com/img/paytm_order.be7df6c75-555.png",
                    width: 555,
                    height: 549
                }],
                src: "https://v1.bundlecdn.com/img/paytm_order.be7df6c75-555.png",
                toString: function() {
                    return "https://v1.bundlecdn.com/img/paytm_order.be7df6c75-555.png"
                },
                width: 555,
                height: 549
            }
        },
        217094: t => {
            t.exports = {
                srcSet: "https://v1.bundlecdn.com/img/paytm_order.92ce8b16f-200.webp 200w,https://v1.bundlecdn.com/img/paytm_order.5c5251873-300.webp 300w,https://v1.bundlecdn.com/img/paytm_order.312bc6c16-400.webp 400w,https://v1.bundlecdn.com/img/paytm_order.2f677d480-555.webp 555w",
                images: [{
                    path: "https://v1.bundlecdn.com/img/paytm_order.92ce8b16f-200.webp",
                    width: 200,
                    height: 198
                }, {
                    path: "https://v1.bundlecdn.com/img/paytm_order.5c5251873-300.webp",
                    width: 300,
                    height: 297
                }, {
                    path: "https://v1.bundlecdn.com/img/paytm_order.312bc6c16-400.webp",
                    width: 400,
                    height: 396
                }, {
                    path: "https://v1.bundlecdn.com/img/paytm_order.2f677d480-555.webp",
                    width: 555,
                    height: 549
                }],
                src: "https://v1.bundlecdn.com/img/paytm_order.2f677d480-555.webp",
                toString: function() {
                    return "https://v1.bundlecdn.com/img/paytm_order.2f677d480-555.webp"
                },
                width: 555,
                height: 549
            }
        },
        479976: t => {
            t.exports = {
                srcSet: "https://v1.bundlecdn.com/img/phonepe.8cc634a73-200.png 200w,https://v1.bundlecdn.com/img/phonepe.fadcaf4cc-300.png 300w,https://v1.bundlecdn.com/img/phonepe.bedce7158-400.png 400w,https://v1.bundlecdn.com/img/phonepe.9072da177-600.png 600w",
                images: [{
                    path: "https://v1.bundlecdn.com/img/phonepe.8cc634a73-200.png",
                    width: 200,
                    height: 297
                }, {
                    path: "https://v1.bundlecdn.com/img/phonepe.fadcaf4cc-300.png",
                    width: 300,
                    height: 445
                }, {
                    path: "https://v1.bundlecdn.com/img/phonepe.bedce7158-400.png",
                    width: 400,
                    height: 594
                }, {
                    path: "https://v1.bundlecdn.com/img/phonepe.9072da177-600.png",
                    width: 600,
                    height: 891
                }],
                src: "https://v1.bundlecdn.com/img/phonepe.9072da177-600.png",
                toString: function() {
                    return "https://v1.bundlecdn.com/img/phonepe.9072da177-600.png"
                },
                width: 600,
                height: 891
            }
        },
        692637: t => {
            t.exports = {
                srcSet: "https://v1.bundlecdn.com/img/phonepe.766eca1ad-200.webp 200w,https://v1.bundlecdn.com/img/phonepe.e7e87e062-300.webp 300w,https://v1.bundlecdn.com/img/phonepe.29d187351-400.webp 400w,https://v1.bundlecdn.com/img/phonepe.f6aef2450-600.webp 600w",
                images: [{
                    path: "https://v1.bundlecdn.com/img/phonepe.766eca1ad-200.webp",
                    width: 200,
                    height: 297
                }, {
                    path: "https://v1.bundlecdn.com/img/phonepe.e7e87e062-300.webp",
                    width: 300,
                    height: 445
                }, {
                    path: "https://v1.bundlecdn.com/img/phonepe.29d187351-400.webp",
                    width: 400,
                    height: 594
                }, {
                    path: "https://v1.bundlecdn.com/img/phonepe.f6aef2450-600.webp",
                    width: 600,
                    height: 891
                }],
                src: "https://v1.bundlecdn.com/img/phonepe.f6aef2450-600.webp",
                toString: function() {
                    return "https://v1.bundlecdn.com/img/phonepe.f6aef2450-600.webp"
                },
                width: 600,
                height: 891
            }
        },
        765080: t => {
            t.exports = {
                srcSet: "https://v1.bundlecdn.com/img/phonepe_order.f67f6453f-200.png 200w,https://v1.bundlecdn.com/img/phonepe_order.927b5f517-300.png 300w,https://v1.bundlecdn.com/img/phonepe_order.44a655a9e-375.png 375w",
                images: [{
                    path: "https://v1.bundlecdn.com/img/phonepe_order.f67f6453f-200.png",
                    width: 200,
                    height: 390
                }, {
                    path: "https://v1.bundlecdn.com/img/phonepe_order.927b5f517-300.png",
                    width: 300,
                    height: 585
                }, {
                    path: "https://v1.bundlecdn.com/img/phonepe_order.44a655a9e-375.png",
                    width: 375,
                    height: 731
                }],
                src: "https://v1.bundlecdn.com/img/phonepe_order.44a655a9e-375.png",
                toString: function() {
                    return "https://v1.bundlecdn.com/img/phonepe_order.44a655a9e-375.png"
                },
                width: 375,
                height: 731
            }
        },
        236962: t => {
            t.exports = {
                srcSet: "https://v1.bundlecdn.com/img/phonepe_order.83c42850a-200.webp 200w,https://v1.bundlecdn.com/img/phonepe_order.f966a5c36-300.webp 300w,https://v1.bundlecdn.com/img/phonepe_order.e87373590-375.webp 375w",
                images: [{
                    path: "https://v1.bundlecdn.com/img/phonepe_order.83c42850a-200.webp",
                    width: 200,
                    height: 390
                }, {
                    path: "https://v1.bundlecdn.com/img/phonepe_order.f966a5c36-300.webp",
                    width: 300,
                    height: 585
                }, {
                    path: "https://v1.bundlecdn.com/img/phonepe_order.e87373590-375.webp",
                    width: 375,
                    height: 731
                }],
                src: "https://v1.bundlecdn.com/img/phonepe_order.e87373590-375.webp",
                toString: function() {
                    return "https://v1.bundlecdn.com/img/phonepe_order.e87373590-375.webp"
                },
                width: 375,
                height: 731
            }
        },
        681319: t => {
            t.exports = {
                srcSet: "https://v1.bundlecdn.com/img/upi_id.fc3ba2b4d-200.png 200w,https://v1.bundlecdn.com/img/upi_id.ed36de3c4-300.png 300w,https://v1.bundlecdn.com/img/upi_id.d103b498d-400.png 400w,https://v1.bundlecdn.com/img/upi_id.8197912c0-502.png 502w",
                images: [{
                    path: "https://v1.bundlecdn.com/img/upi_id.fc3ba2b4d-200.png",
                    width: 200,
                    height: 179
                }, {
                    path: "https://v1.bundlecdn.com/img/upi_id.ed36de3c4-300.png",
                    width: 300,
                    height: 269
                }, {
                    path: "https://v1.bundlecdn.com/img/upi_id.d103b498d-400.png",
                    width: 400,
                    height: 359
                }, {
                    path: "https://v1.bundlecdn.com/img/upi_id.8197912c0-502.png",
                    width: 502,
                    height: 450
                }],
                src: "https://v1.bundlecdn.com/img/upi_id.8197912c0-502.png",
                toString: function() {
                    return "https://v1.bundlecdn.com/img/upi_id.8197912c0-502.png"
                },
                width: 502,
                height: 450
            }
        },
        643311: t => {
            t.exports = {
                srcSet: "https://v1.bundlecdn.com/img/upi_id.4c71124ed-200.webp 200w,https://v1.bundlecdn.com/img/upi_id.a95a80314-300.webp 300w,https://v1.bundlecdn.com/img/upi_id.5317a1169-400.webp 400w,https://v1.bundlecdn.com/img/upi_id.65cf36914-502.webp 502w",
                images: [{
                    path: "https://v1.bundlecdn.com/img/upi_id.4c71124ed-200.webp",
                    width: 200,
                    height: 179
                }, {
                    path: "https://v1.bundlecdn.com/img/upi_id.a95a80314-300.webp",
                    width: 300,
                    height: 269
                }, {
                    path: "https://v1.bundlecdn.com/img/upi_id.5317a1169-400.webp",
                    width: 400,
                    height: 359
                }, {
                    path: "https://v1.bundlecdn.com/img/upi_id.65cf36914-502.webp",
                    width: 502,
                    height: 450
                }],
                src: "https://v1.bundlecdn.com/img/upi_id.65cf36914-502.webp",
                toString: function() {
                    return "https://v1.bundlecdn.com/img/upi_id.65cf36914-502.webp"
                },
                width: 502,
                height: 450
            }
        },
        872853: t => {
            t.exports = {
                srcSet: "https://v1.bundlecdn.com/img/upi_order.70751b268-200.png 200w,https://v1.bundlecdn.com/img/upi_order.cb10186e6-300.png 300w,https://v1.bundlecdn.com/img/upi_order.725772616-375.png 375w",
                images: [{
                    path: "https://v1.bundlecdn.com/img/upi_order.70751b268-200.png",
                    width: 200,
                    height: 390
                }, {
                    path: "https://v1.bundlecdn.com/img/upi_order.cb10186e6-300.png",
                    width: 300,
                    height: 585
                }, {
                    path: "https://v1.bundlecdn.com/img/upi_order.725772616-375.png",
                    width: 375,
                    height: 731
                }],
                src: "https://v1.bundlecdn.com/img/upi_order.725772616-375.png",
                toString: function() {
                    return "https://v1.bundlecdn.com/img/upi_order.725772616-375.png"
                },
                width: 375,
                height: 731
            }
        },
        491967: t => {
            t.exports = {
                srcSet: "https://v1.bundlecdn.com/img/upi_order.9a48140e5-200.webp 200w,https://v1.bundlecdn.com/img/upi_order.d572c4fe5-300.webp 300w,https://v1.bundlecdn.com/img/upi_order.394688080-375.webp 375w",
                images: [{
                    path: "https://v1.bundlecdn.com/img/upi_order.9a48140e5-200.webp",
                    width: 200,
                    height: 390
                }, {
                    path: "https://v1.bundlecdn.com/img/upi_order.d572c4fe5-300.webp",
                    width: 300,
                    height: 585
                }, {
                    path: "https://v1.bundlecdn.com/img/upi_order.394688080-375.webp",
                    width: 375,
                    height: 731
                }],
                src: "https://v1.bundlecdn.com/img/upi_order.394688080-375.webp",
                toString: function() {
                    return "https://v1.bundlecdn.com/img/upi_order.394688080-375.webp"
                },
                width: 375,
                height: 731
            }
        },
        217710: t => {
            t.exports = {
                srcSet: "https://v1.bundlecdn.com/img/whatsapp.dd9a4a9ce-200.png 200w,https://v1.bundlecdn.com/img/whatsapp.d5cfae0fb-300.png 300w,https://v1.bundlecdn.com/img/whatsapp.e8ef90ea5-360.png 360w",
                images: [{
                    path: "https://v1.bundlecdn.com/img/whatsapp.dd9a4a9ce-200.png",
                    width: 200,
                    height: 369
                }, {
                    path: "https://v1.bundlecdn.com/img/whatsapp.d5cfae0fb-300.png",
                    width: 300,
                    height: 554
                }, {
                    path: "https://v1.bundlecdn.com/img/whatsapp.e8ef90ea5-360.png",
                    width: 360,
                    height: 665
                }],
                src: "https://v1.bundlecdn.com/img/whatsapp.e8ef90ea5-360.png",
                toString: function() {
                    return "https://v1.bundlecdn.com/img/whatsapp.e8ef90ea5-360.png"
                },
                width: 360,
                height: 665
            }
        },
        599711: t => {
            t.exports = {
                srcSet: "https://v1.bundlecdn.com/img/whatsapp.3cc5fae0e-200.webp 200w,https://v1.bundlecdn.com/img/whatsapp.f6f653ca7-300.webp 300w,https://v1.bundlecdn.com/img/whatsapp.cde97a1c2-360.webp 360w",
                images: [{
                    path: "https://v1.bundlecdn.com/img/whatsapp.3cc5fae0e-200.webp",
                    width: 200,
                    height: 369
                }, {
                    path: "https://v1.bundlecdn.com/img/whatsapp.f6f653ca7-300.webp",
                    width: 300,
                    height: 554
                }, {
                    path: "https://v1.bundlecdn.com/img/whatsapp.cde97a1c2-360.webp",
                    width: 360,
                    height: 665
                }],
                src: "https://v1.bundlecdn.com/img/whatsapp.cde97a1c2-360.webp",
                toString: function() {
                    return "https://v1.bundlecdn.com/img/whatsapp.cde97a1c2-360.webp"
                },
                width: 360,
                height: 665
            }
        }
    }
]);