"use strict";
(self["webpackChunk_1win_frontend_main"] = self["webpackChunk_1win_frontend_main"] || []).push([
    [99226], {
        299226: (n, r, t) => {
            t.r(r), t.d(r, {
                default: () => i
            });
            var e = t(166252);

            function s(n, r) {
                return (0, e.wg)(), (0, e.iD)("svg", (0, e.dG)({
                    xmlns: "http://www.w3.org/2000/svg",
                    viewBox: "0 0 128 512"
                }, n.$attrs), r[0] || (r[0] = [(0, e._)("path", {
                    fill: "currentColor",
                    d: "M64 208c26.5 0 48 21.5 48 48s-21.5 48-48 48-48-21.5-48-48 21.5-48 48-48zM16 104c0 26.5 21.5 48 48 48s48-21.5 48-48-21.5-48-48-48-48 21.5-48 48zm0 304c0 26.5 21.5 48 48 48s48-21.5 48-48-21.5-48-48-48-48 21.5-48 48z"
                }, null, -1)]), 16)
            }
            var w = t(983744);
            const a = {},
                c = (0, w.Z)(a, [
                    ["render", s]
                ]),
                i = c
        }
    }
]);