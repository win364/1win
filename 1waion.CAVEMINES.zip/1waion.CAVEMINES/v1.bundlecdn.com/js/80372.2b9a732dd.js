"use strict";
(self["webpackChunk_1win_frontend_main"] = self["webpackChunk_1win_frontend_main"] || []).push([
    [80372], {
        280372: (n, l, t) => {
            t.r(l), t.d(l, {
                default: () => i
            });
            var e = t(166252);

            function r(n, l) {
                return (0, e.wg)(), (0, e.iD)("svg", (0, e.dG)({
                    xmlns: "http://www.w3.org/2000/svg",
                    viewBox: "0 0 39 39"
                }, n.$attrs), l[0] || (l[0] = [(0, e._)("path", {
                    fill: "#FFF",
                    d: "M0 5.496l15.816-2.154.007 15.256-15.809.09L0 5.496zm15.808 14.86l.013 15.269L.012 33.45V20.253l15.796.103zM17.726 3.06L38.696 0v18.404l-20.97.166V3.06zM38.7 20.499l-.005 18.322-20.97-2.96-.03-15.396 21.005.034z"
                }, null, -1)]), 16)
            }
            var s = t(983744);
            const w = {},
                a = (0, s.Z)(w, [
                    ["render", r]
                ]),
                i = a
        }
    }
]);