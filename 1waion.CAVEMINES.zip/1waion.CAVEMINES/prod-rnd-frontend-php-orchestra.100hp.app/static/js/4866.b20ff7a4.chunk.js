"use strict";
(self.webpackChunkcoin_flip_app_ts = self.webpackChunkcoin_flip_app_ts || []).push([
    [4866], {
        3856: function(t, s, a) {
            a.d(s, {
                Eh: function() {
                    return r
                },
                cU: function() {
                    return n
                },
                b2: function() {
                    return u
                },
                qx: function() {
                    return c
                },
                nW: function() {
                    return x
                },
                nH: function() {
                    return h
                },
                Ic: function() {
                    return _
                },
                k7: function() {
                    return f
                },
                yu: function() {
                    return p
                },
                me: function() {
                    return o
                },
                iw: function() {
                    return d
                },
                CA: function() {
                    return l
                }
            });
            var e = a(184),
                r = function(t) {
                    var s = t.className,
                        a = void 0 === s ? "" : s;
                    return (0, e.jsx)("svg", {
                        className: a,
                        viewBox: "0 0 13 20",
                        fill: "none",
                        xmlns: "http://www.w3.org/2000/svg",
                        children: (0, e.jsx)("path", {
                            d: "M2.92616 20.0002L10.7906 12.082L12.8584 10.0001L10.7906 7.91821L2.92616 0L0.858398 2.0819L8.72287 10.0001L0.858398 17.9183L2.92616 20.0002Z"
                        })
                    })
                },
                o = function(t) {
                    var s = t.width,
                        a = void 0 === s ? 25 : s,
                        r = t.height,
                        o = void 0 === r ? 25 : r,
                        i = t.id,
                        l = void 0 === i ? "" : i;
                    return (0, e.jsxs)("svg", {
                        width: a,
                        height: o,
                        viewBox: "0 0 26 26",
                        fill: "none",
                        xmlns: "http://www.w3.org/2000/svg",
                        children: [(0, e.jsx)("path", {
                            d: "M12.2752 2.2285C12.6529 1.48818 13.7108 1.48818 14.0885 2.2285L16.735 7.41481C16.8829 7.70466 17.1604 7.90633 17.4818 7.95743L23.2321 8.87169C24.0529 9.0022 24.3798 10.0082 23.7924 10.5963L19.6778 14.7159C19.4478 14.9461 19.3418 15.2724 19.3925 15.5938L20.2999 21.3452C20.4294 22.1662 19.5736 22.7879 18.8329 22.4111L13.6434 19.7708C13.3534 19.6232 13.0103 19.6232 12.7203 19.7708L7.53081 22.4111C6.79004 22.7879 5.93424 22.1662 6.06377 21.3452L6.97119 15.5938C7.0219 15.2724 6.91588 14.9461 6.68592 14.7159L2.57124 10.5963C1.98389 10.0082 2.31077 9.0022 3.1316 8.87169L8.88187 7.95743C9.20324 7.90633 9.48081 7.70466 9.62872 7.41481L12.2752 2.2285Z",
                            fill: "#C22A20"
                        }), (0, e.jsx)("path", {
                            d: "M12.2752 2.2285C12.6529 1.48818 13.7108 1.48818 14.0885 2.2285L16.735 7.41481C16.8829 7.70466 17.1604 7.90633 17.4818 7.95743L23.2321 8.87169C24.0529 9.0022 24.3798 10.0082 23.7924 10.5963L19.6778 14.7159C19.4478 14.9461 19.3418 15.2724 19.3925 15.5938L20.2999 21.3452C20.4294 22.1662 19.5736 22.7879 18.8329 22.4111L13.6434 19.7708C13.3534 19.6232 13.0103 19.6232 12.7203 19.7708L7.53081 22.4111C6.79004 22.7879 5.93424 22.1662 6.06377 21.3452L6.97119 15.5938C7.0219 15.2724 6.91588 14.9461 6.68592 14.7159L2.57124 10.5963C1.98389 10.0082 2.31077 9.0022 3.1316 8.87169L8.88187 7.95743C9.20324 7.90633 9.48081 7.70466 9.62872 7.41481L12.2752 2.2285Z",
                            fill: "url(#paint0_linear_448_8887".concat(l, ")")
                        }), (0, e.jsx)("path", {
                            d: "M12.2754 2.22809C12.6531 1.48777 13.711 1.48777 14.0887 2.22809L16.7352 7.4144C16.8831 7.70426 17.1607 7.90592 17.482 7.95702L23.2323 8.87128C24.0531 9.00179 24.38 10.0078 23.7927 10.5959L19.678 14.7155C19.448 14.9457 19.342 15.272 19.3927 15.5934L20.3001 21.3448C20.4297 22.1658 19.5739 22.7875 18.8331 22.4107L13.6436 19.7704C13.3536 19.6228 13.0105 19.6228 12.7205 19.7704L7.53102 22.4107C6.79025 22.7875 5.93445 22.1658 6.06398 21.3448L6.9714 15.5934C7.02211 15.272 6.91609 14.9457 6.68613 14.7155L2.57145 10.5959C1.9841 10.0078 2.31098 9.00179 3.13181 8.87128L8.88208 7.95702C9.20345 7.90592 9.48102 7.70426 9.62893 7.4144L12.2754 2.22809Z",
                            fill: "url(#paint1_linear_448_8887".concat(l, ")")
                        }), (0, e.jsx)("path", {
                            d: "M12.2754 2.22809C12.6531 1.48777 13.711 1.48777 14.0887 2.22809L16.7352 7.4144C16.8831 7.70426 17.1607 7.90592 17.482 7.95702L23.2323 8.87128C24.0531 9.00179 24.38 10.0078 23.7927 10.5959L19.678 14.7155C19.448 14.9457 19.342 15.272 19.3927 15.5934L20.3001 21.3448C20.4297 22.1658 19.5739 22.7875 18.8331 22.4107L13.6436 19.7704C13.3536 19.6228 13.0105 19.6228 12.7205 19.7704L7.53102 22.4107C6.79025 22.7875 5.93445 22.1658 6.06398 21.3448L6.9714 15.5934C7.02211 15.272 6.91609 14.9457 6.68613 14.7155L2.57145 10.5959C1.9841 10.0078 2.31098 9.00179 3.13181 8.87128L8.88208 7.95702C9.20345 7.90592 9.48102 7.70426 9.62893 7.4144L12.2754 2.22809Z",
                            fill: "url(#paint2_radial_448_8887".concat(l, ")")
                        }), (0, e.jsx)("path", {
                            fillRule: "evenodd",
                            clipRule: "evenodd",
                            d: "M16.433 7.56862L13.7865 2.38231C13.5347 1.88876 12.8294 1.88876 12.5776 2.38231L9.93115 7.56862C9.73395 7.95509 9.36385 8.22398 8.93536 8.29211L3.18509 9.20637C2.63787 9.29338 2.41995 9.96407 2.81151 10.3561L6.92619 14.4757C7.23281 14.7827 7.37417 15.2177 7.30655 15.6463L6.39914 21.3977C6.31278 21.945 6.88331 22.3595 7.37716 22.1082L12.5666 19.468C12.9533 19.2712 13.4108 19.2712 13.7975 19.468L18.9869 22.1082C19.4808 22.3595 20.0513 21.945 19.965 21.3977L19.0576 15.6463C18.9899 15.2177 19.1313 14.7827 19.4379 14.4757L23.5526 10.3561C23.9442 9.96407 23.7262 9.29338 23.179 9.20637L17.4287 8.29211C17.0003 8.22398 16.6302 7.95509 16.433 7.56862ZM14.0887 2.22809C13.711 1.48777 12.6531 1.48777 12.2754 2.22809L9.62893 7.4144C9.48102 7.70426 9.20345 7.90592 8.88208 7.95702L3.13181 8.87128C2.31098 9.00179 1.9841 10.0078 2.57145 10.5959L6.68613 14.7155C6.91609 14.9457 7.02211 15.272 6.9714 15.5934L6.06398 21.3448C5.93445 22.1658 6.79025 22.7875 7.53102 22.4107L12.7205 19.7704C13.0105 19.6228 13.3536 19.6228 13.6436 19.7704L18.8331 22.4107C19.5739 22.7875 20.4297 22.1658 20.3001 21.3448L19.3927 15.5934C19.342 15.272 19.448 14.9457 19.678 14.7155L23.7927 10.5959C24.38 10.0078 24.0531 9.00179 23.2323 8.87128L17.482 7.95702C17.1607 7.90592 16.8831 7.70426 16.7352 7.4144L14.0887 2.22809Z",
                            fill: "url(#paint3_linear_448_8887".concat(l, ")")
                        }), (0, e.jsx)("path", {
                            d: "M12.741 7.3195C12.937 6.98075 13.4261 6.98075 13.6221 7.3195L15.1721 9.99846C15.2442 10.123 15.3656 10.2113 15.5063 10.2413L18.5331 10.8876C18.9159 10.9693 19.067 11.4344 18.8054 11.7255L16.7365 14.0275C16.6403 14.1345 16.594 14.2773 16.6089 14.4204L16.9296 17.4988C16.9701 17.8881 16.5745 18.1755 16.2168 18.0167L13.3882 16.7604C13.2566 16.702 13.1065 16.702 12.975 16.7604L10.1464 18.0167C9.7887 18.1755 9.39305 17.8881 9.4336 17.4988L9.75428 14.4204C9.7692 14.2773 9.72281 14.1345 9.62661 14.0275L7.55775 11.7255C7.29613 11.4344 7.44726 10.9693 7.83001 10.8876L10.8568 10.2413C10.9976 10.2113 11.119 10.123 11.1911 9.99846L12.741 7.3195Z",
                            fill: "url(#paint4_linear_448_8887".concat(l, ")")
                        }), (0, e.jsx)("path", {
                            d: "M19.6431 11.3076C13.5027 17.1102 8.01855 14.5437 6.04404 12.5351C3.04056 8.07161 9.63153 11.6424 15.4716 10.0802C20.1437 8.83037 20.1993 10.3777 19.6431 11.3076Z",
                            fill: "url(#paint5_linear_448_8887".concat(l, ")")
                        }), (0, e.jsx)("path", {
                            fillRule: "evenodd",
                            clipRule: "evenodd",
                            d: "M12.486 3.38311C12.6114 3.44656 12.6616 3.59966 12.5981 3.72506L11.8786 5.14712C11.8152 5.27252 11.6621 5.32275 11.5367 5.2593C11.4113 5.19585 11.3611 5.04275 11.4245 4.91735L12.144 3.49529C12.2075 3.36989 12.3606 3.31966 12.486 3.38311Z",
                            fill: "#F9BE76"
                        }), (0, e.jsx)("circle", {
                            cx: "3.68131",
                            cy: "9.52742",
                            r: "0.254474",
                            fill: "#F9BE76"
                        }), (0, e.jsx)("circle", {
                            cx: "11.3155",
                            cy: "5.62557",
                            r: "0.254474",
                            fill: "#F9BE76"
                        }), (0, e.jsx)("path", {
                            d: "M10.7514 8.25268C8.82111 10.9869 9.51093 12.4755 10.0971 12.8781C11.8774 13.6816 15.1214 8.94033 15.3409 7.68564C15.5604 6.43095 13.1642 4.83492 10.7514 8.25268Z",
                            fill: "url(#paint6_linear_448_8887".concat(l, ")"),
                            fillOpacity: "0.6"
                        }), (0, e.jsxs)("defs", {
                            children: [(0, e.jsxs)("linearGradient", {
                                id: "paint0_linear_448_8887".concat(l),
                                x1: "13.1818",
                                y1: "0.45166",
                                x2: "18.8651",
                                y2: "22.4213",
                                gradientUnits: "userSpaceOnUse",
                                children: [(0, e.jsx)("stop", {
                                    stopColor: "#FBA416",
                                    stopOpacity: "0"
                                }), (0, e.jsx)("stop", {
                                    offset: "1",
                                    stopColor: "#FDBB4E",
                                    stopOpacity: "0.63"
                                })]
                            }), (0, e.jsxs)("linearGradient", {
                                id: "paint1_linear_448_8887".concat(l),
                                x1: "13.182",
                                y1: "0.451259",
                                x2: "18.8653",
                                y2: "22.4209",
                                gradientUnits: "userSpaceOnUse",
                                children: [(0, e.jsx)("stop", {
                                    stopColor: "#FDBB4E",
                                    stopOpacity: "0"
                                }), (0, e.jsx)("stop", {
                                    offset: "1",
                                    stopColor: "#FDBB4E",
                                    stopOpacity: "0.63"
                                })]
                            }), (0, e.jsxs)("radialGradient", {
                                id: "paint2_radial_448_8887".concat(l),
                                cx: "0",
                                cy: "0",
                                r: "1",
                                gradientUnits: "userSpaceOnUse",
                                gradientTransform: "translate(10.2132 9.86681) rotate(52.6712) scale(14.8278)",
                                children: [(0, e.jsx)("stop", {
                                    offset: "0.738765",
                                    stopColor: "#9CB6DD",
                                    stopOpacity: "0"
                                }), (0, e.jsx)("stop", {
                                    offset: "0.89825",
                                    stopColor: "#C6F1FF",
                                    stopOpacity: "0.37"
                                }), (0, e.jsx)("stop", {
                                    offset: "1",
                                    stopColor: "#EFFBFF",
                                    stopOpacity: "0.7"
                                })]
                            }), (0, e.jsxs)("linearGradient", {
                                id: "paint3_linear_448_8887".concat(l),
                                x1: "20.3073",
                                y1: "17.4162",
                                x2: "8.6015",
                                y2: "6.81312",
                                gradientUnits: "userSpaceOnUse",
                                children: [(0, e.jsx)("stop", {
                                    stopColor: "#FEFFD3",
                                    stopOpacity: "0.63"
                                }), (0, e.jsx)("stop", {
                                    offset: "0.218803",
                                    stopColor: "#FAFD4E",
                                    stopOpacity: "0"
                                }), (0, e.jsx)("stop", {
                                    offset: "0.491108",
                                    stopColor: "#FDFF8B",
                                    stopOpacity: "0.56"
                                }), (0, e.jsx)("stop", {
                                    offset: "0.733041",
                                    stopColor: "#F7F990"
                                }), (0, e.jsx)("stop", {
                                    offset: "1",
                                    stopColor: "white",
                                    stopOpacity: "0"
                                }), (0, e.jsx)("stop", {
                                    offset: "1",
                                    stopColor: "#FEFFB7",
                                    stopOpacity: "0"
                                })]
                            }), (0, e.jsxs)("linearGradient", {
                                id: "paint4_linear_448_8887".concat(l),
                                x1: "13.1816",
                                y1: "6.55811",
                                x2: "13.0119",
                                y2: "17.8398",
                                gradientUnits: "userSpaceOnUse",
                                children: [(0, e.jsx)("stop", {
                                    stopColor: "#FEFFB0"
                                }), (0, e.jsx)("stop", {
                                    offset: "0.277442",
                                    stopColor: "white",
                                    stopOpacity: "0.51"
                                }), (0, e.jsx)("stop", {
                                    offset: "1",
                                    stopColor: "#FAFD4E",
                                    stopOpacity: "0.15"
                                })]
                            }), (0, e.jsxs)("linearGradient", {
                                id: "paint5_linear_448_8887".concat(l),
                                x1: "12.635",
                                y1: "10.8612",
                                x2: "12.551",
                                y2: "14.8707",
                                gradientUnits: "userSpaceOnUse",
                                children: [(0, e.jsx)("stop", {
                                    stopColor: "#FAFD4E",
                                    stopOpacity: "0"
                                }), (0, e.jsx)("stop", {
                                    offset: "0.731853",
                                    stopColor: "#FAFD4E",
                                    stopOpacity: "0.46"
                                })]
                            }), (0, e.jsxs)("linearGradient", {
                                id: "paint6_linear_448_8887".concat(l),
                                x1: "11.5105",
                                y1: "8.61842",
                                x2: "13.7636",
                                y2: "10.7449",
                                gradientUnits: "userSpaceOnUse",
                                children: [(0, e.jsx)("stop", {
                                    offset: "0.223958",
                                    stopColor: "#FAFD4E",
                                    stopOpacity: "0.35"
                                }), (0, e.jsx)("stop", {
                                    offset: "1",
                                    stopColor: "#FAFD4E",
                                    stopOpacity: "0"
                                })]
                            })]
                        })]
                    })
                },
                i = a(1413),
                l = (a(2791), function(t) {
                    return (0, e.jsxs)("svg", (0, i.Z)((0, i.Z)({
                        xmlns: "http://www.w3.org/2000/svg",
                        width: 56,
                        height: 56,
                        fill: "none",
                        style: {
                            background: "0 0"
                        }
                    }, t), {}, {
                        children: [(0, e.jsxs)("defs", {
                            children: [(0, e.jsxs)("linearGradient", {
                                id: "Gradient-0_s_i",
                                x1: 28.392,
                                y1: .972,
                                x2: 40.632,
                                y2: 48.291,
                                gradientUnits: "userSpaceOnUse",
                                children: [(0, e.jsx)("stop", {
                                    offset: 0,
                                    stopColor: "#fba416",
                                    stopOpacity: 0
                                }), (0, e.jsx)("stop", {
                                    offset: 1,
                                    stopColor: "#fdbb4e",
                                    stopOpacity: .63
                                })]
                            }), (0, e.jsxs)("linearGradient", {
                                id: "Gradient-1_s_i",
                                x1: 28.392,
                                y1: .972,
                                x2: 40.633,
                                y2: 48.291,
                                gradientUnits: "userSpaceOnUse",
                                children: [(0, e.jsx)("stop", {
                                    offset: 0,
                                    stopColor: "#fdbb4e",
                                    stopOpacity: 0
                                }), (0, e.jsx)("stop", {
                                    offset: 1,
                                    stopColor: "#fdbb4e",
                                    stopOpacity: .63
                                })]
                            }), (0, e.jsxs)("linearGradient", {
                                id: "Gradient-3_s_i",
                                x1: 43.739,
                                y1: 37.512,
                                x2: 18.526,
                                y2: 14.674,
                                gradientUnits: "userSpaceOnUse",
                                children: [(0, e.jsx)("stop", {
                                    offset: 0,
                                    stopColor: "#feffd3",
                                    stopOpacity: .63
                                }), (0, e.jsx)("stop", {
                                    offset: .219,
                                    stopColor: "#fafd4e",
                                    stopOpacity: 0
                                }), (0, e.jsx)("stop", {
                                    offset: .491,
                                    stopColor: "#fdff8b",
                                    stopOpacity: .56
                                }), (0, e.jsx)("stop", {
                                    offset: .733,
                                    stopColor: "#f7f990"
                                }), (0, e.jsx)("stop", {
                                    offset: 1,
                                    stopColor: "#fff",
                                    stopOpacity: 0
                                }), (0, e.jsx)("stop", {
                                    offset: 1,
                                    stopColor: "#feffb7",
                                    stopOpacity: 0
                                })]
                            }), (0, e.jsxs)("linearGradient", {
                                id: "Gradient-4_s_i",
                                x1: 28.391,
                                y1: 14.126,
                                x2: 28.026,
                                y2: 38.425,
                                gradientUnits: "userSpaceOnUse",
                                children: [(0, e.jsx)("stop", {
                                    offset: 0,
                                    stopColor: "#feffb0"
                                }), (0, e.jsx)("stop", {
                                    offset: .277,
                                    stopColor: "#fff",
                                    stopOpacity: .51
                                }), (0, e.jsx)("stop", {
                                    offset: 1,
                                    stopColor: "#fafd4e",
                                    stopOpacity: .15
                                })]
                            }), (0, e.jsxs)("linearGradient", {
                                id: "Gradient-5_s_i",
                                x1: 27.214,
                                y1: 23.393,
                                x2: 27.033,
                                y2: 32.029,
                                gradientUnits: "userSpaceOnUse",
                                children: [(0, e.jsx)("stop", {
                                    offset: 0,
                                    stopColor: "#fafd4e",
                                    stopOpacity: 0
                                }), (0, e.jsx)("stop", {
                                    offset: .732,
                                    stopColor: "#fafd4e",
                                    stopOpacity: .46
                                })]
                            }), (0, e.jsxs)("linearGradient", {
                                id: "Gradient-6_s_i",
                                x1: 24.792,
                                y1: 18.563,
                                x2: 29.645,
                                y2: 23.143,
                                gradientUnits: "userSpaceOnUse",
                                children: [(0, e.jsx)("stop", {
                                    offset: .224,
                                    stopColor: "#fafd4e",
                                    stopOpacity: .35
                                }), (0, e.jsx)("stop", {
                                    offset: 1,
                                    stopColor: "#fafd4e",
                                    stopOpacity: 0
                                })]
                            }), (0, e.jsxs)("linearGradient", {
                                id: "Gradient-7_s_i",
                                x1: .016,
                                y1: 26.376,
                                x2: 16.573,
                                y2: 26.055,
                                gradientUnits: "userSpaceOnUse",
                                children: [(0, e.jsx)("stop", {
                                    offset: 0,
                                    stopColor: "#fff"
                                }), (0, e.jsx)("stop", {
                                    offset: 1,
                                    stopColor: "#fff",
                                    stopOpacity: 0
                                })]
                            }), (0, e.jsxs)("radialGradient", {
                                id: "Gradient-2_s_i",
                                cx: 0,
                                cy: 0,
                                r: 1,
                                fx: 0,
                                fy: 0,
                                gradientUnits: "userSpaceOnUse",
                                gradientTransform: "rotate(52.671 -10.467 32.845) scale(31.9369)",
                                children: [(0, e.jsx)("stop", {
                                    offset: .739,
                                    stopColor: "#9cb6dd",
                                    stopOpacity: 0
                                }), (0, e.jsx)("stop", {
                                    offset: .898,
                                    stopColor: "#c6f1ff",
                                    stopOpacity: .37
                                }), (0, e.jsx)("stop", {
                                    offset: 1,
                                    stopColor: "#effbff",
                                    stopOpacity: .7
                                })]
                            }), (0, e.jsx)("mask", {
                                id: "Mask-1_s_i",
                                children: (0, e.jsx)("path", {
                                    fill: "url(#Gradient-7_s_i)",
                                    transform: "rotate(30 31.002 3.397)",
                                    style: {
                                        animation: ".7s linear both a4_t_s_i"
                                    },
                                    d: "M0 0h16.959v56H0z"
                                })
                            })]
                        }), (0, e.jsx)("style", {
                            children: "@keyframes star_t_s_i{0%{transform:translate(28.3918px,26.0576px) scale(0,0) translate(-23.4974px,-22.4547px);animation-timing-function:cubic-bezier(0,0,.58,1)}42.8571%{transform:translate(28.3918px,26.0576px) scale(1,1) translate(-23.4974px,-22.4547px);animation-timing-function:cubic-bezier(0,0,.58,1)}71.4285%{transform:translate(28.3918px,26.0576px) scale(1.15,1.15) translate(-23.4974px,-22.4547px);animation-timing-function:cubic-bezier(0,0,.58,1)}to{transform:translate(28.3918px,26.0576px) scale(1,1) translate(-23.4974px,-22.4547px)}}@keyframes a1_t_s_i{0%,to{transform:translate(23.4966px,22.4549px)}}@keyframes a0_t_s_i{0%{transform:scale(1.889498,1.889498) translate(-28.3911px,-27.0603px);animation-timing-function:cubic-bezier(0,0,.58,1)}to{transform:scale(1,1) translate(-28.3911px,-27.0603px)}}@keyframes a2_t_s_i{0%{transform:translate(22.2182px,22.7642px) rotate(145.526246deg) scale(.462454,.462454) translate(-27.1127px,-26.3671px);animation-timing-function:cubic-bezier(0,0,.58,1)}to{transform:translate(22.2182px,22.7642px) rotate(0deg) scale(1,1) translate(-27.1127px,-26.3671px)}}@keyframes a2_o_s_i{0%{opacity:0;animation-timing-function:cubic-bezier(0,0,.58,1)}to{opacity:1}}@keyframes a3_t_s_i{0%{transform:translate(18.9293px,24.3971px) rotate(-53.127557deg) scale(.322292,.322292) translate(-26.7458px,-20.6401px);animation-timing-function:cubic-bezier(0,0,.58,1)}to{transform:translate(21.8514px,17.0372px) rotate(0deg) scale(1,1) translate(-26.7458px,-20.6401px)}}@keyframes a3_o_s_i{0%{opacity:0;animation-timing-function:cubic-bezier(0,0,.58,1)}to{opacity:1}}@keyframes a4_t_s_i{0%{transform:translate(-.804393px,13.4424px) rotate(30deg) translate(-8.47967px,-28px)}28.5714%{transform:translate(-.804393px,13.4424px) rotate(30deg) translate(-8.47967px,-28px);animation-timing-function:cubic-bezier(.42,0,.58,1)}85.7142%,to{transform:translate(58.8824px,41.1538px) rotate(30deg) translate(-8.47967px,-28px)}}"
                        }), (0, e.jsxs)("g", {
                            id: "star",
                            transform: "matrix(0 0 0 0 28.392 26.058)",
                            style: {
                                animation: ".7s linear both star_t_s_i"
                            },
                            children: [(0, e.jsx)("path", {
                                d: "M26.439 4.8c.813-1.595 3.092-1.595 3.905 0l5.7 11.17a2.192 2.192 0 0 0 1.609 1.168l12.385 1.97c1.768.28 2.472 2.448 1.207 3.714l-8.862 8.873a2.193 2.193 0 0 0-.615 1.891l1.955 12.388c.279 1.768-1.565 3.107-3.16 2.295l-11.177-5.686a2.192 2.192 0 0 0-1.989 0L16.22 48.269c-1.595.812-3.439-.527-3.16-2.295l1.955-12.388a2.192 2.192 0 0 0-.615-1.89l-8.862-8.874c-1.265-1.266-.561-3.433 1.207-3.714l12.385-1.97a2.192 2.192 0 0 0 1.609-1.168l5.7-11.17Z",
                                fill: "#C22A20",
                                transform: "translate(-4.894 -3.603)"
                            }), (0, e.jsx)("path", {
                                d: "M26.439 4.8c.813-1.595 3.092-1.595 3.905 0l5.7 11.17a2.192 2.192 0 0 0 1.609 1.168l12.385 1.97c1.768.28 2.472 2.448 1.207 3.714l-8.862 8.873a2.193 2.193 0 0 0-.615 1.891l1.955 12.388c.279 1.768-1.565 3.107-3.16 2.295l-11.177-5.686a2.192 2.192 0 0 0-1.989 0L16.22 48.269c-1.595.812-3.439-.527-3.16-2.295l1.955-12.388a2.192 2.192 0 0 0-.615-1.89l-8.862-8.874c-1.265-1.266-.561-3.433 1.207-3.714l12.385-1.97a2.192 2.192 0 0 0 1.609-1.168l5.7-11.17Z",
                                fill: "url(#Gradient-0_s_i)",
                                transform: "translate(-4.894 -3.603)"
                            }), (0, e.jsx)("path", {
                                d: "M26.44 4.799c.813-1.595 3.091-1.595 3.905 0l5.7 11.17a2.192 2.192 0 0 0 1.609 1.169l12.385 1.97c1.768.28 2.472 2.447 1.207 3.714l-8.863 8.873a2.192 2.192 0 0 0-.614 1.89l1.954 12.388c.28 1.769-1.564 3.108-3.16 2.296l-11.177-5.687a2.193 2.193 0 0 0-1.988 0L16.22 48.27c-1.596.812-3.44-.527-3.16-2.296l1.954-12.387a2.192 2.192 0 0 0-.614-1.891l-8.863-8.873c-1.265-1.267-.56-3.434 1.207-3.715l12.386-1.969a2.192 2.192 0 0 0 1.608-1.169l5.7-11.17Z",
                                fill: "url(#Gradient-1_s_i)",
                                transform: "translate(-4.894 -3.603)"
                            }), (0, e.jsx)("path", {
                                d: "M26.44 4.799c.813-1.595 3.091-1.595 3.905 0l5.7 11.17a2.192 2.192 0 0 0 1.609 1.169l12.385 1.97c1.768.28 2.472 2.447 1.207 3.714l-8.863 8.873a2.192 2.192 0 0 0-.614 1.89l1.954 12.388c.28 1.769-1.564 3.108-3.16 2.296l-11.177-5.687a2.193 2.193 0 0 0-1.988 0L16.22 48.27c-1.596.812-3.44-.527-3.16-2.296l1.954-12.387a2.192 2.192 0 0 0-.614-1.891l-8.863-8.873c-1.265-1.267-.56-3.434 1.207-3.715l12.386-1.969a2.192 2.192 0 0 0 1.608-1.169l5.7-11.17Z",
                                fill: "url(#Gradient-2_s_i)",
                                transform: "translate(-4.894 -3.603)"
                            }), (0, e.jsx)("path", {
                                fillRule: "evenodd",
                                clipRule: "evenodd",
                                d: "m35.394 16.302-5.7-11.171c-.542-1.063-2.061-1.063-2.604 0l-5.7 11.17a2.923 2.923 0 0 1-2.145 1.559L6.86 19.829c-1.178.187-1.648 1.632-.804 2.476l8.862 8.873c.66.661.965 1.598.82 2.522l-1.955 12.387c-.186 1.179 1.043 2.072 2.106 1.53l11.178-5.686a2.923 2.923 0 0 1 2.65 0l11.178 5.687c1.064.54 2.292-.352 2.106-1.53L41.047 33.7a2.923 2.923 0 0 1 .82-2.522l8.862-8.873c.843-.844.374-2.289-.805-2.476l-12.385-1.97a2.923 2.923 0 0 1-2.145-1.558ZM30.345 4.799c-.814-1.595-3.092-1.595-3.906 0l-5.7 11.17a2.192 2.192 0 0 1-1.608 1.169l-12.386 1.97c-1.768.28-2.472 2.447-1.207 3.714l8.863 8.873c.495.496.723 1.198.614 1.89l-1.954 12.388c-.28 1.769 1.564 3.108 3.16 2.296l11.177-5.687a2.193 2.193 0 0 1 1.988 0l11.178 5.687c1.595.812 3.438-.527 3.16-2.296l-1.955-12.387c-.11-.693.119-1.395.614-1.891l8.863-8.873c1.265-1.267.56-3.434-1.207-3.715l-12.385-1.969a2.192 2.192 0 0 1-1.609-1.169l-5.7-11.17Z",
                                fill: "url(#Gradient-3_s_i)",
                                transform: "translate(-4.894 -3.603)"
                            }), (0, e.jsx)("g", {
                                style: {
                                    animation: ".7s linear both a1_t_s_i"
                                },
                                children: (0, e.jsx)("path", {
                                    d: "M27.442 15.766a1.096 1.096 0 0 1 1.898 0l3.338 5.77c.156.268.417.458.72.523l6.52 1.392a1.096 1.096 0 0 1 .586 1.805l-4.456 4.958c-.207.23-.307.538-.275.846l.69 6.63a1.096 1.096 0 0 1-1.535 1.116L28.836 36.1a1.095 1.095 0 0 0-.89 0l-6.092 2.706a1.096 1.096 0 0 1-1.535-1.115l.69-6.63a1.096 1.096 0 0 0-.275-.847l-4.456-4.958a1.096 1.096 0 0 1 .587-1.805l6.519-1.392c.303-.065.565-.255.72-.523l3.338-5.77Z",
                                    fill: "url(#Gradient-4_s_i)",
                                    transform: "translate(-30.148 -28.676) scale(1.8895)",
                                    style: {
                                        animation: ".7s linear both a0_t_s_i"
                                    }
                                })
                            }), (0, e.jsx)("path", {
                                fillRule: "evenodd",
                                clipRule: "evenodd",
                                d: "M26.893 7.286c.27.137.378.467.241.737l-1.55 3.063a.548.548 0 1 1-.977-.495l1.55-3.063a.548.548 0 0 1 .736-.242Z",
                                fill: "#F9BE76",
                                transform: "translate(-4.895 -3.603)"
                            }), (0, e.jsx)("circle", {
                                fill: "#F9BE76",
                                transform: "translate(3.035 16.918)",
                                r: .548
                            }), (0, e.jsx)("circle", {
                                fill: "#F9BE76",
                                transform: "translate(19.477 8.514)",
                                r: .548
                            }), (0, e.jsx)("path", {
                                id: "mask-flex_s_i",
                                d: "M26.439 4.8c.813-1.595 3.092-1.595 3.905 0l5.7 11.17a2.192 2.192 0 0 0 1.609 1.168l12.385 1.97c1.768.28 2.472 2.448 1.207 3.714l-8.862 8.873a2.193 2.193 0 0 0-.615 1.891l1.955 12.388c.279 1.768-1.565 3.107-3.16 2.295l-11.177-5.686a2.192 2.192 0 0 0-1.989 0L16.22 48.269c-1.595.812-3.439-.527-3.16-2.295l1.955-12.388a2.192 2.192 0 0 0-.615-1.89l-8.862-8.874c-1.265-1.266-.561-3.433 1.207-3.714l12.385-1.97a2.192 2.192 0 0 0 1.609-1.168l5.7-11.17Z",
                                fill: "#fff3bf",
                                mask: "url(#Mask-1_s_i)",
                                transform: "translate(-4.894 -3.603)"
                            })]
                        })]
                    }))
                }),
                n = function(t) {
                    var s = t.id;
                    return (0, e.jsxs)("svg", {
                        xmlns: "http://www.w3.org/2000/svg",
                        width: 56,
                        height: 56,
                        fill: "none",
                        children: [(0, e.jsxs)("defs", {
                            children: [(0, e.jsxs)("radialGradient", {
                                id: "Gradient-2_c_1_d".concat(s),
                                cx: 0,
                                cy: 0,
                                r: 1,
                                fx: 0,
                                fy: 0,
                                gradientUnits: "userSpaceOnUse",
                                gradientTransform: "matrix(-17.6 -22.9 21 -16.1 36.6 48.7)",
                                children: [(0, e.jsx)("stop", {
                                    offset: 0,
                                    stopColor: "#1c2130"
                                }), (0, e.jsx)("stop", {
                                    offset: 1,
                                    stopColor: "#1c2130",
                                    stopOpacity: 0
                                })]
                            }), (0, e.jsxs)("radialGradient", {
                                id: "Gradient-3_c_1_d".concat(s),
                                cx: 0,
                                cy: 0,
                                r: 1,
                                fx: 0,
                                fy: 0,
                                gradientUnits: "userSpaceOnUse",
                                gradientTransform: "matrix(18.6 -22.1 20.3 17 24.3 38.3)",
                                children: [(0, e.jsx)("stop", {
                                    offset: 0,
                                    stopColor: "#1c2130"
                                }), (0, e.jsx)("stop", {
                                    offset: 1,
                                    stopColor: "#1c2130",
                                    stopOpacity: 0
                                })]
                            }), (0, e.jsxs)("linearGradient", {
                                id: "Gradient-0_c_1_d".concat(s),
                                x1: 52,
                                y1: 52,
                                x2: -2.3,
                                y2: 1,
                                gradientUnits: "userSpaceOnUse",
                                children: [(0, e.jsx)("stop", {
                                    offset: 0,
                                    stopColor: "#d8fffc",
                                    stopOpacity: .63
                                }), (0, e.jsx)("stop", {
                                    offset: .2,
                                    stopColor: "#a0fff7",
                                    stopOpacity: 0
                                }), (0, e.jsx)("stop", {
                                    offset: .5,
                                    stopColor: "#8dfff6",
                                    stopOpacity: .56
                                }), (0, e.jsx)("stop", {
                                    offset: .7,
                                    stopColor: "#9af8f0"
                                }), (0, e.jsx)("stop", {
                                    offset: 1,
                                    stopColor: "#fff",
                                    stopOpacity: 0
                                }), (0, e.jsx)("stop", {
                                    offset: 1,
                                    stopColor: "#bafff9",
                                    stopOpacity: 0
                                })]
                            }), (0, e.jsxs)("linearGradient", {
                                id: "Gradient-1_c_1_d".concat(s),
                                x1: 24,
                                y1: 0,
                                x2: 24,
                                y2: 48,
                                gradientUnits: "userSpaceOnUse",
                                children: [(0, e.jsx)("stop", {
                                    offset: 0,
                                    stopColor: "#37b0ce"
                                }), (0, e.jsx)("stop", {
                                    offset: 1,
                                    stopColor: "#01586b"
                                })]
                            }), (0, e.jsx)("clipPath", {
                                id: "ClipPath-1_c_1_d",
                                children: (0, e.jsx)("rect", {
                                    width: 56,
                                    height: 56,
                                    rx: 8,
                                    fill: "#fff"
                                })
                            })]
                        }), (0, e.jsx)("style", {
                            children: "@keyframes a0_t_c_1_d{0%{transform:translate(28px,28px) scale(.9,.9) translate(-28px,-28px);animation-timing-function:cubic-bezier(.4,0,1,1)}to{transform:translate(28px,28px) scale(0,0) translate(-28px,-28px)}}@keyframes a1_o_c_1_d_c_1_d{0%,to{opacity:.6}}"
                        }), (0, e.jsxs)("g", {
                            clipPath: "url(#ClipPath-1_c_1_d)",
                            transform: "matrix(.9 0 0 .9 2.8 2.8)",
                            style: {
                                animation: ".2s linear both a0_t_c_1_d"
                            },
                            children: [(0, e.jsx)("rect", {
                                opacity: .7,
                                width: 56,
                                height: 56,
                                rx: 8,
                                fill: "#151c2e"
                            }), (0, e.jsx)("rect", {
                                opacity: .6,
                                width: 52,
                                height: 52,
                                rx: 6,
                                fill: "url(#Gradient-0_c_1_d".concat(s, ")"),
                                transform: "translate(2 2)"
                            }), (0, e.jsx)("rect", {
                                width: 48,
                                height: 48,
                                rx: 4,
                                fill: "url(#Gradient-1_c_1_d".concat(s, ")"),
                                transform: "translate(4 4)"
                            }), (0, e.jsx)("path", {
                                opacity: .1,
                                fillRule: "evenodd",
                                clipRule: "evenodd",
                                d: "M23.6 50.4c-3.9-.9-6.1-4.4-9-7.2-3-2.9-8.1-4.8-8-9 .2-4.1 5.9-5.2 8.7-8.3 3.1-3.5 3.8-9.5 8.3-10.5 4.8-1 9.9 2 12.9 5.9 2.8 3.6 1.6 8.4 1.8 12.9.4 5.1 3.4 10.9 0 14.6-3.5 3.8-9.7 2.8-14.7 1.6Z",
                                fill: "url(#Gradient-2_c_1_d".concat(s, ")")
                            }), (0, e.jsx)("path", {
                                opacity: .1,
                                fillRule: "evenodd",
                                clipRule: "evenodd",
                                d: "M19.9 26c.1-4 3-6.9 5.1-10.3 2.1-3.6 3-9 7.1-9.7 4.1-.8 6.3 4.6 10 6.6 4 2.3 10.1 1.7 12 5.9 2 4.5.1 10.1-3 13.9-2.9 3.5-7.9 3.3-12.3 4.5-4.8 1.4-9.9 5.6-14.3 3.1-4.4-2.6-4.7-8.9-4.6-14Z",
                                fill: "url(#Gradient-3_c_1_d".concat(s, ")")
                            }), (0, e.jsx)("rect", {
                                opacity: .6,
                                width: 56,
                                height: 56,
                                rx: 8,
                                fill: "#151c2e",
                                style: {
                                    animation: ".2s linear both a1_o_c_1_d_c_1_d"
                                }
                            })]
                        })]
                    })
                },
                c = function(t) {
                    var s = t.id;
                    return (0, e.jsxs)("svg", {
                        xmlns: "http://www.w3.org/2000/svg",
                        width: 56,
                        height: 56,
                        fill: "none",
                        children: [(0, e.jsxs)("defs", {
                            children: [(0, e.jsxs)("radialGradient", {
                                id: "Gradient-2_c_1_t".concat(s),
                                cx: 0,
                                cy: 0,
                                r: 1,
                                fx: 0,
                                fy: 0,
                                gradientUnits: "userSpaceOnUse",
                                gradientTransform: "matrix(-17.6 -22.9 21 -16.1 36.6 48.7)",
                                children: [(0, e.jsx)("stop", {
                                    offset: 0,
                                    stopColor: "#1c2130"
                                }), (0, e.jsx)("stop", {
                                    offset: 1,
                                    stopColor: "#1c2130",
                                    stopOpacity: 0
                                })]
                            }), (0, e.jsxs)("radialGradient", {
                                id: "Gradient-3_c_1_t".concat(s),
                                cx: 0,
                                cy: 0,
                                r: 1,
                                fx: 0,
                                fy: 0,
                                gradientUnits: "userSpaceOnUse",
                                gradientTransform: "matrix(18.6 -22.1 20.3 17 24.3 38.3)",
                                children: [(0, e.jsx)("stop", {
                                    offset: 0,
                                    stopColor: "#1c2130"
                                }), (0, e.jsx)("stop", {
                                    offset: 1,
                                    stopColor: "#1c2130",
                                    stopOpacity: 0
                                })]
                            }), (0, e.jsxs)("linearGradient", {
                                id: "Gradient-0_c_1_t_c_1_t".concat(s),
                                x1: 52,
                                y1: 52,
                                x2: -2.3,
                                y2: 1,
                                gradientUnits: "userSpaceOnUse",
                                children: [(0, e.jsx)("stop", {
                                    offset: 0,
                                    stopColor: "#d8fffc",
                                    stopOpacity: .63
                                }), (0, e.jsx)("stop", {
                                    offset: .2,
                                    stopColor: "#a0fff7",
                                    stopOpacity: 0
                                }), (0, e.jsx)("stop", {
                                    offset: .5,
                                    stopColor: "#8dfff6",
                                    stopOpacity: .56
                                }), (0, e.jsx)("stop", {
                                    offset: .7,
                                    stopColor: "#9af8f0"
                                }), (0, e.jsx)("stop", {
                                    offset: 1,
                                    stopColor: "#fff",
                                    stopOpacity: 0
                                }), (0, e.jsx)("stop", {
                                    offset: 1,
                                    stopColor: "#bafff9",
                                    stopOpacity: 0
                                })]
                            }), (0, e.jsxs)("linearGradient", {
                                id: "Gradient-1_c_1_t".concat(s),
                                x1: 24,
                                y1: 0,
                                x2: 24,
                                y2: 48,
                                gradientUnits: "userSpaceOnUse",
                                children: [(0, e.jsx)("stop", {
                                    offset: 0,
                                    stopColor: "#37b0ce"
                                }), (0, e.jsx)("stop", {
                                    offset: 1,
                                    stopColor: "#01586b"
                                })]
                            }), (0, e.jsx)("clipPath", {
                                id: "ClipPath-1",
                                children: (0, e.jsx)("rect", {
                                    width: 56,
                                    height: 56,
                                    rx: 8,
                                    fill: "#fff"
                                })
                            })]
                        }), (0, e.jsx)("style", {
                            children: "@keyframes a0_t_t_c_1_t{0%{transform:translate(28px,28px) scale(1,1) translate(-28px,-28px)}to{transform:translate(28px,28px) scale(.9,.9) translate(-28px,-28px)}}@keyframes a1_o_c_1_t{0%{opacity:0}to{opacity:.6}}"
                        }), (0, e.jsxs)("g", {
                            clipPath: "url(#ClipPath-1)",
                            style: {
                                animation: ".2s linear both a0_t_t_c_1_t"
                            },
                            children: [(0, e.jsx)("rect", {
                                opacity: .7,
                                width: 56,
                                height: 56,
                                rx: 8,
                                fill: "#151c2e"
                            }), (0, e.jsx)("path", {
                                opacity: .2,
                                fillRule: "evenodd",
                                clipRule: "evenodd",
                                d: "M31.3 73.8c.2-5.9 4.5-10.1 7.6-15.1 3.3-5.2 4.6-13.1 10.6-14.1s9.3 6.8 14.6 9.9c5.8 3.5 14.8 2.7 17.5 8.9 2.9 6.6 0 14.8-4.6 20.3-4.3 5.1-11.7 4.7-18.1 6.4-7.1 2-14.6 8-21 4.3-6.5-3.8-6.8-13.1-6.6-20.6ZM23.8 44.2c3.6 3.3 7.2 8 6.2 12.8-.9 4.8-7 5.7-10.6 9-3.8 3.5-5.4 11.3-10.6 10.7-5.3-.6-4.5-9-8.1-13-3.7-4.1-11.5-4.6-12.4-10.1-1-5.7 3.4-11.5 8.4-14.4 4.5-2.6 9.9.2 15 1.1 4.3.8 8.8.9 12.1 3.9ZM51.3-5.2c3.6 3.4 7.2 8 6.3 12.9-1 4.7-7.1 5.7-10.6 8.9-3.9 3.6-5.5 11.4-10.7 10.7-5.3-.6-4.5-9-8-12.9-3.7-4.2-11.6-4.6-12.5-10.1-1-5.7 3.4-11.6 8.4-14.4 4.6-2.6 9.9.1 15 1.1 4.3.8 8.8.9 12.1 3.8Z",
                                fill: "#1c2130"
                            }), (0, e.jsx)("rect", {
                                opacity: .6,
                                width: 52,
                                height: 52,
                                rx: 6,
                                fill: "url(#Gradient-0_c_1_t_c_1_t".concat(s, ")"),
                                transform: "translate(2 2)"
                            }), (0, e.jsx)("rect", {
                                width: 48,
                                height: 48,
                                rx: 4,
                                fill: "url(#Gradient-1_c_1_t".concat(s, ")"),
                                transform: "translate(4 4)"
                            }), (0, e.jsx)("path", {
                                opacity: .1,
                                fillRule: "evenodd",
                                clipRule: "evenodd",
                                d: "M23.6 50.4c-3.9-.9-6.1-4.4-9-7.2-3-2.9-8.1-4.8-8-9 .2-4.1 5.9-5.2 8.7-8.3 3.1-3.5 3.8-9.5 8.3-10.5 4.8-1 9.9 2 12.9 5.9 2.8 3.6 1.6 8.4 1.8 12.9.4 5.1 3.4 10.9 0 14.6-3.5 3.8-9.7 2.8-14.7 1.6Z",
                                fill: "url(#Gradient-2_c_1_t".concat(s, ")")
                            }), (0, e.jsx)("path", {
                                opacity: .1,
                                fillRule: "evenodd",
                                clipRule: "evenodd",
                                d: "M19.9 26c.1-4 3-6.9 5.1-10.3 2.1-3.6 3-9 7.1-9.7 4.1-.8 6.3 4.6 10 6.6 4 2.3 10.1 1.7 12 5.9 2 4.5.1 10.1-3 13.9-2.9 3.5-7.9 3.3-12.3 4.5-4.8 1.4-9.9 5.6-14.3 3.1-4.4-2.6-4.7-8.9-4.6-14Z",
                                fill: "url(#Gradient-3_c_1_t".concat(s, ")")
                            }), (0, e.jsx)("rect", {
                                opacity: 0,
                                width: 56,
                                height: 56,
                                rx: 8,
                                fill: "#151C2E",
                                style: {
                                    animation: "0.2s linear both a1_o_c_1_t"
                                }
                            })]
                        })]
                    })
                },
                p = function(t) {
                    return (0, e.jsxs)("svg", (0, i.Z)((0, i.Z)({
                        xmlns: "http://www.w3.org/2000/svg",
                        width: 56,
                        height: 56,
                        fill: "none",
                        style: {
                            background: "0 0"
                        }
                    }, t), {}, {
                        children: [(0, e.jsxs)("defs", {
                            children: [(0, e.jsxs)("linearGradient", {
                                id: "Gradient-0_cr_i",
                                x1: 36.273,
                                y1: 22.811,
                                x2: 36.273,
                                y2: 42.259,
                                gradientUnits: "userSpaceOnUse",
                                children: [(0, e.jsx)("stop", {
                                    offset: 0,
                                    stopColor: "#708fbe",
                                    stopOpacity: 0
                                }), (0, e.jsx)("stop", {
                                    offset: 1,
                                    stopColor: "#72ddff",
                                    stopOpacity: .63
                                })]
                            }), (0, e.jsxs)("linearGradient", {
                                id: "Gradient-1_cr_i",
                                x1: 37.616,
                                y1: 25.294,
                                x2: 38.093,
                                y2: 46.992,
                                gradientUnits: "userSpaceOnUse",
                                children: [(0, e.jsx)("stop", {
                                    offset: 0,
                                    stopColor: "#708fbe",
                                    stopOpacity: 0
                                }), (0, e.jsx)("stop", {
                                    offset: 1,
                                    stopColor: "#72ddff",
                                    stopOpacity: .63
                                })]
                            }), (0, e.jsxs)("linearGradient", {
                                id: "Gradient-3_cr_i",
                                x1: 40.728,
                                y1: 38.449,
                                x2: 18.636,
                                y2: 19.326,
                                gradientUnits: "userSpaceOnUse",
                                children: [(0, e.jsx)("stop", {
                                    offset: 0,
                                    stopColor: "#d8f6ff",
                                    stopOpacity: .63
                                }), (0, e.jsx)("stop", {
                                    offset: .219,
                                    stopColor: "#a0d2ff",
                                    stopOpacity: 0
                                }), (0, e.jsx)("stop", {
                                    offset: .491,
                                    stopColor: "#8dc8ff",
                                    stopOpacity: .56
                                }), (0, e.jsx)("stop", {
                                    offset: .733,
                                    stopColor: "#9adbf8"
                                }), (0, e.jsx)("stop", {
                                    offset: 1,
                                    stopColor: "#fff",
                                    stopOpacity: 0
                                }), (0, e.jsx)("stop", {
                                    offset: 1,
                                    stopColor: "#baeaff",
                                    stopOpacity: 0
                                })]
                            }), (0, e.jsxs)("linearGradient", {
                                id: "Gradient-4_cr_i",
                                x1: 14.418,
                                y1: 36.947,
                                x2: 17.329,
                                y2: 39.593,
                                gradientUnits: "userSpaceOnUse",
                                children: [(0, e.jsx)("stop", {
                                    offset: 0,
                                    stopColor: "#c4c4c4",
                                    stopOpacity: 0
                                }), (0, e.jsx)("stop", {
                                    offset: .732,
                                    stopColor: "#dbf6ff",
                                    stopOpacity: .46
                                })]
                            }), (0, e.jsxs)("linearGradient", {
                                id: "Gradient-5_cr_i",
                                x1: 19.496,
                                y1: 20.081,
                                x2: 16.218,
                                y2: 17.456,
                                gradientUnits: "userSpaceOnUse",
                                children: [(0, e.jsx)("stop", {
                                    offset: 0,
                                    stopColor: "#c4c4c4",
                                    stopOpacity: 0
                                }), (0, e.jsx)("stop", {
                                    offset: 1,
                                    stopColor: "#dbf6ff",
                                    stopOpacity: .45
                                })]
                            }), (0, e.jsxs)("linearGradient", {
                                id: "Gradient-6_cr_i",
                                x1: 40.013,
                                y1: 20.668,
                                x2: 36.906,
                                y2: 18.258,
                                gradientUnits: "userSpaceOnUse",
                                children: [(0, e.jsx)("stop", {
                                    offset: 0,
                                    stopColor: "#c4c4c4",
                                    stopOpacity: 0
                                }), (0, e.jsx)("stop", {
                                    offset: 1,
                                    stopColor: "#dbf6ff",
                                    stopOpacity: .45
                                })]
                            }), (0, e.jsxs)("linearGradient", {
                                id: "Gradient-7_cr_i",
                                x1: 28.827,
                                y1: 29.033,
                                x2: 36.075,
                                y2: 28.323,
                                gradientUnits: "userSpaceOnUse",
                                children: [(0, e.jsx)("stop", {
                                    offset: .224,
                                    stopColor: "#dbf6ff",
                                    stopOpacity: .35
                                }), (0, e.jsx)("stop", {
                                    offset: 1,
                                    stopColor: "#c4c4c4",
                                    stopOpacity: 0
                                })]
                            }), (0, e.jsxs)("linearGradient", {
                                id: "Gradient-8_cr_i",
                                x1: 37.08,
                                y1: 34.836,
                                x2: 12.044,
                                y2: 13.755,
                                gradientUnits: "userSpaceOnUse",
                                children: [(0, e.jsx)("stop", {
                                    offset: 0,
                                    stopColor: "#d8f6ff",
                                    stopOpacity: .63
                                }), (0, e.jsx)("stop", {
                                    offset: .219,
                                    stopColor: "#a0d2ff",
                                    stopOpacity: 0
                                }), (0, e.jsx)("stop", {
                                    offset: .491,
                                    stopColor: "#8dc8ff",
                                    stopOpacity: .56
                                }), (0, e.jsx)("stop", {
                                    offset: .733,
                                    stopColor: "#9adbf8"
                                }), (0, e.jsx)("stop", {
                                    offset: 1,
                                    stopColor: "#fff",
                                    stopOpacity: 0
                                }), (0, e.jsx)("stop", {
                                    offset: 1,
                                    stopColor: "#baeaff",
                                    stopOpacity: 0
                                })]
                            }), (0, e.jsxs)("linearGradient", {
                                id: "Gradient-9_cr_i",
                                x1: 0,
                                y1: -2.48,
                                x2: -.638,
                                y2: 1.785,
                                gradientUnits: "userSpaceOnUse",
                                children: [(0, e.jsx)("stop", {
                                    offset: 0,
                                    stopColor: "#94d9f6"
                                }), (0, e.jsx)("stop", {
                                    offset: 1,
                                    stopColor: "#94d9f6",
                                    stopOpacity: 0
                                })]
                            }), (0, e.jsxs)("radialGradient", {
                                id: "Gradient-2_cr_i",
                                cx: 0,
                                cy: 0,
                                r: 1,
                                fx: 0,
                                fy: 0,
                                gradientUnits: "userSpaceOnUse",
                                gradientTransform: "matrix(15.5197 21.2962 -21.0221 15.3199 22.682 24.327)",
                                children: [(0, e.jsx)("stop", {
                                    offset: .739,
                                    stopColor: "#9cb6dd",
                                    stopOpacity: 0
                                }), (0, e.jsx)("stop", {
                                    offset: .898,
                                    stopColor: "#c6f1ff",
                                    stopOpacity: .37
                                }), (0, e.jsx)("stop", {
                                    offset: 1,
                                    stopColor: "#effbff",
                                    stopOpacity: .7
                                })]
                            })]
                        }), (0, e.jsx)("style", {
                            children: "@keyframes a0_t_cr_i{0%{transform:translate(28px,28px) rotate(180deg);animation-timing-function:cubic-bezier(0,0,.58,1)}71.4285%{transform:translate(28px,28px) rotate(-5deg)}to{transform:translate(28px,28px) rotate(0deg)}}@keyframes krest_t_cr_i{0%{transform:scale(0,0) translate(-28px,-28px)}42.8571%,to{transform:scale(1,1) translate(-28px,-28px)}71.4285%{transform:scale(1.15,1.15) translate(-28px,-28px);animation-timing-function:cubic-bezier(0,0,.58,1)}}@keyframes a1_t_cr_i{0%{transform:translate(17.3511px,39px) rotate(0deg) scale(.438128,.423532) translate(-14.3863px,-37.0446px)}to{transform:translate(14.3863px,37.0446px) rotate(0deg) scale(1,1) translate(-14.3863px,-37.0446px)}}@keyframes a2_t_cr_i{0%{transform:translate(15.8726px,16.8036px) rotate(0deg) scale(.440469,.440469) translate(-19.2722px,-19.7496px)}to{transform:translate(19.2722px,19.7496px) rotate(0deg) scale(1,1) translate(-19.2722px,-19.7496px)}}@keyframes a3_t_cr_i{0%{transform:translate(37px,18.2131px) rotate(0deg) scale(.461347,.461347) translate(-40.0446px,-20.5702px)}to{transform:translate(40.0446px,20.5702px) rotate(0deg) scale(1,1) translate(-40.0446px,-20.5702px)}}@keyframes a4_t_cr_i{0%{transform:translate(29.3877px,32.5041px) rotate(-45.565409deg) scale(.403058,.403058) translate(-31.3472px,-29.0394px)}to{transform:translate(31.3472px,29.0394px) rotate(0deg) scale(1,1) translate(-31.3472px,-29.0394px)}}@keyframes a5_t_cr_i{0%{transform:translate(27.9335px,28.2933px) rotate(0deg) scale(1.122601,1.122601) translate(-27.9335px,-28.2933px)}28.5714%{transform:translate(27.9335px,28.2933px) rotate(-4.682578deg) scale(1.087572,1.087572) translate(-27.9335px,-28.2933px)}71.4285%{transform:translate(27.9335px,28.2933px) rotate(0deg) scale(1.035029,1.035029) translate(-27.9335px,-28.2933px)}to{transform:translate(27.9335px,28.2933px) rotate(0deg) scale(1,1) translate(-27.9335px,-28.2933px)}}"
                        }), (0, e.jsx)("g", {
                            style: {
                                animation: ".7s linear both a0_t_cr_i"
                            },
                            children: (0, e.jsxs)("g", {
                                transform: "matrix(0 0 0 0 28 28)",
                                style: {
                                    animation: ".7s linear both krest_t_cr_i"
                                },
                                id: "krest",
                                children: [(0, e.jsx)("path", {
                                    fillRule: "evenodd",
                                    clipRule: "evenodd",
                                    d: "M43.408 10.226a2.385 2.385 0 0 0-3.373 0L29.388 20.872a2.237 2.237 0 0 1-3.163 0L15.578 10.226a2.385 2.385 0 0 0-3.373 0l-2.53 2.53a2.385 2.385 0 0 0 0 3.373L20.32 26.776c.874.873.874 2.29 0 3.163L9.675 40.585a2.385 2.385 0 0 0 0 3.374l2.53 2.53a2.385 2.385 0 0 0 3.373 0l10.647-10.647a2.236 2.236 0 0 1 3.163 0l10.646 10.647a2.385 2.385 0 0 0 3.374 0l2.53-2.53a2.385 2.385 0 0 0 0-3.374L35.29 29.94a2.237 2.237 0 0 1 0-3.163l10.647-10.647a2.385 2.385 0 0 0 0-3.373l-2.53-2.53Z",
                                    fill: "#43628F"
                                }), (0, e.jsx)("path", {
                                    fillRule: "evenodd",
                                    clipRule: "evenodd",
                                    d: "M43.408 10.226a2.385 2.385 0 0 0-3.373 0L29.388 20.872a2.237 2.237 0 0 1-3.163 0L15.578 10.226a2.385 2.385 0 0 0-3.373 0l-2.53 2.53a2.385 2.385 0 0 0 0 3.373L20.32 26.776c.874.873.874 2.29 0 3.163L9.675 40.585a2.385 2.385 0 0 0 0 3.374l2.53 2.53a2.385 2.385 0 0 0 3.373 0l10.647-10.647a2.236 2.236 0 0 1 3.163 0l10.646 10.647a2.385 2.385 0 0 0 3.374 0l2.53-2.53a2.385 2.385 0 0 0 0-3.374L35.29 29.94a2.237 2.237 0 0 1 0-3.163l10.647-10.647a2.385 2.385 0 0 0 0-3.373l-2.53-2.53Z",
                                    fill: "url(#Gradient-0_cr_i)"
                                }), (0, e.jsx)("path", {
                                    fillRule: "evenodd",
                                    clipRule: "evenodd",
                                    d: "M43.408 10.226a2.385 2.385 0 0 0-3.373 0L27.806 22.454 15.578 10.226a2.385 2.385 0 0 0-3.373 0l-2.53 2.53a2.385 2.385 0 0 0 0 3.373l12.228 12.228L9.675 40.585a2.385 2.385 0 0 0 0 3.374l2.53 2.53a2.385 2.385 0 0 0 3.373 0L27.806 34.26 40.035 46.49a2.385 2.385 0 0 0 3.373 0l2.53-2.53a2.385 2.385 0 0 0 0-3.374L33.709 28.357 45.938 16.13a2.385 2.385 0 0 0 0-3.373l-2.53-2.53Z",
                                    fill: "url(#Gradient-1_cr_i)"
                                }), (0, e.jsx)("path", {
                                    fillRule: "evenodd",
                                    clipRule: "evenodd",
                                    d: "M43.408 10.226a2.385 2.385 0 0 0-3.373 0L27.806 22.454 15.578 10.226a2.385 2.385 0 0 0-3.373 0l-2.53 2.53a2.385 2.385 0 0 0 0 3.373l12.228 12.228L9.675 40.585a2.385 2.385 0 0 0 0 3.374l2.53 2.53a2.385 2.385 0 0 0 3.373 0L27.806 34.26 40.035 46.49a2.385 2.385 0 0 0 3.373 0l2.53-2.53a2.385 2.385 0 0 0 0-3.374L33.71 28.357l12.228-12.228a2.385 2.385 0 0 0 0-3.373l-2.53-2.53Z",
                                    fill: "url(#Gradient-2_cr_i)"
                                }), (0, e.jsx)("path", {
                                    fillRule: "evenodd",
                                    clipRule: "evenodd",
                                    d: "M39.36 9.551a3.34 3.34 0 0 1 4.723 0l2.53 2.53a3.34 3.34 0 0 1 0 4.723L35.227 28.188a.239.239 0 0 0 0 .338L46.613 39.91a3.34 3.34 0 0 1 0 4.722l-2.53 2.53a3.34 3.34 0 0 1-4.723 0L27.975 35.778a.239.239 0 0 0-.337 0L16.253 47.163a3.34 3.34 0 0 1-4.723 0L9 44.633a3.34 3.34 0 0 1 0-4.722l11.385-11.385a.239.239 0 0 0 0-.338L9 16.804a3.34 3.34 0 0 1 0-4.723l2.53-2.53a3.34 3.34 0 0 1 4.723 0l11.385 11.385a.239.239 0 0 0 .337 0L39.36 9.55Zm.675.675a2.385 2.385 0 0 1 3.373 0l2.53 2.53a2.385 2.385 0 0 1 0 3.373L34.553 27.514a1.193 1.193 0 0 0 0 1.686l11.385 11.385a2.385 2.385 0 0 1 0 3.374l-2.53 2.53a2.385 2.385 0 0 1-3.373 0L28.65 35.104a1.193 1.193 0 0 0-1.687 0L15.578 46.489a2.385 2.385 0 0 1-3.373 0l-2.53-2.53a2.385 2.385 0 0 1 0-3.374L21.06 29.2a1.193 1.193 0 0 0 0-1.686L9.675 16.129a2.385 2.385 0 0 1 0-3.373l2.53-2.53a2.385 2.385 0 0 1 3.373 0L26.963 21.61c.466.466 1.221.466 1.687 0l11.385-11.384Z",
                                    fill: "#E2E2E2"
                                }), (0, e.jsx)("path", {
                                    fillRule: "evenodd",
                                    clipRule: "evenodd",
                                    d: "M39.36 9.551a3.34 3.34 0 0 1 4.723 0l2.53 2.53a3.34 3.34 0 0 1 0 4.723L35.227 28.188a.239.239 0 0 0 0 .338L46.613 39.91a3.34 3.34 0 0 1 0 4.722l-2.53 2.53a3.34 3.34 0 0 1-4.723 0L27.975 35.778a.239.239 0 0 0-.337 0L16.253 47.163a3.34 3.34 0 0 1-4.723 0L9 44.633a3.34 3.34 0 0 1 0-4.722l11.385-11.385a.239.239 0 0 0 0-.338L9 16.804a3.34 3.34 0 0 1 0-4.723l2.53-2.53a3.34 3.34 0 0 1 4.723 0l11.385 11.385a.239.239 0 0 0 .337 0L39.36 9.55Zm.675.675a2.385 2.385 0 0 1 3.373 0l2.53 2.53a2.385 2.385 0 0 1 0 3.373L34.553 27.514a1.193 1.193 0 0 0 0 1.686l11.385 11.385a2.385 2.385 0 0 1 0 3.374l-2.53 2.53a2.385 2.385 0 0 1-3.373 0L28.65 35.104a1.193 1.193 0 0 0-1.687 0L15.578 46.489a2.385 2.385 0 0 1-3.373 0l-2.53-2.53a2.385 2.385 0 0 1 0-3.374L21.06 29.2a1.193 1.193 0 0 0 0-1.686L9.675 16.129a2.385 2.385 0 0 1 0-3.373l2.53-2.53a2.385 2.385 0 0 1 3.373 0L26.963 21.61c.466.466 1.221.466 1.687 0l11.385-11.384Z",
                                    fill: "url(#Gradient-3_cr_i)"
                                }), (0, e.jsx)("path", {
                                    d: "M19.263 32.051c.336 8.28-5.096 10.683-7.854 10.85-5.237-.655 1.651-3.229 4.258-8.555 2.086-4.261 3.267-3.305 3.596-2.295Z",
                                    fill: "url(#Gradient-4_cr_i)",
                                    transform: "matrix(.43813 0 0 .42353 11.048 23.31)",
                                    style: {
                                        animation: ".7s linear both a1_t_cr_i"
                                    }
                                }), (0, e.jsx)("path", {
                                    d: "M16.417 22.512c-1.922-6.724 2.141-6.982 4.413-6.27 4.507 2.126-.74 2.076-1.863 5.536-.898 2.769-2.074 1.643-2.55.734Z",
                                    fill: "url(#Gradient-5_cr_i)",
                                    fillOpacity: .6,
                                    transform: "matrix(.44047 0 0 .44047 7.384 8.105)",
                                    style: {
                                        animation: ".7s linear both a2_t_cr_i"
                                    }
                                }), (0, e.jsx)("path", {
                                    d: "M35.168 25.564c-.336-8.281 5.096-10.684 7.854-10.85 5.237.654-1.651 3.229-4.258 8.555-2.086 4.26-3.267 3.305-3.596 2.295Z",
                                    fill: "url(#Gradient-6_cr_i)",
                                    fillOpacity: .6,
                                    transform: "matrix(.46135 0 0 .46135 18.526 8.723)",
                                    style: {
                                        animation: ".7s linear both a3_t_cr_i"
                                    }
                                }), (0, e.jsx)("path", {
                                    d: "M27.007 29.814c1.866 7.643 5.57 8.719 7.188 8.301 4.173-1.915.778-14.985-1.107-17.311-1.885-2.326-8.414-.543-6.081 9.01Z",
                                    fill: "url(#Gradient-7_cr_i)",
                                    fillOpacity: .6,
                                    transform: "rotate(-45.566 45.772 2.16) scale(.40306)",
                                    style: {
                                        animation: ".7s linear both a4_t_cr_i"
                                    }
                                }), (0, e.jsx)("path", {
                                    fillRule: "evenodd",
                                    clipRule: "evenodd",
                                    d: "M12.948 13.266a.894.894 0 0 1 1.265.002l9.498 9.524a5.963 5.963 0 0 0 8.445 0l9.498-9.524a.894.894 0 1 1 1.267 1.263l-9.525 9.552a5.963 5.963 0 0 0 0 8.421l9.525 9.552a.894.894 0 1 1-1.267 1.263l-9.498-9.525a5.963 5.963 0 0 0-8.445 0l-9.498 9.525a.895.895 0 0 1-1.267-1.263l9.525-9.552a5.963 5.963 0 0 0 0-8.421l-9.525-9.552a.894.894 0 0 1 .002-1.265Z",
                                    fill: "url(#Gradient-8_cr_i)",
                                    transform: "translate(-3.425 -3.469) scale(1.1226)",
                                    style: {
                                        animation: ".7s linear both a5_t_cr_i"
                                    }
                                }), (0, e.jsx)("circle", {
                                    fill: "#94D9F6",
                                    transform: "translate(26.508 27.06)",
                                    r: .54
                                }), (0, e.jsx)("circle", {
                                    opacity: .2,
                                    fill: "url(#Gradient-9_cr_i)",
                                    transform: "translate(26.509 27.06)",
                                    r: 2.48
                                }), (0, e.jsx)("path", {
                                    fillRule: "evenodd",
                                    clipRule: "evenodd",
                                    d: "M12.052 16.59a.54.54 0 0 1 .764.022l2.322 2.46a.54.54 0 0 1-.785.742l-2.323-2.46a.54.54 0 0 1 .022-.764Z",
                                    fill: "#94D9F6"
                                }), (0, e.jsx)("circle", {
                                    fill: "#94D9F6",
                                    transform: "rotate(-70.181 22.464 -.895)",
                                    r: .54
                                })]
                            })
                        })]
                    }))
                },
                f = function() {
                    return (0, e.jsxs)("svg", {
                        xmlns: "http://www.w3.org/2000/svg",
                        width: 56,
                        height: 56,
                        fill: "none",
                        style: {
                            background: "0 0"
                        },
                        children: [(0, e.jsxs)("defs", {
                            children: [(0, e.jsxs)("linearGradient", {
                                id: "Gradient-0_cr_d",
                                x1: 36.273,
                                y1: 22.811,
                                x2: 36.273,
                                y2: 42.259,
                                gradientUnits: "userSpaceOnUse",
                                children: [(0, e.jsx)("stop", {
                                    offset: 0,
                                    stopColor: "#708fbe",
                                    stopOpacity: 0
                                }), (0, e.jsx)("stop", {
                                    offset: 1,
                                    stopColor: "#72ddff",
                                    stopOpacity: .63
                                })]
                            }), (0, e.jsxs)("linearGradient", {
                                id: "Gradient-1_cr_d",
                                x1: 37.616,
                                y1: 25.294,
                                x2: 38.093,
                                y2: 46.992,
                                gradientUnits: "userSpaceOnUse",
                                children: [(0, e.jsx)("stop", {
                                    offset: 0,
                                    stopColor: "#708fbe",
                                    stopOpacity: 0
                                }), (0, e.jsx)("stop", {
                                    offset: 1,
                                    stopColor: "#72ddff",
                                    stopOpacity: .63
                                })]
                            }), (0, e.jsxs)("linearGradient", {
                                id: "Gradient-3_cr_d",
                                x1: 40.728,
                                y1: 38.449,
                                x2: 18.636,
                                y2: 19.326,
                                gradientUnits: "userSpaceOnUse",
                                children: [(0, e.jsx)("stop", {
                                    offset: 0,
                                    stopColor: "#d8f6ff",
                                    stopOpacity: .63
                                }), (0, e.jsx)("stop", {
                                    offset: .219,
                                    stopColor: "#a0d2ff",
                                    stopOpacity: 0
                                }), (0, e.jsx)("stop", {
                                    offset: .491,
                                    stopColor: "#8dc8ff",
                                    stopOpacity: .56
                                }), (0, e.jsx)("stop", {
                                    offset: .733,
                                    stopColor: "#9adbf8"
                                }), (0, e.jsx)("stop", {
                                    offset: 1,
                                    stopColor: "#fff",
                                    stopOpacity: 0
                                }), (0, e.jsx)("stop", {
                                    offset: 1,
                                    stopColor: "#baeaff",
                                    stopOpacity: 0
                                })]
                            }), (0, e.jsxs)("linearGradient", {
                                id: "Gradient-4_cr_d",
                                x1: 14.418,
                                y1: 36.947,
                                x2: 17.329,
                                y2: 39.593,
                                gradientUnits: "userSpaceOnUse",
                                children: [(0, e.jsx)("stop", {
                                    offset: 0,
                                    stopColor: "#c4c4c4",
                                    stopOpacity: 0
                                }), (0, e.jsx)("stop", {
                                    offset: .732,
                                    stopColor: "#dbf6ff",
                                    stopOpacity: .46
                                })]
                            }), (0, e.jsxs)("linearGradient", {
                                id: "Gradient-5_cr_d",
                                x1: 19.496,
                                y1: 20.081,
                                x2: 16.218,
                                y2: 17.456,
                                gradientUnits: "userSpaceOnUse",
                                children: [(0, e.jsx)("stop", {
                                    offset: 0,
                                    stopColor: "#c4c4c4",
                                    stopOpacity: 0
                                }), (0, e.jsx)("stop", {
                                    offset: 1,
                                    stopColor: "#dbf6ff",
                                    stopOpacity: .45
                                })]
                            }), (0, e.jsxs)("linearGradient", {
                                id: "Gradient-6_cr_d",
                                x1: 40.013,
                                y1: 20.668,
                                x2: 36.906,
                                y2: 18.258,
                                gradientUnits: "userSpaceOnUse",
                                children: [(0, e.jsx)("stop", {
                                    offset: 0,
                                    stopColor: "#c4c4c4",
                                    stopOpacity: 0
                                }), (0, e.jsx)("stop", {
                                    offset: 1,
                                    stopColor: "#dbf6ff",
                                    stopOpacity: .45
                                })]
                            }), (0, e.jsxs)("linearGradient", {
                                id: "Gradient-7_cr_d",
                                x1: 28.827,
                                y1: 29.033,
                                x2: 36.075,
                                y2: 28.323,
                                gradientUnits: "userSpaceOnUse",
                                children: [(0, e.jsx)("stop", {
                                    offset: .224,
                                    stopColor: "#dbf6ff",
                                    stopOpacity: .35
                                }), (0, e.jsx)("stop", {
                                    offset: 1,
                                    stopColor: "#c4c4c4",
                                    stopOpacity: 0
                                })]
                            }), (0, e.jsxs)("linearGradient", {
                                id: "Gradient-8_cr_d",
                                x1: 37.08,
                                y1: 34.836,
                                x2: 12.044,
                                y2: 13.755,
                                gradientUnits: "userSpaceOnUse",
                                children: [(0, e.jsx)("stop", {
                                    offset: 0,
                                    stopColor: "#d8f6ff",
                                    stopOpacity: .63
                                }), (0, e.jsx)("stop", {
                                    offset: .219,
                                    stopColor: "#a0d2ff",
                                    stopOpacity: 0
                                }), (0, e.jsx)("stop", {
                                    offset: .491,
                                    stopColor: "#8dc8ff",
                                    stopOpacity: .56
                                }), (0, e.jsx)("stop", {
                                    offset: .733,
                                    stopColor: "#9adbf8"
                                }), (0, e.jsx)("stop", {
                                    offset: 1,
                                    stopColor: "#fff",
                                    stopOpacity: 0
                                }), (0, e.jsx)("stop", {
                                    offset: 1,
                                    stopColor: "#baeaff",
                                    stopOpacity: 0
                                })]
                            }), (0, e.jsxs)("linearGradient", {
                                id: "Gradient-9_cr_d",
                                x1: 0,
                                y1: -2.48,
                                x2: -.638,
                                y2: 1.785,
                                gradientUnits: "userSpaceOnUse",
                                children: [(0, e.jsx)("stop", {
                                    offset: 0,
                                    stopColor: "#94d9f6"
                                }), (0, e.jsx)("stop", {
                                    offset: 1,
                                    stopColor: "#94d9f6",
                                    stopOpacity: 0
                                })]
                            }), (0, e.jsxs)("radialGradient", {
                                id: "Gradient-2_cr_d",
                                cx: 0,
                                cy: 0,
                                r: 1,
                                fx: 0,
                                fy: 0,
                                gradientUnits: "userSpaceOnUse",
                                gradientTransform: "matrix(15.5197 21.2962 -21.0221 15.3199 22.682 24.327)",
                                children: [(0, e.jsx)("stop", {
                                    offset: .739,
                                    stopColor: "#9cb6dd",
                                    stopOpacity: 0
                                }), (0, e.jsx)("stop", {
                                    offset: .898,
                                    stopColor: "#c6f1ff",
                                    stopOpacity: .37
                                }), (0, e.jsx)("stop", {
                                    offset: 1,
                                    stopColor: "#effbff",
                                    stopOpacity: .7
                                })]
                            })]
                        }), (0, e.jsx)("style", {
                            children: "@keyframes a0_t_cr_d{0%,to{transform:translate(28px,28px) rotate(0deg)}}@keyframes krest_t_cr_d{0%{transform:scale(1,1) translate(-28px,-28px);animation-timing-function:cubic-bezier(.42,0,1,1)}50%{transform:scale(1,1) translate(-28px,-28px)}to{transform:scale(0,0) translate(-28px,-28px)}}@keyframes a1_t_cr_d{0%{transform:translate(15.992233px,38.103775px) rotate(0deg) scale(.695653,.687747) translate(-14.3863px,-37.0446px)}to{transform:translate(16.486366px,38.429676px) rotate(0deg) scale(.602007,.591668) translate(-14.3863px,-37.0446px)}}@keyframes a2_t_cr_d{0%{transform:translate(17.43075px,18.153849px) rotate(0deg) scale(.696921,.696921) translate(-19.2722px,-19.7496px)}to{transform:translate(16.864149px,17.662849px) rotate(0deg) scale(.603666,.603666) translate(-19.2722px,-19.7496px)}}@keyframes a3_t_cr_d{0%{transform:translate(40.0446px,20.5702px) rotate(0deg) scale(1,1) translate(-40.0446px,-20.5702px)}to{transform:translate(37px,18.2131px) rotate(0deg) scale(.461347,.461347) translate(-40.0446px,-20.5702px)}}@keyframes a4_t_cr_d{0%{transform:translate(31.3472px,29.0394px) rotate(0deg) scale(1,1) translate(-31.3472px,-29.0394px)}to{transform:translate(29.3877px,32.5041px) rotate(-45.565409deg) scale(.403058,.403058) translate(-31.3472px,-29.0394px)}}@keyframes a5_t_cr_d{0%{transform:translate(27.9335px,28.2933px) rotate(0deg) scale(1,1) translate(-27.9335px,-28.2933px)}25%{transform:translate(27.9335px,28.2933px) rotate(-4.682578deg) scale(1.03065,1.03065) translate(-27.9335px,-28.2933px)}50%{transform:translate(27.9335px,28.2933px) rotate(0deg) scale(1.0613,1.0613) translate(-27.9335px,-28.2933px)}to{transform:translate(27.9335px,28.2933px) rotate(0deg) scale(1.122601,1.122601) translate(-27.9335px,-28.2933px)}}"
                        }), (0, e.jsx)("g", {
                            id: "krest_cr_d",
                            style: {
                                animation: "0.4s linear both a0_t_cr_d"
                            },
                            children: (0, e.jsxs)("g", {
                                transform: "translate(28,28) translate(-28,-28)",
                                style: {
                                    animation: "0.4s linear both krest_t_cr_d"
                                },
                                children: [(0, e.jsx)("path", {
                                    fillRule: "evenodd",
                                    clipRule: "evenodd",
                                    d: "M43.408 10.226a2.385 2.385 0 0 0-3.373 0L29.388 20.872a2.237 2.237 0 0 1-3.163 0L15.578 10.226a2.385 2.385 0 0 0-3.373 0l-2.53 2.53a2.385 2.385 0 0 0 0 3.373L20.32 26.776c.874.873.874 2.29 0 3.163L9.675 40.585a2.385 2.385 0 0 0 0 3.374l2.53 2.53a2.385 2.385 0 0 0 3.373 0l10.647-10.647a2.236 2.236 0 0 1 3.163 0l10.646 10.647a2.385 2.385 0 0 0 3.374 0l2.53-2.53a2.385 2.385 0 0 0 0-3.374L35.29 29.94a2.237 2.237 0 0 1 0-3.163l10.647-10.647a2.385 2.385 0 0 0 0-3.373l-2.53-2.53Z",
                                    fill: "#43628F"
                                }), (0, e.jsx)("path", {
                                    fillRule: "evenodd",
                                    clipRule: "evenodd",
                                    d: "M43.408 10.226a2.385 2.385 0 0 0-3.373 0L29.388 20.872a2.237 2.237 0 0 1-3.163 0L15.578 10.226a2.385 2.385 0 0 0-3.373 0l-2.53 2.53a2.385 2.385 0 0 0 0 3.373L20.32 26.776c.874.873.874 2.29 0 3.163L9.675 40.585a2.385 2.385 0 0 0 0 3.374l2.53 2.53a2.385 2.385 0 0 0 3.373 0l10.647-10.647a2.236 2.236 0 0 1 3.163 0l10.646 10.647a2.385 2.385 0 0 0 3.374 0l2.53-2.53a2.385 2.385 0 0 0 0-3.374L35.29 29.94a2.237 2.237 0 0 1 0-3.163l10.647-10.647a2.385 2.385 0 0 0 0-3.373l-2.53-2.53Z",
                                    fill: "url(#Gradient-0_cr_d)"
                                }), (0, e.jsx)("path", {
                                    fillRule: "evenodd",
                                    clipRule: "evenodd",
                                    d: "M43.408 10.226a2.385 2.385 0 0 0-3.373 0L27.806 22.454 15.578 10.226a2.385 2.385 0 0 0-3.373 0l-2.53 2.53a2.385 2.385 0 0 0 0 3.373l12.228 12.228L9.675 40.585a2.385 2.385 0 0 0 0 3.374l2.53 2.53a2.385 2.385 0 0 0 3.373 0L27.806 34.26 40.035 46.49a2.385 2.385 0 0 0 3.373 0l2.53-2.53a2.385 2.385 0 0 0 0-3.374L33.709 28.357 45.938 16.13a2.385 2.385 0 0 0 0-3.373l-2.53-2.53Z",
                                    fill: "url(#Gradient-1_cr_d)"
                                }), (0, e.jsx)("path", {
                                    fillRule: "evenodd",
                                    clipRule: "evenodd",
                                    d: "M43.408 10.226a2.385 2.385 0 0 0-3.373 0L27.806 22.454 15.578 10.226a2.385 2.385 0 0 0-3.373 0l-2.53 2.53a2.385 2.385 0 0 0 0 3.373l12.228 12.228L9.675 40.585a2.385 2.385 0 0 0 0 3.374l2.53 2.53a2.385 2.385 0 0 0 3.373 0L27.806 34.26 40.035 46.49a2.385 2.385 0 0 0 3.373 0l2.53-2.53a2.385 2.385 0 0 0 0-3.374L33.71 28.357l12.228-12.228a2.385 2.385 0 0 0 0-3.373l-2.53-2.53Z",
                                    fill: "url(#Gradient-2_cr_d)"
                                }), (0, e.jsx)("path", {
                                    fillRule: "evenodd",
                                    clipRule: "evenodd",
                                    d: "M39.36 9.551a3.34 3.34 0 0 1 4.723 0l2.53 2.53a3.34 3.34 0 0 1 0 4.723L35.227 28.188a.239.239 0 0 0 0 .338L46.613 39.91a3.34 3.34 0 0 1 0 4.722l-2.53 2.53a3.34 3.34 0 0 1-4.723 0L27.975 35.778a.239.239 0 0 0-.337 0L16.253 47.163a3.34 3.34 0 0 1-4.723 0L9 44.633a3.34 3.34 0 0 1 0-4.722l11.385-11.385a.239.239 0 0 0 0-.338L9 16.804a3.34 3.34 0 0 1 0-4.723l2.53-2.53a3.34 3.34 0 0 1 4.723 0l11.385 11.385a.239.239 0 0 0 .337 0L39.36 9.55Zm.675.675a2.385 2.385 0 0 1 3.373 0l2.53 2.53a2.385 2.385 0 0 1 0 3.373L34.553 27.514a1.193 1.193 0 0 0 0 1.686l11.385 11.385a2.385 2.385 0 0 1 0 3.374l-2.53 2.53a2.385 2.385 0 0 1-3.373 0L28.65 35.104a1.193 1.193 0 0 0-1.687 0L15.578 46.489a2.385 2.385 0 0 1-3.373 0l-2.53-2.53a2.385 2.385 0 0 1 0-3.374L21.06 29.2a1.193 1.193 0 0 0 0-1.686L9.675 16.129a2.385 2.385 0 0 1 0-3.373l2.53-2.53a2.385 2.385 0 0 1 3.373 0L26.963 21.61c.466.466 1.221.466 1.687 0l11.385-11.384Z",
                                    fill: "#E2E2E2"
                                }), (0, e.jsx)("path", {
                                    fillRule: "evenodd",
                                    clipRule: "evenodd",
                                    d: "M39.36 9.551a3.34 3.34 0 0 1 4.723 0l2.53 2.53a3.34 3.34 0 0 1 0 4.723L35.227 28.188a.239.239 0 0 0 0 .338L46.613 39.91a3.34 3.34 0 0 1 0 4.722l-2.53 2.53a3.34 3.34 0 0 1-4.723 0L27.975 35.778a.239.239 0 0 0-.337 0L16.253 47.163a3.34 3.34 0 0 1-4.723 0L9 44.633a3.34 3.34 0 0 1 0-4.722l11.385-11.385a.239.239 0 0 0 0-.338L9 16.804a3.34 3.34 0 0 1 0-4.723l2.53-2.53a3.34 3.34 0 0 1 4.723 0l11.385 11.385a.239.239 0 0 0 .337 0L39.36 9.55Zm.675.675a2.385 2.385 0 0 1 3.373 0l2.53 2.53a2.385 2.385 0 0 1 0 3.373L34.553 27.514a1.193 1.193 0 0 0 0 1.686l11.385 11.385a2.385 2.385 0 0 1 0 3.374l-2.53 2.53a2.385 2.385 0 0 1-3.373 0L28.65 35.104a1.193 1.193 0 0 0-1.687 0L15.578 46.489a2.385 2.385 0 0 1-3.373 0l-2.53-2.53a2.385 2.385 0 0 1 0-3.374L21.06 29.2a1.193 1.193 0 0 0 0-1.686L9.675 16.129a2.385 2.385 0 0 1 0-3.373l2.53-2.53a2.385 2.385 0 0 1 3.373 0L26.963 21.61c.466.466 1.221.466 1.687 0l11.385-11.384Z",
                                    fill: "url(#Gradient-3_cr_d)"
                                }), (0, e.jsx)("path", {
                                    d: "M19.263 32.051c.336 8.28-5.096 10.683-7.854 10.85-5.237-.655 1.651-3.229 4.258-8.555 2.086-4.261 3.267-3.305 3.596-2.295Z",
                                    fill: "url(#Gradient-4_cr_d)",
                                    transform: "matrix(.69565 0 0 .68775 5.984 12.626)",
                                    style: {
                                        animation: ".4s linear both a1_t_cr_d"
                                    }
                                }), (0, e.jsx)("path", {
                                    d: "M16.417 22.512c-1.922-6.724 2.141-6.982 4.413-6.27 4.507 2.126-.74 2.076-1.863 5.536-.898 2.769-2.074 1.643-2.55.734Z",
                                    fill: "url(#Gradient-5_cr_d)",
                                    fillOpacity: .6,
                                    transform: "translate(4 4.39) scale(.69692)",
                                    style: {
                                        animation: ".4s linear both a2_t_cr_d"
                                    }
                                }), (0, e.jsx)("path", {
                                    d: "M35.168 25.564c-.336-8.281 5.096-10.684 7.854-10.85 5.237.654-1.651 3.229-4.258 8.555-2.086 4.26-3.267 3.305-3.596 2.295Z",
                                    fill: "url(#Gradient-6_cr_d)",
                                    fillOpacity: .6,
                                    style: {
                                        animation: ".4s linear both a3_t_cr_d"
                                    }
                                }), (0, e.jsx)("path", {
                                    d: "M27.007 29.814c1.866 7.643 5.57 8.719 7.188 8.301 4.173-1.915.778-14.985-1.107-17.311-1.885-2.326-8.414-.543-6.081 9.01Z",
                                    fill: "url(#Gradient-7_cr_d)",
                                    fillOpacity: .6,
                                    style: {
                                        animation: ".4s linear both a4_t_cr_d"
                                    }
                                }), (0, e.jsx)("path", {
                                    fillRule: "evenodd",
                                    clipRule: "evenodd",
                                    d: "M12.948 13.266a.894.894 0 0 1 1.265.002l9.498 9.524a5.963 5.963 0 0 0 8.445 0l9.498-9.524a.894.894 0 1 1 1.267 1.263l-9.525 9.552a5.963 5.963 0 0 0 0 8.421l9.525 9.552a.894.894 0 1 1-1.267 1.263l-9.498-9.525a5.963 5.963 0 0 0-8.445 0l-9.498 9.525a.895.895 0 0 1-1.267-1.263l9.525-9.552a5.963 5.963 0 0 0 0-8.421l-9.525-9.552a.894.894 0 0 1 .002-1.265Z",
                                    fill: "url(#Gradient-8_cr_d)",
                                    style: {
                                        animation: ".4s linear both a5_t_cr_d"
                                    }
                                }), (0, e.jsx)("circle", {
                                    fill: "#94D9F6",
                                    transform: "translate(26.508 27.06)",
                                    r: .54
                                }), (0, e.jsx)("circle", {
                                    opacity: .2,
                                    fill: "url(#Gradient-9_cr_d)",
                                    transform: "translate(26.509 27.06)",
                                    r: 2.48
                                }), (0, e.jsx)("path", {
                                    fillRule: "evenodd",
                                    clipRule: "evenodd",
                                    d: "M12.052 16.59a.54.54 0 0 1 .764.022l2.322 2.46a.54.54 0 0 1-.785.742l-2.323-2.46a.54.54 0 0 1 .022-.764Z",
                                    fill: "#94D9F6"
                                }), (0, e.jsx)("circle", {
                                    fill: "#94D9F6",
                                    transform: "rotate(-70.181 22.464 -.895)",
                                    r: .54
                                })]
                            })
                        })]
                    })
                },
                d = function() {
                    return (0, e.jsxs)("svg", {
                        xmlns: "http://www.w3.org/2000/svg",
                        width: 56,
                        height: 56,
                        fill: "none",
                        style: {
                            background: "0 0"
                        },
                        children: [(0, e.jsxs)("defs", {
                            children: [(0, e.jsxs)("linearGradient", {
                                id: "Gradient-0_s_d",
                                x1: 28.392,
                                y1: .972,
                                x2: 40.632,
                                y2: 48.291,
                                gradientUnits: "userSpaceOnUse",
                                children: [(0, e.jsx)("stop", {
                                    offset: 0,
                                    stopColor: "#fba416",
                                    stopOpacity: 0
                                }), (0, e.jsx)("stop", {
                                    offset: 1,
                                    stopColor: "#fdbb4e",
                                    stopOpacity: .63
                                })]
                            }), (0, e.jsxs)("linearGradient", {
                                id: "Gradient-1_s_d",
                                x1: 28.392,
                                y1: .972,
                                x2: 40.633,
                                y2: 48.291,
                                gradientUnits: "userSpaceOnUse",
                                children: [(0, e.jsx)("stop", {
                                    offset: 0,
                                    stopColor: "#fdbb4e",
                                    stopOpacity: 0
                                }), (0, e.jsx)("stop", {
                                    offset: 1,
                                    stopColor: "#fdbb4e",
                                    stopOpacity: .63
                                })]
                            }), (0, e.jsxs)("linearGradient", {
                                id: "Gradient-3_s_d",
                                x1: 43.739,
                                y1: 37.512,
                                x2: 18.526,
                                y2: 14.674,
                                gradientUnits: "userSpaceOnUse",
                                children: [(0, e.jsx)("stop", {
                                    offset: 0,
                                    stopColor: "#feffd3",
                                    stopOpacity: .63
                                }), (0, e.jsx)("stop", {
                                    offset: .219,
                                    stopColor: "#fafd4e",
                                    stopOpacity: 0
                                }), (0, e.jsx)("stop", {
                                    offset: .491,
                                    stopColor: "#fdff8b",
                                    stopOpacity: .56
                                }), (0, e.jsx)("stop", {
                                    offset: .733,
                                    stopColor: "#f7f990"
                                }), (0, e.jsx)("stop", {
                                    offset: 1,
                                    stopColor: "#fff",
                                    stopOpacity: 0
                                }), (0, e.jsx)("stop", {
                                    offset: 1,
                                    stopColor: "#feffb7",
                                    stopOpacity: 0
                                })]
                            }), (0, e.jsxs)("linearGradient", {
                                id: "Gradient-4_s_d",
                                x1: 28.391,
                                y1: 14.126,
                                x2: 28.026,
                                y2: 38.425,
                                gradientUnits: "userSpaceOnUse",
                                children: [(0, e.jsx)("stop", {
                                    offset: 0,
                                    stopColor: "#feffb0"
                                }), (0, e.jsx)("stop", {
                                    offset: .277,
                                    stopColor: "#fff",
                                    stopOpacity: .51
                                }), (0, e.jsx)("stop", {
                                    offset: 1,
                                    stopColor: "#fafd4e",
                                    stopOpacity: .15
                                })]
                            }), (0, e.jsxs)("linearGradient", {
                                id: "Gradient-5_s_d",
                                x1: 27.214,
                                y1: 23.393,
                                x2: 27.033,
                                y2: 32.029,
                                gradientUnits: "userSpaceOnUse",
                                children: [(0, e.jsx)("stop", {
                                    offset: 0,
                                    stopColor: "#fafd4e",
                                    stopOpacity: 0
                                }), (0, e.jsx)("stop", {
                                    offset: .732,
                                    stopColor: "#fafd4e",
                                    stopOpacity: .46
                                })]
                            }), (0, e.jsxs)("linearGradient", {
                                id: "Gradient-6_s_d",
                                x1: 24.792,
                                y1: 18.563,
                                x2: 29.645,
                                y2: 23.143,
                                gradientUnits: "userSpaceOnUse",
                                children: [(0, e.jsx)("stop", {
                                    offset: .224,
                                    stopColor: "#fafd4e",
                                    stopOpacity: .35
                                }), (0, e.jsx)("stop", {
                                    offset: 1,
                                    stopColor: "#fafd4e",
                                    stopOpacity: 0
                                })]
                            }), (0, e.jsxs)("linearGradient", {
                                id: "Gradient-7_s_d",
                                x1: .016,
                                y1: 26.376,
                                x2: 16.573,
                                y2: 26.055,
                                gradientUnits: "userSpaceOnUse",
                                children: [(0, e.jsx)("stop", {
                                    offset: 0,
                                    stopColor: "#fff"
                                }), (0, e.jsx)("stop", {
                                    offset: 1,
                                    stopColor: "#fff",
                                    stopOpacity: 0
                                })]
                            }), (0, e.jsxs)("radialGradient", {
                                id: "Gradient-2_s_d",
                                cx: 0,
                                cy: 0,
                                r: 1,
                                fx: 0,
                                fy: 0,
                                gradientUnits: "userSpaceOnUse",
                                gradientTransform: "rotate(52.671 -10.467 32.845) scale(31.9369)",
                                children: [(0, e.jsx)("stop", {
                                    offset: .739,
                                    stopColor: "#9cb6dd",
                                    stopOpacity: 0
                                }), (0, e.jsx)("stop", {
                                    offset: .898,
                                    stopColor: "#c6f1ff",
                                    stopOpacity: .37
                                }), (0, e.jsx)("stop", {
                                    offset: 1,
                                    stopColor: "#effbff",
                                    stopOpacity: .7
                                })]
                            }), (0, e.jsx)("mask", {
                                id: "Mask-1_s_d",
                                children: (0, e.jsx)("path", {
                                    fill: "url(#Gradient-7_s_d)",
                                    transform: "rotate(30 9.136 128.63)",
                                    style: {
                                        animation: ".4s linear both a3_t_s_d"
                                    },
                                    d: "M0 0h16.959v56H0z"
                                })
                            })]
                        }), (0, e.jsx)("style", {
                            children: "@keyframes star_t_s_d{0%{transform:translate(28.3918px,26.0576px) scale(1,1) translate(-23.4974px,-22.4547px);animation-timing-function:cubic-bezier(.42,0,1,1)}25%{transform:translate(28.3918px,26.0576px) scale(1.15,1.15) translate(-23.4974px,-22.4547px);animation-timing-function:cubic-bezier(0,0,.58,1)}50%{transform:translate(28.3918px,26.0576px) scale(1,1) translate(-23.4974px,-22.4547px)}to{transform:translate(28.3918px,26.0576px) scale(0,0) translate(-23.4974px,-22.4547px)}}@keyframes a0_t_s_d{0%{transform:translate(23.4966px,22.4549px) scale(1,1) translate(-28.3911px,-27.0603px)}to{transform:translate(23.4966px,22.4549px) scale(1.737025,1.737025) translate(-28.3911px,-27.0603px)}}@keyframes a1_t_s_d{0%{transform:translate(22.2182px,22.7642px) rotate(0deg) scale(1,1) translate(-27.1127px,-26.3671px)}to{transform:translate(22.2182px,22.7642px) rotate(145.526246deg) scale(.462454,.462454) translate(-27.1127px,-26.3671px)}}@keyframes a1_o_s_d{0%{opacity:1}to{opacity:0}}@keyframes a2_t_s_d{0%{transform:translate(21.8514px,17.0372px) rotate(0deg) scale(1,1) translate(-26.7458px,-20.6401px)}to{transform:translate(18.9293px,24.3971px) rotate(-53.127557deg) scale(.322292,.322292) translate(-26.7458px,-20.6401px)}}@keyframes a2_o_s_d{0%{opacity:1}to{opacity:0}}@keyframes a3_t_s_d{0%,to{transform:translate(58.8824px,41.1538px) rotate(30deg) translate(-8.47967px,-28px)}}"
                        }), (0, e.jsxs)("g", {
                            id: "star",
                            transform: "translate(4.894 3.603)",
                            style: {
                                animation: ".4s linear both star_t_s_d"
                            },
                            children: [(0, e.jsx)("path", {
                                d: "M26.439 4.8c.813-1.595 3.092-1.595 3.905 0l5.7 11.17a2.192 2.192 0 0 0 1.609 1.168l12.385 1.97c1.768.28 2.472 2.448 1.207 3.714l-8.862 8.873a2.193 2.193 0 0 0-.615 1.891l1.955 12.388c.279 1.768-1.565 3.107-3.16 2.295l-11.177-5.686a2.192 2.192 0 0 0-1.989 0L16.22 48.269c-1.595.812-3.439-.527-3.16-2.295l1.955-12.388a2.192 2.192 0 0 0-.615-1.89l-8.862-8.874c-1.265-1.266-.561-3.433 1.207-3.714l12.385-1.97a2.192 2.192 0 0 0 1.609-1.168l5.7-11.17Z",
                                fill: "#C22A20",
                                transform: "translate(-4.894 -3.603)"
                            }), (0, e.jsx)("path", {
                                d: "M26.439 4.8c.813-1.595 3.092-1.595 3.905 0l5.7 11.17a2.192 2.192 0 0 0 1.609 1.168l12.385 1.97c1.768.28 2.472 2.448 1.207 3.714l-8.862 8.873a2.193 2.193 0 0 0-.615 1.891l1.955 12.388c.279 1.768-1.565 3.107-3.16 2.295l-11.177-5.686a2.192 2.192 0 0 0-1.989 0L16.22 48.269c-1.595.812-3.439-.527-3.16-2.295l1.955-12.388a2.192 2.192 0 0 0-.615-1.89l-8.862-8.874c-1.265-1.266-.561-3.433 1.207-3.714l12.385-1.97a2.192 2.192 0 0 0 1.609-1.168l5.7-11.17Z",
                                fill: "url(#Gradient-0_s_d)",
                                transform: "translate(-4.894 -3.603)"
                            }), (0, e.jsx)("path", {
                                d: "M26.44 4.799c.813-1.595 3.091-1.595 3.905 0l5.7 11.17a2.192 2.192 0 0 0 1.609 1.169l12.385 1.97c1.768.28 2.472 2.447 1.207 3.714l-8.863 8.873a2.192 2.192 0 0 0-.614 1.89l1.954 12.388c.28 1.769-1.564 3.108-3.16 2.296l-11.177-5.687a2.193 2.193 0 0 0-1.988 0L16.22 48.27c-1.596.812-3.44-.527-3.16-2.296l1.954-12.387a2.192 2.192 0 0 0-.614-1.891l-8.863-8.873c-1.265-1.267-.56-3.434 1.207-3.715l12.386-1.969a2.192 2.192 0 0 0 1.608-1.169l5.7-11.17Z",
                                fill: "url(#Gradient-1_s_d)",
                                transform: "translate(-4.894 -3.603)"
                            }), (0, e.jsx)("path", {
                                d: "M26.44 4.799c.813-1.595 3.091-1.595 3.905 0l5.7 11.17a2.192 2.192 0 0 0 1.609 1.169l12.385 1.97c1.768.28 2.472 2.447 1.207 3.714l-8.863 8.873a2.192 2.192 0 0 0-.614 1.89l1.954 12.388c.28 1.769-1.564 3.108-3.16 2.296l-11.177-5.687a2.193 2.193 0 0 0-1.988 0L16.22 48.27c-1.596.812-3.44-.527-3.16-2.296l1.954-12.387a2.192 2.192 0 0 0-.614-1.891l-8.863-8.873c-1.265-1.267-.56-3.434 1.207-3.715l12.386-1.969a2.192 2.192 0 0 0 1.608-1.169l5.7-11.17Z",
                                fill: "url(#Gradient-2_s_d)",
                                transform: "translate(-4.894 -3.603)"
                            }), (0, e.jsx)("path", {
                                fillRule: "evenodd",
                                clipRule: "evenodd",
                                d: "m35.394 16.302-5.7-11.171c-.542-1.063-2.061-1.063-2.604 0l-5.7 11.17a2.923 2.923 0 0 1-2.145 1.559L6.86 19.829c-1.178.187-1.648 1.632-.804 2.476l8.862 8.873c.66.661.965 1.598.82 2.522l-1.955 12.387c-.186 1.179 1.043 2.072 2.106 1.53l11.178-5.686a2.923 2.923 0 0 1 2.65 0l11.178 5.687c1.064.54 2.292-.352 2.106-1.53L41.047 33.7a2.923 2.923 0 0 1 .82-2.522l8.862-8.873c.843-.844.374-2.289-.805-2.476l-12.385-1.97a2.923 2.923 0 0 1-2.145-1.558ZM30.345 4.799c-.814-1.595-3.092-1.595-3.906 0l-5.7 11.17a2.192 2.192 0 0 1-1.608 1.169l-12.386 1.97c-1.768.28-2.472 2.447-1.207 3.714l8.863 8.873c.495.496.723 1.198.614 1.89l-1.954 12.388c-.28 1.769 1.564 3.108 3.16 2.296l11.177-5.687a2.193 2.193 0 0 1 1.988 0l11.178 5.687c1.595.812 3.438-.527 3.16-2.296l-1.955-12.387c-.11-.693.119-1.395.614-1.891l8.863-8.873c1.265-1.267.56-3.434-1.207-3.715l-12.385-1.969a2.192 2.192 0 0 1-1.609-1.169l-5.7-11.17Z",
                                fill: "url(#Gradient-3_s_d)",
                                transform: "translate(-4.894 -3.603)"
                            }), (0, e.jsx)("path", {
                                d: "M27.442 15.766a1.096 1.096 0 0 1 1.898 0l3.338 5.77c.156.268.417.458.72.523l6.52 1.392a1.096 1.096 0 0 1 .586 1.805l-4.456 4.958c-.207.23-.307.538-.275.846l.69 6.63a1.096 1.096 0 0 1-1.535 1.116L28.836 36.1a1.095 1.095 0 0 0-.89 0l-6.092 2.706a1.096 1.096 0 0 1-1.535-1.115l.69-6.63a1.096 1.096 0 0 0-.275-.847l-4.456-4.958a1.096 1.096 0 0 1 .587-1.805l6.519-1.392c.303-.065.565-.255.72-.523l3.338-5.77Z",
                                fill: "url(#Gradient-4_s_d)",
                                transform: "translate(-4.895 -4.605)",
                                style: {
                                    animation: ".4s linear both a0_t_s_d"
                                }
                            }), (0, e.jsx)("path", {
                                d: "M42.308 24.355c-13.225 12.498-25.037 6.97-29.29 2.644-6.47-9.614 7.727-1.923 20.305-5.288 10.063-2.692 10.183.641 8.985 2.644Z",
                                fill: "url(#Gradient-5_s_d)",
                                transform: "translate(-4.895 -3.603)",
                                style: {
                                    animation: ".4s linear both a1_t_s_d,.4s linear both a1_o_s_d"
                                }
                            }), (0, e.jsx)("path", {
                                fillRule: "evenodd",
                                clipRule: "evenodd",
                                d: "M26.893 7.286c.27.137.378.467.241.737l-1.55 3.063a.548.548 0 1 1-.977-.495l1.55-3.063a.548.548 0 0 1 .736-.242Z",
                                fill: "#F9BE76",
                                transform: "translate(-4.895 -3.603)"
                            }), (0, e.jsx)("circle", {
                                fill: "#F9BE76",
                                transform: "translate(3.035 16.918)",
                                r: .548
                            }), (0, e.jsx)("circle", {
                                fill: "#F9BE76",
                                transform: "translate(19.477 8.514)",
                                r: .548
                            }), (0, e.jsx)("path", {
                                d: "M23.157 17.775c-4.158 5.89-2.672 9.096-1.41 9.963 3.835 1.73 10.822-8.482 11.295-11.184.473-2.703-4.688-6.14-9.885 1.221Z",
                                fill: "url(#Gradient-6_s_d)",
                                fillOpacity: .6,
                                transform: "translate(-4.894 -3.603)",
                                style: {
                                    animation: ".4s linear both a2_t_s_d,.4s linear both a2_o_s_d"
                                }
                            }), (0, e.jsx)("path", {
                                id: "mask-flex",
                                d: "M26.439 4.8c.813-1.595 3.092-1.595 3.905 0l5.7 11.17a2.192 2.192 0 0 0 1.609 1.168l12.385 1.97c1.768.28 2.472 2.448 1.207 3.714l-8.862 8.873a2.193 2.193 0 0 0-.615 1.891l1.955 12.388c.279 1.768-1.565 3.107-3.16 2.295l-11.177-5.686a2.192 2.192 0 0 0-1.989 0L16.22 48.269c-1.595.812-3.439-.527-3.16-2.295l1.955-12.388a2.192 2.192 0 0 0-.615-1.89l-8.862-8.874c-1.265-1.266-.561-3.433 1.207-3.714l12.385-1.97a2.192 2.192 0 0 0 1.609-1.168l5.7-11.17Z",
                                fill: "#fff3bf",
                                mask: "url(#Mask-1_s_d)",
                                transform: "translate(-4.894 -3.603)"
                            })]
                        })]
                    })
                },
                x = function(t) {
                    var s = t.id;
                    return (0, e.jsxs)("svg", {
                        xmlns: "http://www.w3.org/2000/svg",
                        width: 56,
                        height: 56,
                        fill: "none",
                        children: [(0, e.jsxs)("defs", {
                            children: [(0, e.jsxs)("radialGradient", {
                                id: "Gradient-2_c_2_d".concat(s),
                                cx: 0,
                                cy: 0,
                                r: 1,
                                fx: 0,
                                fy: 0,
                                gradientUnits: "userSpaceOnUse",
                                gradientTransform: "matrix(28.6228 -7.61449 6.96925 26.1973 5.358 50.625)",
                                children: [(0, e.jsx)("stop", {
                                    offset: 0,
                                    stopColor: "#1c2130"
                                }), (0, e.jsx)("stop", {
                                    offset: 1,
                                    stopColor: "#1c2130",
                                    stopOpacity: 0
                                })]
                            }), (0, e.jsxs)("radialGradient", {
                                id: "Gradient-3_c_2_d",
                                cx: 0,
                                cy: 0,
                                r: 1,
                                fx: 0,
                                fy: 0,
                                gradientUnits: "userSpaceOnUse",
                                gradientTransform: "matrix(-26.8297 -12.5463 11.4831 -24.5562 19.703 45.611)",
                                children: [(0, e.jsx)("stop", {
                                    offset: 0,
                                    stopColor: "#1c2130"
                                }), (0, e.jsx)("stop", {
                                    offset: 1,
                                    stopColor: "#1c2130",
                                    stopOpacity: 0
                                })]
                            }), (0, e.jsxs)("linearGradient", {
                                id: "Gradient-0_c_2_d".concat(s),
                                x1: 58.152,
                                y1: 24.257,
                                x2: -3.614,
                                y2: 28.984,
                                gradientUnits: "userSpaceOnUse",
                                children: [(0, e.jsx)("stop", {
                                    offset: 0,
                                    stopColor: "#d8fffc",
                                    stopOpacity: .63
                                }), (0, e.jsx)("stop", {
                                    offset: .219,
                                    stopColor: "#a0fff7",
                                    stopOpacity: 0
                                }), (0, e.jsx)("stop", {
                                    offset: .491,
                                    stopColor: "#8dfff6",
                                    stopOpacity: .56
                                }), (0, e.jsx)("stop", {
                                    offset: .733,
                                    stopColor: "#9af8f0"
                                }), (0, e.jsx)("stop", {
                                    offset: 1,
                                    stopColor: "#fff",
                                    stopOpacity: 0
                                }), (0, e.jsx)("stop", {
                                    offset: 1,
                                    stopColor: "#bafff9",
                                    stopOpacity: 0
                                })]
                            }), (0, e.jsxs)("linearGradient", {
                                id: "Gradient-1_c_2_d".concat(s),
                                x1: 24,
                                y1: 0,
                                x2: 24,
                                y2: 48,
                                gradientUnits: "userSpaceOnUse",
                                children: [(0, e.jsx)("stop", {
                                    offset: 0,
                                    stopColor: "#37b0ce"
                                }), (0, e.jsx)("stop", {
                                    offset: 1,
                                    stopColor: "#01586b"
                                })]
                            }), (0, e.jsx)("clipPath", {
                                id: "clip0_366_7284_c_2_d",
                                children: (0, e.jsx)("rect", {
                                    width: 56,
                                    height: 56,
                                    rx: 7.593,
                                    fill: "#fff"
                                })
                            })]
                        }), (0, e.jsx)("style", {
                            children: "@keyframes a0_t_c_2_d{0%{transform:translate(28px,28px) scale(.9,.9) translate(-28px,-28px)}to{transform:translate(28px,28px) scale(0,0) translate(-28px,-28px)}}@keyframes a1_o_c_2_d{0%,to{opacity:.6}}"
                        }), (0, e.jsxs)("g", {
                            clipPath: "url(#clip0_366_7284_c_2_d)",
                            transform: "matrix(.9 0 0 .9 2.8 2.8)",
                            style: {
                                animation: ".2s linear both a0_t_c_2_d"
                            },
                            children: [(0, e.jsx)("rect", {
                                opacity: .7,
                                width: 56,
                                height: 56,
                                rx: 12,
                                fill: "#151C2E"
                            }), (0, e.jsx)("rect", {
                                opacity: .6,
                                width: 52,
                                height: 52,
                                rx: 10,
                                fill: "url(#Gradient-0_c_2_d".concat(s, ")"),
                                transform: "translate(2 2)"
                            }), (0, e.jsx)("rect", {
                                width: 48,
                                height: 48,
                                rx: 8,
                                fill: "url(#Gradient-1_c_2_d".concat(s, ")"),
                                transform: "translate(4 4)"
                            }), (0, e.jsx)("path", {
                                opacity: .1,
                                fillRule: "evenodd",
                                clipRule: "evenodd",
                                d: "M14.834 60.127c3.731 1.672 7.732.204 11.798-.231 4.245-.454 9.628 1.157 12.1-2.325 2.466-3.477-1.482-7.917-1.818-12.166-.375-4.74 2.845-10.093-.23-13.719-3.261-3.844-9.295-4.521-14.177-3.264-4.482 1.155-6.48 5.88-9.52 9.37-3.412 3.912-9.48 6.762-9.052 11.935.43 5.202 6.134 8.266 10.899 10.4Z",
                                fill: "url(#Gradient-2_c_2_d".concat(s, ")")
                            }), (0, e.jsx)("path", {
                                opacity: .1,
                                fillRule: "evenodd",
                                clipRule: "evenodd",
                                d: "M8.7 53.292c-3.968.987-7.647-1.164-11.573-2.31-4.098-1.196-9.681-.56-11.498-4.423-1.815-3.857 2.854-7.531 3.935-11.655 1.205-4.599-1.02-10.436 2.648-13.462 3.888-3.208 9.947-2.81 14.53-.711 4.208 1.928 5.34 6.931 7.718 10.902 2.667 4.453 8.137 8.33 6.803 13.346-1.342 5.045-7.497 7.053-12.563 8.313Z",
                                fill: "url(#Gradient-3_c_2_d".concat(s, ")")
                            }), (0, e.jsx)("rect", {
                                opacity: .6,
                                width: 56,
                                height: 56,
                                rx: 12,
                                fill: "#151C2E",
                                style: {
                                    animation: ".2s linear both a1_o_c_2_d"
                                }
                            })]
                        })]
                    })
                },
                _ = function(t) {
                    var s = t.id;
                    return (0, e.jsxs)("svg", {
                        xmlns: "http://www.w3.org/2000/svg",
                        width: 56,
                        height: 56,
                        fill: "none",
                        children: [(0, e.jsxs)("defs", {
                            children: [(0, e.jsxs)("radialGradient", {
                                id: "Gradient-2_c_2_t".concat(s),
                                cx: 0,
                                cy: 0,
                                r: 1,
                                fx: 0,
                                fy: 0,
                                gradientUnits: "userSpaceOnUse",
                                gradientTransform: "matrix(28.6228 -7.61449 6.96925 26.1973 5.358 50.625)",
                                children: [(0, e.jsx)("stop", {
                                    offset: 0,
                                    stopColor: "#1c2130"
                                }), (0, e.jsx)("stop", {
                                    offset: 1,
                                    stopColor: "#1c2130",
                                    stopOpacity: 0
                                })]
                            }), (0, e.jsxs)("radialGradient", {
                                id: "Gradient-3_c_2_t".concat(s),
                                cx: 0,
                                cy: 0,
                                r: 1,
                                fx: 0,
                                fy: 0,
                                gradientUnits: "userSpaceOnUse",
                                gradientTransform: "matrix(-26.8297 -12.5463 11.4831 -24.5562 19.703 45.611)",
                                children: [(0, e.jsx)("stop", {
                                    offset: 0,
                                    stopColor: "#1c2130"
                                }), (0, e.jsx)("stop", {
                                    offset: 1,
                                    stopColor: "#1c2130",
                                    stopOpacity: 0
                                })]
                            }), (0, e.jsxs)("linearGradient", {
                                id: "Gradient-0_c_2_t".concat(s),
                                x1: 58.152,
                                y1: 24.257,
                                x2: -3.614,
                                y2: 28.984,
                                gradientUnits: "userSpaceOnUse",
                                children: [(0, e.jsx)("stop", {
                                    offset: 0,
                                    stopColor: "#d8fffc",
                                    stopOpacity: .63
                                }), (0, e.jsx)("stop", {
                                    offset: .219,
                                    stopColor: "#a0fff7",
                                    stopOpacity: 0
                                }), (0, e.jsx)("stop", {
                                    offset: .491,
                                    stopColor: "#8dfff6",
                                    stopOpacity: .56
                                }), (0, e.jsx)("stop", {
                                    offset: .733,
                                    stopColor: "#9af8f0"
                                }), (0, e.jsx)("stop", {
                                    offset: 1,
                                    stopColor: "#fff",
                                    stopOpacity: 0
                                }), (0, e.jsx)("stop", {
                                    offset: 1,
                                    stopColor: "#bafff9",
                                    stopOpacity: 0
                                })]
                            }), (0, e.jsxs)("linearGradient", {
                                id: "Gradient-1_c_2_t".concat(s),
                                x1: 24,
                                y1: 0,
                                x2: 24,
                                y2: 48,
                                gradientUnits: "userSpaceOnUse",
                                children: [(0, e.jsx)("stop", {
                                    offset: 0,
                                    stopColor: "#37b0ce"
                                }), (0, e.jsx)("stop", {
                                    offset: 1,
                                    stopColor: "#01586b"
                                })]
                            }), (0, e.jsx)("clipPath", {
                                id: "clip0_366_7284_c_2_t",
                                children: (0, e.jsx)("rect", {
                                    width: 56,
                                    height: 56,
                                    rx: 7.593,
                                    fill: "#fff"
                                })
                            })]
                        }), (0, e.jsx)("style", {
                            children: "@keyframes a0_t_c_2_t{0%{transform:translate(28px,28px) scale(1,1) translate(-28px,-28px)}to{transform:translate(28px,28px) scale(.9,.9) translate(-28px,-28px)}}@keyframes a1_o_c_2_t{0%{opacity:0}to{opacity:.6}}"
                        }), (0, e.jsxs)("g", {
                            clipPath: "url(#clip0_366_7284_c_2_t)",
                            style: {
                                animation: ".2s linear both a0_t_c_2_t"
                            },
                            children: [(0, e.jsx)("rect", {
                                opacity: .7,
                                width: 56,
                                height: 56,
                                rx: 12,
                                fill: "#151C2E"
                            }), (0, e.jsx)("rect", {
                                opacity: .6,
                                width: 52,
                                height: 52,
                                rx: 10,
                                fill: "url(#Gradient-0_c_2_t".concat(s, ")"),
                                transform: "translate(2 2)"
                            }), (0, e.jsx)("rect", {
                                width: 48,
                                height: 48,
                                rx: 8,
                                fill: "url(#Gradient-1_c_2_t".concat(s, ")"),
                                transform: "translate(4 4)"
                            }), (0, e.jsx)("path", {
                                opacity: .1,
                                fillRule: "evenodd",
                                clipRule: "evenodd",
                                d: "M14.834 60.127c3.731 1.672 7.732.204 11.798-.231 4.245-.454 9.628 1.157 12.1-2.325 2.466-3.477-1.482-7.917-1.818-12.166-.375-4.74 2.845-10.093-.23-13.719-3.261-3.844-9.295-4.521-14.177-3.264-4.482 1.155-6.48 5.88-9.52 9.37-3.412 3.912-9.48 6.762-9.052 11.935.43 5.202 6.134 8.266 10.899 10.4Z",
                                fill: "url(#Gradient-2_c_2_t".concat(s, ")")
                            }), (0, e.jsx)("path", {
                                opacity: .1,
                                fillRule: "evenodd",
                                clipRule: "evenodd",
                                d: "M8.7 53.292c-3.968.987-7.647-1.164-11.573-2.31-4.098-1.196-9.681-.56-11.498-4.423-1.815-3.857 2.854-7.531 3.935-11.655 1.205-4.599-1.02-10.436 2.648-13.462 3.888-3.208 9.947-2.81 14.53-.711 4.208 1.928 5.34 6.931 7.718 10.902 2.667 4.453 8.137 8.33 6.803 13.346-1.342 5.045-7.497 7.053-12.563 8.313Z",
                                fill: "url(#Gradient-3_c_2_t".concat(s, ")")
                            }), (0, e.jsx)("rect", {
                                opacity: 0,
                                width: 56,
                                height: 56,
                                rx: 12,
                                fill: "#151C2E",
                                transform: "translate(28,28) translate(-28,-28)",
                                style: {
                                    animation: "0.2s linear both a1_o_c_2_t"
                                }
                            })]
                        })]
                    })
                },
                u = function(t) {
                    var s = t.id;
                    return (0, e.jsxs)("svg", {
                        xmlns: "http://www.w3.org/2000/svg",
                        width: 56,
                        height: 56,
                        fill: "none",
                        viewBox: "0 0 54 54",
                        children: [(0, e.jsxs)("defs", {
                            children: [(0, e.jsxs)("radialGradient", {
                                id: "Gradient-2_c_1_r".concat(s),
                                cx: 0,
                                cy: 0,
                                r: 1,
                                fx: 0,
                                fy: 0,
                                gradientUnits: "userSpaceOnUse",
                                gradientTransform: "matrix(-17.6 -22.9 21 -16.1 36.6 48.7)",
                                children: [(0, e.jsx)("stop", {
                                    offset: 0,
                                    stopColor: "#1c2130"
                                }), (0, e.jsx)("stop", {
                                    offset: 1,
                                    stopColor: "#1c2130",
                                    stopOpacity: 0
                                })]
                            }), (0, e.jsxs)("radialGradient", {
                                id: "Gradient-3_c_1_r".concat(s),
                                cx: 0,
                                cy: 0,
                                r: 1,
                                fx: 0,
                                fy: 0,
                                gradientUnits: "userSpaceOnUse",
                                gradientTransform: "matrix(18.6 -22.1 20.3 17 24.3 38.3)",
                                children: [(0, e.jsx)("stop", {
                                    offset: 0,
                                    stopColor: "#1c2130"
                                }), (0, e.jsx)("stop", {
                                    offset: 1,
                                    stopColor: "#1c2130",
                                    stopOpacity: 0
                                })]
                            }), (0, e.jsxs)("linearGradient", {
                                id: "Gradient-0_c_1_r".concat(s),
                                x1: 52,
                                y1: 52,
                                x2: -2.3,
                                y2: 1,
                                gradientUnits: "userSpaceOnUse",
                                children: [(0, e.jsx)("stop", {
                                    offset: 0,
                                    stopColor: "#d8fffc",
                                    stopOpacity: .63
                                }), (0, e.jsx)("stop", {
                                    offset: .2,
                                    stopColor: "#a0fff7",
                                    stopOpacity: 0
                                }), (0, e.jsx)("stop", {
                                    offset: .5,
                                    stopColor: "#8dfff6",
                                    stopOpacity: .56
                                }), (0, e.jsx)("stop", {
                                    offset: .7,
                                    stopColor: "#9af8f0"
                                }), (0, e.jsx)("stop", {
                                    offset: 1,
                                    stopColor: "#fff",
                                    stopOpacity: 0
                                }), (0, e.jsx)("stop", {
                                    offset: 1,
                                    stopColor: "#bafff9",
                                    stopOpacity: 0
                                })]
                            }), (0, e.jsxs)("linearGradient", {
                                id: "Gradient-1_c_1_r".concat(s),
                                x1: 24,
                                y1: 0,
                                x2: 24,
                                y2: 48,
                                gradientUnits: "userSpaceOnUse",
                                children: [(0, e.jsx)("stop", {
                                    offset: 0,
                                    stopColor: "#37b0ce"
                                }), (0, e.jsx)("stop", {
                                    offset: 1,
                                    stopColor: "#01586b"
                                })]
                            }), (0, e.jsx)("clipPath", {
                                id: "ClipPath-1_c_1_r",
                                children: (0, e.jsx)("rect", {
                                    width: 56,
                                    height: 56,
                                    rx: 8,
                                    fill: "#fff"
                                })
                            })]
                        }), (0, e.jsx)("style", {
                            children: "@keyframes a0_t_c_1_r{0%{transform:translate(28px,28px) scale(0,0) translate(-28px,-28px);animation-timing-function:cubic-bezier(0,0,.6,1)}to{transform:translate(28px,28px) scale(1,1) translate(-28px,-28px)}}@keyframes a1_o_c_1_r{0%{opacity:.6}to{opacity:0}}"
                        }), (0, e.jsxs)("g", {
                            clipPath: "url(#ClipPath-1_c_1_r)",
                            transform: "matrix(0 0 0 0 28 28)",
                            style: {
                                animation: ".25s linear both a0_t_c_1_r"
                            },
                            children: [(0, e.jsx)("rect", {
                                opacity: .7,
                                width: 56,
                                height: 56,
                                rx: 8,
                                fill: "#151c2e"
                            }), (0, e.jsx)("path", {
                                opacity: .2,
                                fillRule: "evenodd",
                                clipRule: "evenodd",
                                d: "M31.3 73.8c.2-5.9 4.5-10.1 7.6-15.1 3.3-5.2 4.6-13.1 10.6-14.1s9.3 6.8 14.6 9.9c5.8 3.5 14.8 2.7 17.5 8.9 2.9 6.6 0 14.8-4.6 20.3-4.3 5.1-11.7 4.7-18.1 6.4-7.1 2-14.6 8-21 4.3-6.5-3.8-6.8-13.1-6.6-20.6ZM23.8 44.2c3.6 3.3 7.2 8 6.2 12.8-.9 4.8-7 5.7-10.6 9-3.8 3.5-5.4 11.3-10.6 10.7-5.3-.6-4.5-9-8.1-13-3.7-4.1-11.5-4.6-12.4-10.1-1-5.7 3.4-11.5 8.4-14.4 4.5-2.6 9.9.2 15 1.1 4.3.8 8.8.9 12.1 3.9ZM51.3-5.2c3.6 3.4 7.2 8 6.3 12.9-1 4.7-7.1 5.7-10.6 8.9-3.9 3.6-5.5 11.4-10.7 10.7-5.3-.6-4.5-9-8-12.9-3.7-4.2-11.6-4.6-12.5-10.1-1-5.7 3.4-11.6 8.4-14.4 4.6-2.6 9.9.1 15 1.1 4.3.8 8.8.9 12.1 3.8Z",
                                fill: "#1c2130"
                            }), (0, e.jsx)("rect", {
                                opacity: .6,
                                width: 52,
                                height: 52,
                                rx: 6,
                                fill: "url(#Gradient-0_c_1_r".concat(s, ")"),
                                transform: "translate(2 2)"
                            }), (0, e.jsx)("rect", {
                                width: 48,
                                height: 48,
                                rx: 4,
                                fill: "url(#Gradient-1_c_1_r".concat(s, ")"),
                                transform: "translate(4 4)"
                            }), (0, e.jsx)("path", {
                                opacity: .1,
                                fillRule: "evenodd",
                                clipRule: "evenodd",
                                d: "M23.6 50.4c-3.9-.9-6.1-4.4-9-7.2-3-2.9-8.1-4.8-8-9 .2-4.1 5.9-5.2 8.7-8.3 3.1-3.5 3.8-9.5 8.3-10.5 4.8-1 9.9 2 12.9 5.9 2.8 3.6 1.6 8.4 1.8 12.9.4 5.1 3.4 10.9 0 14.6-3.5 3.8-9.7 2.8-14.7 1.6Z",
                                fill: "url(#Gradient-2_c_1_r".concat(s, ")")
                            }), (0, e.jsx)("path", {
                                opacity: .1,
                                fillRule: "evenodd",
                                clipRule: "evenodd",
                                d: "M19.9 26c.1-4 3-6.9 5.1-10.3 2.1-3.6 3-9 7.1-9.7 4.1-.8 6.3 4.6 10 6.6 4 2.3 10.1 1.7 12 5.9 2 4.5.1 10.1-3 13.9-2.9 3.5-7.9 3.3-12.3 4.5-4.8 1.4-9.9 5.6-14.3 3.1-4.4-2.6-4.7-8.9-4.6-14Z",
                                fill: "url(#Gradient-3_c_1_r".concat(s, ")")
                            }), (0, e.jsx)("rect", {
                                opacity: .6,
                                width: 56,
                                height: 56,
                                rx: 8,
                                fill: "#151c2e",
                                style: {
                                    animation: ".25s linear both a1_o_c_1_r"
                                }
                            })]
                        })]
                    })
                },
                h = function(t) {
                    var s = t.id;
                    return (0, e.jsxs)("svg", {
                        xmlns: "http://www.w3.org/2000/svg",
                        width: 56,
                        height: 56,
                        fill: "none",
                        viewBox: "0 0 54 54",
                        children: [(0, e.jsxs)("defs", {
                            children: [(0, e.jsxs)("radialGradient", {
                                id: "Gradient-2_c_2_r".concat(s),
                                cx: 0,
                                cy: 0,
                                r: 1,
                                fx: 0,
                                fy: 0,
                                gradientUnits: "userSpaceOnUse",
                                gradientTransform: "matrix(28.6228 -7.61449 6.96925 26.1973 5.358 50.625)",
                                children: [(0, e.jsx)("stop", {
                                    offset: 0,
                                    stopColor: "#1c2130"
                                }), (0, e.jsx)("stop", {
                                    offset: 1,
                                    stopColor: "#1c2130",
                                    stopOpacity: 0
                                })]
                            }), (0, e.jsxs)("radialGradient", {
                                id: "Gradient-3_c_2_r".concat(s),
                                cx: 0,
                                cy: 0,
                                r: 1,
                                fx: 0,
                                fy: 0,
                                gradientUnits: "userSpaceOnUse",
                                gradientTransform: "matrix(-26.8297 -12.5463 11.4831 -24.5562 19.703 45.611)",
                                children: [(0, e.jsx)("stop", {
                                    offset: 0,
                                    stopColor: "#1c2130"
                                }), (0, e.jsx)("stop", {
                                    offset: 1,
                                    stopColor: "#1c2130",
                                    stopOpacity: 0
                                })]
                            }), (0, e.jsxs)("linearGradient", {
                                id: "Gradient-0_c_2_r".concat(s),
                                x1: 58.152,
                                y1: 24.257,
                                x2: -3.614,
                                y2: 28.984,
                                gradientUnits: "userSpaceOnUse",
                                children: [(0, e.jsx)("stop", {
                                    offset: 0,
                                    stopColor: "#d8fffc",
                                    stopOpacity: .63
                                }), (0, e.jsx)("stop", {
                                    offset: .219,
                                    stopColor: "#a0fff7",
                                    stopOpacity: 0
                                }), (0, e.jsx)("stop", {
                                    offset: .491,
                                    stopColor: "#8dfff6",
                                    stopOpacity: .56
                                }), (0, e.jsx)("stop", {
                                    offset: .733,
                                    stopColor: "#9af8f0"
                                }), (0, e.jsx)("stop", {
                                    offset: 1,
                                    stopColor: "#fff",
                                    stopOpacity: 0
                                }), (0, e.jsx)("stop", {
                                    offset: 1,
                                    stopColor: "#bafff9",
                                    stopOpacity: 0
                                })]
                            }), (0, e.jsxs)("linearGradient", {
                                id: "Gradient-1_c_2_r".concat(s),
                                x1: 24,
                                y1: 0,
                                x2: 24,
                                y2: 48,
                                gradientUnits: "userSpaceOnUse",
                                children: [(0, e.jsx)("stop", {
                                    offset: 0,
                                    stopColor: "#37b0ce"
                                }), (0, e.jsx)("stop", {
                                    offset: 1,
                                    stopColor: "#01586b"
                                })]
                            }), (0, e.jsx)("clipPath", {
                                id: "clip0_366_7284_c_2_r",
                                children: (0, e.jsx)("rect", {
                                    width: 56,
                                    height: 56,
                                    rx: 7.593,
                                    fill: "#fff"
                                })
                            })]
                        }), (0, e.jsx)("style", {
                            children: "@keyframes a0_t_c_2_r{0%{transform:translate(28px,28px) scale(0,0) translate(-28px,-28px);animation-timing-function:cubic-bezier(0,0,.58,1)}to{transform:translate(28px,28px) scale(1,1) translate(-28px,-28px)}}@keyframes a1_o_c_2_r{0%{opacity:.6}to{opacity:0}}"
                        }), (0, e.jsxs)("g", {
                            clipPath: "url(#clip0_366_7284_c_2_r)",
                            transform: "matrix(0 0 0 0 28 28)",
                            style: {
                                animation: ".25s linear both a0_t_c_2_r"
                            },
                            children: [(0, e.jsx)("rect", {
                                opacity: .7,
                                width: 56,
                                height: 56,
                                rx: 12,
                                fill: "#151C2E"
                            }), (0, e.jsx)("rect", {
                                opacity: .6,
                                width: 52,
                                height: 52,
                                rx: 10,
                                fill: "url(#Gradient-0_c_2_r".concat(s, ")"),
                                transform: "translate(2 2)"
                            }), (0, e.jsx)("rect", {
                                width: 48,
                                height: 48,
                                rx: 8,
                                fill: "url(#Gradient-1_c_2_r".concat(s, ")"),
                                transform: "translate(4 4)"
                            }), (0, e.jsx)("path", {
                                opacity: .1,
                                fillRule: "evenodd",
                                clipRule: "evenodd",
                                d: "M14.834 60.127c3.731 1.672 7.732.204 11.798-.231 4.245-.454 9.628 1.157 12.1-2.325 2.466-3.477-1.482-7.917-1.818-12.166-.375-4.74 2.845-10.093-.23-13.719-3.261-3.844-9.295-4.521-14.177-3.264-4.482 1.155-6.48 5.88-9.52 9.37-3.412 3.912-9.48 6.762-9.052 11.935.43 5.202 6.134 8.266 10.899 10.4Z",
                                fill: "url(#Gradient-2_c_2_r".concat(s, ")")
                            }), (0, e.jsx)("path", {
                                opacity: .1,
                                fillRule: "evenodd",
                                clipRule: "evenodd",
                                d: "M8.7 53.292c-3.968.987-7.647-1.164-11.573-2.31-4.098-1.196-9.681-.56-11.498-4.423-1.815-3.857 2.854-7.531 3.935-11.655 1.205-4.599-1.02-10.436 2.648-13.462 3.888-3.208 9.947-2.81 14.53-.711 4.208 1.928 5.34 6.931 7.718 10.902 2.667 4.453 8.137 8.33 6.803 13.346-1.342 5.045-7.497 7.053-12.563 8.313Z",
                                fill: "url(#Gradient-3_c_2_r".concat(s, ")")
                            }), (0, e.jsx)("rect", {
                                opacity: .6,
                                width: 56,
                                height: 56,
                                rx: 12,
                                fill: "#151C2E",
                                style: {
                                    animation: ".25s linear both a1_o_c_2_r"
                                }
                            })]
                        })]
                    })
                }
        },
        1684: function(t, s, a) {
            a.d(s, {
                A: function() {
                    return m
                }
            });
            var e = a(1413),
                r = a(184),
                o = function(t) {
                    var s = t.title,
                        a = t.Icon,
                        e = t.amount,
                        o = t.currency;
                    return (0, r.jsxs)("div", {
                        className: "status-bar__status",
                        children: [(0, r.jsx)("div", {
                            className: "status-bar__icon",
                            children: a
                        }), (0, r.jsxs)("div", {
                            className: "status-bar__status-content",
                            children: [(0, r.jsx)("span", {
                                className: "status-bar__status-title",
                                children: s
                            }), (0, r.jsxs)("div", {
                                className: "status-bar__status-text",
                                children: [(0, r.jsx)("span", {
                                    className: "status-bar__status-text-amount",
                                    id: "possibleMaxWinAmount",
                                    children: e
                                }), (0, r.jsx)("span", {
                                    className: "text-sm leading-4",
                                    children: "\xa0"
                                }), (0, r.jsx)("span", {
                                    className: "status-bar__status-text-currency",
                                    children: o
                                })]
                            })]
                        })]
                    })
                },
                i = a(3856),
                l = a(2791),
                n = function(t) {
                    var s = t.currentPreset,
                        a = t.onChange,
                        e = t.presets,
                        o = t.label,
                        n = t.onClickSound,
                        c = t.disabled,
                        p = (0, l.useMemo)((function() {
                            return s === e[0]
                        }), [e, s]),
                        f = (0, l.useMemo)((function() {
                            return s === e[e.length - 1]
                        }), [e, s]),
                        d = (0, l.useCallback)((function() {
                            var t = e.findIndex((function(t) {
                                return t === s
                            }));
                            p || (n && n(), a(e[t - 1]))
                        }), [n, e, s, p, a]),
                        x = (0, l.useCallback)((function() {
                            var t = e.findIndex((function(t) {
                                return t === s
                            }));
                            f || (n && n(), a(e[t + 1]))
                        }), [n, e, s, f, a]);
                    return (0, r.jsxs)("div", {
                        className: "select-traps status-bar__select-traps",
                        children: [(0, r.jsx)("button", {
                            className: "select-traps__prev-arrow-btn disabled:opacity-50",
                            type: "button",
                            disabled: p || c,
                            onClick: d,
                            id: "prev_preset_btn",
                            children: (0, r.jsx)(i.Eh, {
                                className: "select-traps__arrow-icon select-traps__arrow-icon_prev"
                            })
                        }), (0, r.jsxs)("div", {
                            className: "select-traps__content",
                            children: [(0, r.jsx)("span", {
                                className: "select-traps__traps_amount",
                                id: "trapsAmount",
                                children: s
                            }), (0, r.jsx)("span", {
                                className: "select-traps__title",
                                children: o
                            })]
                        }), (0, r.jsx)("button", {
                            className: "select-traps__next-arrow-btn disabled:opacity-50",
                            type: "button",
                            disabled: f || c,
                            onClick: x,
                            id: "next_preset_btn",
                            children: (0, r.jsx)(i.Eh, {
                                className: "select-traps__arrow-icon"
                            })
                        })]
                    })
                };
            n.defaultProps = {
                onClickSound: function() {},
                disabled: !1
            };
            var c = a(3433),
                p = a(5331),
                f = a(8182),
                d = function(t) {
                    var s = t.item,
                        a = t.active;
                    return (0, r.jsx)("div", {
                        className: "multiplier-list__item",
                        id: "coefMultiplier",
                        children: (0, r.jsx)("span", {
                            className: (0, f.W)("multiplier-list__item-text", a && "multiplier-list__item-text_active"),
                            children: s ? "X".concat(s) : ""
                        })
                    })
                },
                x = function(t) {
                    var s = t.items,
                        a = t.activeItemIndex,
                        e = (0, l.useRef)(null),
                        o = [].concat((0, c.Z)(s), (0, c.Z)(Array.from(Array(10))));
                    return (0, l.useEffect)((function() {
                        if (e.current) {
                            p.ZP.to(e.current, {
                                x: p.ZP.utils.unitize((function() {
                                    if (!e.current || 0 === a) return 0;
                                    var t = e.current.querySelectorAll(".multiplier-list__item");
                                    return -1 * Array.from(t).slice(0, a).reduce((function(t, s) {
                                        return t + s.offsetWidth + 8
                                    }), 0)
                                }), "px")
                            })
                        }
                    }), [a]), (0, r.jsx)("div", {
                        className: "multiplier-list",
                        children: (0, r.jsx)("div", {
                            className: "multiplier-list-inner overflow-visible",
                            ref: e,
                            children: o.map((function(t, s) {
                                return (0, r.jsx)(d, {
                                    item: t,
                                    active: s === a
                                }, t || s)
                            }))
                        })
                    })
                },
                _ = a(9664),
                u = a(3168),
                h = (0, l.createContext)(null),
                j = h.Provider,
                y = function() {
                    var t = function() {
                            var t = (0, l.useContext)(h);
                            if (!t) throw new Error("Can not use 'useStatusBarContext' outside of the StatusBarProvider");
                            return t
                        }(),
                        s = t.presets,
                        a = t.icon,
                        e = t.amount,
                        i = t.rates,
                        c = t.currency,
                        p = t.isSessionNotStarted,
                        f = t.showLastStep,
                        d = t.label,
                        j = t.coefficients,
                        y = t.activeItemIndex,
                        m = t.onClickSound,
                        C = t.isDisabledToChange,
                        g = (0, u.$)().t;
                    return (0, r.jsxs)("div", {
                        className: "status-bar",
                        children: [(0, r.jsx)(o, {
                            Icon: a,
                            title: g(p ? "MaxWinnings" : f ? "LastStep" : "NextStep"),
                            amount: function() {
                                var t;
                                return t = e.showMaxAmount ? e.bet * function() {
                                    var t = 0;
                                    return i && i.forEach((function(a) {
                                        a.presetValue === s.currentPreset && (t = a.rates[a.rates.length - 1])
                                    })), t
                                }() : Number(j[y] * e.bet), _.ZP.pipe((Math.round(100 * t) / 100).toString(), {
                                    mask: Number,
                                    scale: 2,
                                    thousandsSeparator: " ",
                                    normalizeZeros: !1,
                                    padFractionalZeros: !1,
                                    radix: ".",
                                    mapToRadix: ["."]
                                })
                            }(),
                            currency: c
                        }), p ? (0, r.jsx)(n, {
                            label: d,
                            currentPreset: s.currentPreset,
                            onChange: function(t) {
                                return s.onChangePreset(t)
                            },
                            presets: function(t) {
                                var s = [];
                                return t.forEach((function(t) {
                                    s.push(t.presetValue)
                                })), s
                            }(s.presetsList),
                            onClickSound: m,
                            disabled: C
                        }) : (0, r.jsx)(x, {
                            items: j,
                            activeItemIndex: y
                        })]
                    })
                },
                m = function(t) {
                    var s = (0, e.Z)({}, t);
                    return (0, r.jsx)(j, {
                        value: s,
                        children: (0, r.jsx)(y, {})
                    })
                }
        },
        1641: function(t, s, a) {
            a.d(s, {
                G: function() {
                    return C
                }
            });
            var e = a(2791),
                r = a(1413),
                o = a(4165),
                i = a(5861),
                l = a(9439),
                n = a(1435),
                c = a(8182),
                p = a(1956),
                f = a(3168),
                d = a(3892),
                x = a(6591),
                _ = a(4761),
                u = a(6761),
                h = a(5251),
                j = a.n(h),
                y = a(184),
                m = function(t) {
                    var s = (0, f.$)().t,
                        a = (0, e.useState)(!1),
                        h = (0, l.Z)(a, 2),
                        m = h[0],
                        C = h[1],
                        g = t.item,
                        O = t.gameApi,
                        v = t.numberOfRounds,
                        b = _.GC[g.state] === _.GC.Win,
                        L = (0, e.useState)(void 0),
                        G = (0, l.Z)(L, 2),
                        U = G[0],
                        S = G[1],
                        w = function(t) {
                            (0, x.T)(t)
                        },
                        Z = (0, d.QS)({
                            onTap: function() {
                                return w(g.salt)
                            }
                        }),
                        E = (0, d.QS)({
                            onTap: function() {
                                return w(g.hash)
                            }
                        }),
                        M = (0, e.useCallback)((0, i.Z)((0, o.Z)().mark((function t() {
                            var s;
                            return (0, o.Z)().wrap((function(t) {
                                for (;;) switch (t.prev = t.next) {
                                    case 0:
                                        if (t.prev = 0, U) {
                                            t.next = 6;
                                            break
                                        }
                                        return t.next = 4, O.getSession(g.id);
                                    case 4:
                                        s = t.sent, S(s.gameData);
                                    case 6:
                                        t.next = 11;
                                        break;
                                    case 8:
                                        t.prev = 8, t.t0 = t.catch(0), j().log(t.t0);
                                    case 11:
                                    case "end":
                                        return t.stop()
                                }
                            }), t, null, [
                                [0, 8]
                            ])
                        }))), [U]);
                    return (0, y.jsxs)("div", {
                        className: (0, c.W)("history-element-container", m && "opened"),
                        children: [(0, y.jsxs)("div", {
                            className: "collapsable-header collapsable-header-my",
                            children: [(0, y.jsxs)("div", {
                                className: "date",
                                children: [(0, y.jsx)("div", {
                                    id: "myHistoryCurrentTime",
                                    children: (0, u.pD)(g.endDate)
                                }), (0, y.jsx)("div", {
                                    id: "myHistoryCurrentDate",
                                    children: (0, u._3)(g.endDate)
                                })]
                            }), (0, y.jsxs)("div", {
                                className: "start-sum",
                                id: "myHistoryLastBetAmount",
                                children: [g.bet, " ", (0, y.jsxs)("span", {
                                    children: [" ", _.F[g.currency]]
                                })]
                            }), (0, y.jsxs)("div", {
                                className: "coef",
                                children: ["x", g.coefficient]
                            }), (0, y.jsx)("div", {
                                className: "won",
                                id: "myHistoryLastBetWonAmount",
                                children: b ? (0, y.jsx)("div", {
                                    className: "win-amount",
                                    children: "".concat(g.availableCashout, " ").concat(_.F[g.currency])
                                }) : (0, y.jsx)("div", {
                                    className: "lose-amount",
                                    children: "-"
                                })
                            }), (0, y.jsx)("div", {
                                role: "button",
                                tabIndex: 0,
                                className: (0, c.W)("collapse-button"),
                                onClick: function() {
                                    M().then((function() {
                                        return C(!m)
                                    }))
                                },
                                onKeyDown: function() {
                                    return C(!m)
                                },
                                children: (0, y.jsx)("div", {
                                    children: (0, y.jsx)("img", {
                                        src: n,
                                        alt: "chevron-down"
                                    })
                                })
                            })]
                        }), (0, y.jsx)("div", {
                            className: (0, c.W)("separator", !m && "closed")
                        }), (0, y.jsx)("div", {
                            className: (0, c.W)("collapsable-container", m && "opened"),
                            children: (0, y.jsxs)("div", {
                                className: "details",
                                children: [(0, y.jsxs)("div", {
                                    className: "row justify-between px-[20px]",
                                    children: [(0, y.jsxs)("div", {
                                        className: "rounds",
                                        children: [s("Rounds"), " ", (0, y.jsx)("b", {
                                            children: g.lastRound
                                        }), (0, y.jsxs)("b", {
                                            className: "text-[#858CAB]",
                                            children: ["/", null !== U && void 0 !== U && U.presetValue && !v ? (null === U || void 0 === U ? void 0 : U.expectedChoices.length) - (null === U || void 0 === U ? void 0 : U.presetValue) : v]
                                        })]
                                    }), b ? (0, y.jsx)("div", {
                                        className: "game-result game-result-win",
                                        children: s("Win")
                                    }) : (0, y.jsx)("div", {
                                        className: "game-result game-result-lose",
                                        children: s("Lose")
                                    })]
                                }), (0, y.jsx)("div", {
                                    className: "row mt-[7px]",
                                    children: (0, y.jsxs)("div", {
                                        className: "row-text",
                                        children: [(0, y.jsxs)("span", {
                                            children: ["Hash: ", (0, y.jsxs)("b", {
                                                children: [g.hash.substring(0, 30), "..."]
                                            })]
                                        }), (0, y.jsx)("div", (0, r.Z)((0, r.Z)({}, E), {}, {
                                            role: "button",
                                            tabIndex: 0,
                                            onClick: function() {
                                                return w(g.hash)
                                            },
                                            onKeyDown: function() {
                                                return w(g.hash)
                                            },
                                            className: "button-container",
                                            children: (0, y.jsx)("img", {
                                                height: "15px",
                                                src: p,
                                                alt: "icon"
                                            })
                                        }))]
                                    })
                                }), (0, y.jsx)("div", {
                                    className: "row",
                                    children: (0, y.jsxs)("div", {
                                        className: "row-text",
                                        children: [(0, y.jsxs)("span", {
                                            children: ["Salt: ", (0, y.jsxs)("b", {
                                                children: [g.salt.substring(0, 30), "..."]
                                            })]
                                        }), (0, y.jsx)("div", (0, r.Z)((0, r.Z)({}, Z), {}, {
                                            role: "button",
                                            tabIndex: 0,
                                            onClick: function() {
                                                return w(g.salt)
                                            },
                                            onKeyDown: function() {
                                                return w(g.salt)
                                            },
                                            className: "button-container",
                                            children: (0, y.jsx)("img", {
                                                height: "15px",
                                                src: p,
                                                alt: "icon"
                                            })
                                        }))]
                                    })
                                })]
                            })
                        })]
                    })
                };
            m.defaultProps = {
                numberOfRounds: 0
            };
            var C = function(t) {
                var s = t.list,
                    a = t.gameApi,
                    e = t.numberOfRounds,
                    r = (0, f.$)().t;
                return (0, y.jsxs)("div", {
                    className: "history-panel__content-wrapper",
                    children: [(0, y.jsxs)("div", {
                        className: "history-panel__my-cols history-panel__headers",
                        children: [(0, y.jsx)("span", {}), (0, y.jsx)("h3", {
                            children: r("Bet")
                        }), (0, y.jsx)("h3", {
                            children: r("Coef")
                        }), (0, y.jsx)("h3", {
                            className: "header-col-win",
                            children: r("Win")
                        }), (0, y.jsx)("span", {})]
                    }), (0, y.jsx)("div", {
                        className: "history-panel__list-wrapper",
                        children: s.length > 0 ? s.map((function(t) {
                            return (0, y.jsx)(m, {
                                numberOfRounds: e,
                                item: t,
                                gameApi: a
                            }, t.hash)
                        })) : null
                    })]
                })
            };
            C.defaultProps = {
                numberOfRounds: 0
            }
        },
        5131: function(t, s, a) {
            a.d(s, {
                O: function() {
                    return c
                }
            });
            a(2791);
            var e = a(4761),
                r = a(8182),
                o = a(3457),
                i = a(184),
                l = function(t) {
                    var s = t.item;
                    return (0, i.jsx)("div", {
                        className: (0, r.W)("history-element-container"),
                        children: (0, i.jsxs)("div", {
                            className: "collapsable-header history-live",
                            children: [(0, i.jsxs)("div", {
                                className: "user",
                                children: [(0, i.jsx)("img", {
                                    width: 28,
                                    height: 28,
                                    alt: "user icon",
                                    src: o
                                }), (0, i.jsx)("div", {
                                    className: "ml-[8px]",
                                    children: s.user
                                })]
                            }), (0, i.jsxs)("div", {
                                className: "start-sum",
                                children: [s.bet, " ", (0, i.jsxs)("span", {
                                    children: [" ", e.F[s.currency]]
                                })]
                            }), (0, i.jsxs)("div", {
                                className: "coef",
                                children: ["x", (s.resultBalance / s.bet).toFixed(2)]
                            }), (0, i.jsx)("div", {
                                className: "game-amount",
                                children: (0, i.jsx)("div", {
                                    className: "win-amount",
                                    children: "".concat(s.resultBalance, " ").concat(e.F[s.currency])
                                })
                            })]
                        })
                    })
                },
                n = a(3168),
                c = function(t) {
                    var s = t.list,
                        a = (0, n.$)().t;
                    return (0, i.jsxs)("div", {
                        className: "history-panel__content-wrapper",
                        children: [(0, i.jsxs)("div", {
                            className: "history-panel__headers history-panel__live-cols",
                            children: [(0, i.jsx)("h3", {
                                children: a("Player")
                            }), (0, i.jsx)("h3", {
                                children: a("Bet")
                            }), (0, i.jsx)("h3", {
                                children: a("Coef")
                            }), (0, i.jsx)("h3", {
                                className: "header-col-win",
                                children: a("Win")
                            })]
                        }), (0, i.jsx)("div", {
                            className: "history-panel__list-wrapper",
                            children: s.length > 0 ? s.map((function(t) {
                                return (0, i.jsx)(l, {
                                    item: t
                                }, function(t) {
                                    return "".concat(t.user, " ").concat(t.bet, " ").concat(10 * Math.random())
                                }(t))
                            })) : null
                        })]
                    })
                }
        },
        1963: function(t, s, a) {
            a.d(s, {
                M: function() {
                    return e
                },
                N: function() {
                    return r
                }
            });
            var e = function(t) {
                    return t[t.UPDATE_SETTINGS = 0] = "UPDATE_SETTINGS", t[t.UPDATE_SESSION = 1] = "UPDATE_SESSION", t[t.UPDATE_USER_DATA = 2] = "UPDATE_USER_DATA", t[t.SET_SESSIONS = 3] = "SET_SESSIONS", t[t.SET_USER = 4] = "SET_USER", t[t.SET_LIVE_BETS_CONNECTED = 5] = "SET_LIVE_BETS_CONNECTED", t[t.SET_LIVE_BETS = 6] = "SET_LIVE_BETS", t
                }({}),
                r = {
                    updateSettings: function(t) {
                        return {
                            type: e.UPDATE_SETTINGS,
                            payload: t
                        }
                    },
                    updateSessions: function(t) {
                        return {
                            type: e.SET_SESSIONS,
                            payload: t
                        }
                    },
                    setUser: function(t) {
                        return {
                            type: e.SET_USER,
                            payload: t
                        }
                    },
                    updateSession: function(t) {
                        return {
                            type: e.UPDATE_SESSION,
                            payload: t
                        }
                    },
                    liveBetsConnected: function(t) {
                        return {
                            type: e.SET_LIVE_BETS_CONNECTED,
                            payload: t
                        }
                    },
                    setLiveBets: function(t) {
                        return {
                            type: e.SET_LIVE_BETS,
                            payload: t
                        }
                    }
                }
        }
    }
]);
//# sourceMappingURL=4866.b20ff7a4.chunk.js.map